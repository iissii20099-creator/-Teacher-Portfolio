import { useEffect, useMemo, useState } from "react";
import { StoreProvider, load, migrate, useStore } from "./store";
import { NavCtx, type PageId, type View } from "./nav";
import { computeCompletion, type Teacher } from "./data";
import { EightStar, GoldDivider, Icon, MiniRing } from "./components/ui";
import {
  ShareProvider,
  getLock,
  isUnlocked,
  markUnlocked,
  readShared,
  useShare,
  verifyPassword,
  type LockData,
  type Payload,
} from "./share";
import { DriveProvider } from "./googleDrive";
import { SyncChip, SyncProvider } from "./sync";
import { ClosingPage, HomePage } from "./pages/Home";
import { PlanPage, ProfilePage } from "./pages/ProfilePlan";
import { CriteriaPage, CriterionPage } from "./pages/Criteria";
import { EvidencePage } from "./pages/Evidence";
import { PracticesPage } from "./pages/Practices";
import { DevelopmentPage, ResultsPage } from "./pages/Analysis";
import { AchievementsPage } from "./pages/Achievements";
import { ReportsPage } from "./pages/Reports";
import { SharePage } from "./pages/Share";
import { DashboardPage } from "./pages/Dashboard";
import { cn } from "./utils/cn";

const NAV: { id: PageId; label: string }[] = [
  { id: "home", label: "الرئيسية" },
  { id: "profile", label: "الملف الشخصي" },
  { id: "criteria", label: "معايير الأداء" },
  { id: "plan", label: "الخطة التعليمية" },
  { id: "practices", label: "الممارسات المهنية" },
  { id: "results", label: "نتائج الطلاب" },
  { id: "evidence", label: "الشواهد" },
  { id: "achievements", label: "الإنجازات" },
  { id: "development", label: "التطوير المهني" },
  { id: "reports", label: "التقارير" },
  { id: "share", label: "المشاركة والحماية" },
  { id: "dashboard", label: "لوحة التحكم" },
  { id: "closing", label: "الخاتمة" },
];

/* صفحات تُخفى عن المستلم في وضع العرض */
const OWNER_ONLY: PageId[] = ["dashboard", "share"];

function Shell() {
  const { state } = useStore();
  const { shared, viewer, setViewer } = useShare();
  const [view, setView] = useState<View>({ page: "home" });
  const [progress, setProgress] = useState(0);
  const [showTop, setShowTop] = useState(false);

  const navigate = (page: PageId, param?: number) => {
    setView({ page, param });
    window.scrollTo({ top: 0 });
  };

  useEffect(() => {
    const onScroll = () => {
      const h = document.documentElement;
      const max = h.scrollHeight - h.clientHeight;
      setProgress(max > 0 ? (h.scrollTop / max) * 100 : 0);
      setShowTop(h.scrollTop > 600);
    };
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  const comp = useMemo(() => computeCompletion(state), [state]);
  const activeId: PageId = view.page === "criterion" ? "criteria" : view.page;
  const navItems = viewer ? NAV.filter((n) => !OWNER_ONLY.includes(n.id)) : NAV;

  const render = () => {
    switch (view.page) {
      case "home":
        return <HomePage />;
      case "profile":
        return <ProfilePage />;
      case "criteria":
        return <CriteriaPage />;
      case "criterion":
        return <CriterionPage id={view.param ?? 1} />;
      case "plan":
        return <PlanPage />;
      case "practices":
        return <PracticesPage />;
      case "results":
        return <ResultsPage />;
      case "evidence":
        return <EvidencePage />;
      case "achievements":
        return <AchievementsPage />;
      case "development":
        return <DevelopmentPage />;
      case "reports":
        return <ReportsPage />;
      case "share":
        return <SharePage />;
      case "dashboard":
        return <DashboardPage />;
      case "closing":
        return <ClosingPage />;
    }
  };

  return (
    <NavCtx.Provider value={navigate}>
      <div className="relative z-10 flex min-h-screen flex-col">
        {/* ===== الترويسة ===== */}
        <header className="no-print sticky top-0 z-40 border-b border-gold-300/50 bg-cream/90 backdrop-blur-md">
          <div className="mx-auto max-w-6xl px-4 md:px-6">
            <div className="flex items-center gap-3 py-2.5">
              <button onClick={() => navigate("home")} className="flex items-center gap-3 text-right">
                <span className="relative flex h-11 w-11 items-center justify-center rounded-lg border border-gold-400/60 bg-pine-900">
                  <EightStar className="anim-spin-slow h-7 w-7 text-gold-400" />
                  <span className="absolute -bottom-1 -left-1 flex h-4.5 w-4.5 items-center justify-center rounded-full border border-gold-300 bg-gold-500 text-[9px] font-extrabold text-white">
                    م
                  </span>
                </span>
                <span>
                  <span className="block font-display text-xl font-bold leading-tight text-pine-900">ملف إنجاز المعلم</span>
                  <span className="block text-[10px] font-extrabold tracking-wide text-gold-600">
                    {shared ? `نسخة للعرض · ${state.teacher.name}` : `توثيق الأداء المهني · ${state.teacher.year}`}
                  </span>
                </span>
              </button>
              <div className="ms-auto flex items-center gap-3">
                {viewer && (
                  <span className="hidden items-center gap-1.5 rounded-full border border-pine-600/25 bg-pine-50 px-2.5 py-1 text-[10px] font-extrabold text-pine-700 sm:flex">
                    <Icon name="eye" size={12} /> وضع العرض
                  </span>
                )}
                <span className="no-print hidden lg:block">
                  <SyncChip onOpenPanel={() => navigate("dashboard")} />
                </span>
                <div className="hidden items-center gap-2 sm:flex" title="اكتمال ملف الإنجاز">
                  <span className="text-[10px] font-extrabold text-ink-soft">اكتمال الملف</span>
                  <MiniRing value={comp.total} />
                </div>
                {viewer && !shared ? (
                  <button className="btn-ghost hidden !px-3 !py-1.5 md:inline-flex" onClick={() => setViewer(false)}>
                    <Icon name="x" size={14} /> خروج من العرض
                  </button>
                ) : (
                  <button className="btn-ghost hidden !px-3 !py-1.5 md:inline-flex" onClick={() => navigate("dashboard")}>
                    <Icon name="settings" size={14} /> لوحة التحكم
                  </button>
                )}
              </div>
            </div>
            {/* شريط التنقل الرئيسي */}
            <nav className="-mx-1 flex gap-1 overflow-x-auto pb-2 [scrollbar-width:none] [&::-webkit-scrollbar]:hidden" aria-label="التنقل الرئيسي">
              {navItems.map((n) => (
                <button
                  key={n.id}
                  onClick={() => navigate(n.id)}
                  className={cn(
                    "shrink-0 border-b-2 px-3 py-1.5 text-xs font-extrabold transition",
                    activeId === n.id
                      ? "border-gold-500 text-pine-900"
                      : "border-transparent text-ink-faint hover:border-gold-300 hover:text-pine-800"
                  )}
                >
                  {n.label}
                </button>
              ))}
            </nav>
          </div>
          {/* شريط تقدم القراءة */}
          <div className="absolute inset-x-0 bottom-0 h-[3px] bg-sand-deep/50">
            <div className="h-full bg-gradient-to-l from-gold-400 to-pine-600 transition-[width] duration-150" style={{ width: `${progress}%` }} />
          </div>
        </header>

        {/* ===== المحتوى ===== */}
        <main className="flex-1">
          <div key={view.page + (view.param ?? "")} className="view-anim">
            {render()}
          </div>
        </main>

        {/* ===== التذييل ===== */}
        <footer className="no-print mt-14 bg-pine-950 text-cream">
          <div className="mx-auto grid max-w-6xl grid-cols-1 gap-10 px-4 py-12 md:grid-cols-3 md:px-6">
            <div>
              <div className="flex items-center gap-3">
                <span className="flex h-10 w-10 items-center justify-center rounded-lg border border-gold-400/50 bg-pine-900">
                  <EightStar className="h-6 w-6 text-gold-400" />
                </span>
                <p className="font-display text-xl font-bold">ملف إنجاز المعلم</p>
              </div>
              <p className="mt-4 max-w-xs font-display text-lg leading-relaxed text-cream/75">
                «رحلة مِهنية توثّق الممارسة، وتُظهر الأثر، وتُصنّع التطوّر.»
              </p>
              <GoldDivider className="mt-5 max-w-[200px] opacity-60" />
            </div>
            <div>
              <p className="text-xs font-extrabold tracking-wide text-gold-400">أبواب سريعة</p>
              <ul className="mt-4 grid grid-cols-2 gap-x-4 gap-y-2">
                {navItems.slice(1, 10).map((n) => (
                  <li key={n.id}>
                    <button className="text-xs font-bold text-cream/70 transition hover:text-gold-300" onClick={() => navigate(n.id)}>
                      {n.label}
                    </button>
                  </li>
                ))}
              </ul>
            </div>
            <div>
              <p className="text-xs font-extrabold tracking-wide text-gold-400">بيانات المعلم</p>
              <ul className="mt-4 space-y-2 text-xs font-bold text-cream/70">
                <li className="flex items-center gap-2">
                  <Icon name="user" size={13} className="text-gold-500" /> {state.teacher.name}
                </li>
                <li className="flex items-center gap-2">
                  <Icon name="book" size={13} className="text-gold-500" /> {state.teacher.specialty}
                </li>
                <li className="flex items-center gap-2">
                  <Icon name="building" size={13} className="text-gold-500" /> {state.teacher.school}
                </li>
                <li className="flex items-center gap-2">
                  <Icon name="calendar" size={13} className="text-gold-500" /> {state.teacher.year}
                </li>
              </ul>
            </div>
          </div>
          <div className="border-t border-gold-500/20 py-4 text-center text-[10px] font-bold text-cream/40">
            أُعدّ هذا الملف كمنصة مهنية رسمية لتوثيق الأداء · {state.teacher.year}
          </div>
        </footer>

        {/* زر العودة للأعلى */}
        <button
          onClick={() => window.scrollTo({ top: 0, behavior: "smooth" })}
          className={cn(
            "no-print fixed bottom-6 left-6 z-40 flex h-11 w-11 items-center justify-center rounded-full border border-gold-400/60 bg-pine-900 text-gold-300 shadow-lift transition-all",
            showTop ? "translate-y-0 opacity-100" : "pointer-events-none translate-y-4 opacity-0"
          )}
          aria-label="العودة للأعلى"
        >
          <Icon name="chevron" size={18} className="rotate-90" />
        </button>
      </div>
    </NavCtx.Provider>
  );
}

/* ===================== شاشة الإقلاع ===================== */
function BootScreen() {
  return (
    <div className="flex min-h-screen flex-col items-center justify-center gap-5 bg-pine-950 text-cream">
      <EightStar className="anim-spin-slow h-16 w-16 text-gold-400/80" />
      <p className="font-display text-xl font-bold">جارٍ فتح ملف الإنجاز…</p>
      <p className="boot-pulse text-[11px] font-bold text-cream/50">يُفكّ ضغط البيانات المضمّنة في الرابط</p>
    </div>
  );
}

/* ===================== رابط مقتطع ===================== */
function BrokenLink() {
  return (
    <div className="flex min-h-screen items-center justify-center bg-pine-950 px-4 py-16 text-cream">
      <div className="w-full max-w-md rounded-xl border border-gold-500/40 bg-pine-900/80 p-7 text-center shadow-2xl">
        <span className="mx-auto flex h-14 w-14 items-center justify-center rounded-full border-2 border-gold-400/50 bg-pine-800 text-gold-300">
          <Icon name="x" size={26} />
        </span>
        <h1 className="mt-4 font-display text-2xl font-bold">الرابط غير مكتمل</h1>
        <p className="mt-3 text-xs font-bold leading-relaxed text-cream/75">
          يبدو أن رابط الملف اقتُطع أثناء النسخ أو الإرسال، فلم تصل البيانات المضمّنة فيه كاملة. اطلب من المعلم إعادة إرسال الرابط كما هو، أو استخدام «الملف المستقل» المرفوع على Drive.
        </p>
        <button
          className="btn-gold mt-6 w-full"
          onClick={() => {
            history.replaceState(null, "", location.pathname + location.search);
            location.reload();
          }}
        >
          <Icon name="refresh" size={15} /> فتح الملف بدون الرابط
        </button>
      </div>
    </div>
  );
}

/* ===================== بوابة كلمة المرور ===================== */
function LockGate({ teacher, lock, onUnlock }: { teacher: Teacher; lock: LockData; onUnlock: () => void }) {
  const [pw, setPw] = useState("");
  const [err, setErr] = useState("");
  const [shake, setShake] = useState(0);
  const [busy, setBusy] = useState(false);

  const submit = async () => {
    setBusy(true);
    const ok = await verifyPassword(pw, lock);
    setBusy(false);
    if (ok) {
      markUnlocked();
      onUnlock();
    } else {
      setErr("كلمة المرور غير صحيحة — أعد المحاولة.");
      setShake((s) => s + 1);
      setPw("");
    }
  };

  return (
    <div className="relative flex min-h-screen items-center justify-center overflow-hidden bg-pine-950 px-4 py-16 text-cream">
      <EightStar className="anim-spin-slow absolute -left-28 -top-28 h-[22rem] w-[22rem] text-gold-500/10" />
      <EightStar className="anim-spin-slow absolute -bottom-32 -right-24 h-[26rem] w-[26rem] text-gold-500/[.07]" />
      <div key={shake} className={cn("relative w-full max-w-md rounded-xl border border-gold-500/40 bg-pine-900/80 p-7 text-center shadow-2xl", shake > 0 && "gate-shake")}>
        <span className="mx-auto flex h-14 w-14 items-center justify-center rounded-full border-2 border-gold-400/60 bg-pine-800 text-gold-300">
          <Icon name="shield" size={26} />
        </span>
        <p className="mt-4 text-[10px] font-extrabold tracking-widest text-gold-400">ملف إنجاز المعلم</p>
        <h1 className="mt-1 font-display text-3xl font-bold leading-snug">{teacher.name}</h1>
        <p className="mt-1 text-xs font-bold text-cream/60">
          {teacher.specialty} · {teacher.school}
        </p>
        <GoldDivider className="mx-auto my-5 max-w-[220px] opacity-70" />
        <p className="text-xs font-bold leading-relaxed text-cream/75">هذا الملف محمي بكلمة مرور من قِبل صاحبه. أدخل الكلمة لعرضه.</p>
        <form
          className="mt-5 space-y-3"
          onSubmit={(e) => {
            e.preventDefault();
            void submit();
          }}
        >
          <input
            type="password"
            autoFocus
            className="inp !bg-pine-950/60 !border-gold-500/40 !text-cream text-center !text-base tracking-[0.3em] placeholder:tracking-normal"
            placeholder="كلمة المرور"
            value={pw}
            onChange={(e) => {
              setPw(e.target.value);
              setErr("");
            }}
          />
          {err && <p className="text-[11px] font-extrabold text-clay">{err}</p>}
          <button type="submit" className="btn-gold w-full" disabled={busy || !pw}>
            <Icon name={busy ? "refresh" : "shield"} size={15} className={busy ? "animate-spin" : ""} />
            {busy ? "جارٍ التحقق…" : "فتح الملف"}
          </button>
        </form>
        <p className="mt-4 text-[10px] font-bold leading-relaxed text-cream/40">
          إن كنت صاحب الملف ونسيت الكلمة، فمسح بيانات الموقع من إعدادات المتصفح يعيد الملف لحالته الأولى.
        </p>
      </div>
    </div>
  );
}

/* ===================== الجذر ===================== */
function Root({ payload, teacher }: { payload: Payload | null; teacher: Teacher }) {
  const shared = !!payload;
  const [lock, setLock] = useState<LockData | null>(() => (payload ? payload.lock : getLock()));
  const [unlocked, setUnlocked] = useState(() => !lock || isUnlocked());
  const [viewerOn, setViewerOn] = useState(false);
  const viewer = shared || viewerOn;

  useEffect(() => {
    setUnlocked(!lock || isUnlocked());
  }, [lock]);

  useEffect(() => {
    document.documentElement.classList.toggle("viewer-mode", viewer);
    return () => document.documentElement.classList.remove("viewer-mode");
  }, [viewer]);

  const ctl = useMemo(
    () => ({ shared, viewer, setViewer: (v: boolean) => setViewerOn(v), lock, setLock }),
    [shared, viewer, lock]
  );

  if (lock && !unlocked) return <LockGate teacher={teacher} lock={lock} onUnlock={() => setUnlocked(true)} />;

  return (
    <ShareProvider value={ctl}>
      <StoreProvider initial={payload?.state} persist={!shared}>
        <DriveProvider>
          <SyncProvider disabled={shared}>
            <Shell />
          </SyncProvider>
        </DriveProvider>
      </StoreProvider>
    </ShareProvider>
  );
}

export default function App() {
  const [boot, setBoot] = useState<{ payload: Payload | null; teacher: Teacher } | null>(null);

  useEffect(() => {
    let alive = true;
    readShared().then((raw) => {
      if (!alive) return;
      const payload = raw ? { ...raw, state: migrate(raw.state) } : null;
      const teacher = payload?.state.teacher ?? load().teacher;
      setBoot({ payload, teacher });
    });
    return () => {
      alive = false;
    };
  }, []);

  if (!boot) return <BootScreen />;
  if (!boot.payload && /[#&]f=/.test(location.hash)) return <BrokenLink />;
  return <Root payload={boot.payload} teacher={boot.teacher} />;
}
