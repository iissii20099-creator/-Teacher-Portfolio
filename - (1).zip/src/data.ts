/* ===================== الأنواع ===================== */
export type EvidenceType = "PDF" | "Word" | "PowerPoint" | "Excel" | "صورة" | "فيديو" | "رابط";
export type Semester = "الفصل الأول" | "الفصل الثاني";
export type DocStatus = "موثق" | "قيد التوثيق" | "غير موثق";

export interface Teacher {
  name: string;
  specialty: string;
  school: string;
  year: string;
  photo: string;
  degree: string;
  license: string;
  experience: number;
  skills: string[];
  interests: string[];
}

export interface Criterion {
  id: number;
  title: string;
  short: string;
  indicators: string[];
  required: string[];
  impact: string;
  reflection: string;
  proofs: string[];
  reports: string[];
  icon: string;
}

export interface Evidence {
  id: string;
  title: string;
  desc: string;
  type: EvidenceType;
  date: string;
  criterionId: number;
  subject: string;
  semester: Semester;
  link?: string;
  image?: string;
  file?: { name: string; url?: string };
  notes?: string;
}

export type PracticeCategory =
  | "دروس نموذجية"
  | "استراتيجيات تدريس"
  | "أنشطة صفية"
  | "تعلم تعاوني"
  | "تعلم رقمي"
  | "مشاريع الطلاب"
  | "مبادرات"
  | "مسابقات لغوية";

export interface Practice {
  id: string;
  title: string;
  category: PracticeCategory;
  desc: string;
  goal: string;
  strategy: string;
  impact: string;
  image?: string;
  files: { name: string; type: string }[];
  date: string;
}

export type DevKind = "دورة" | "ورشة عمل" | "مؤتمر" | "مجتمع تعلم" | "بحث" | "قراءة مهنية" | "مبادرة";

export interface DevItem {
  id: string;
  kind: DevKind;
  title: string;
  org: string;
  date: string;
  hours: number;
  cert: string;
  link?: string;
}

export type AchKind = "شهادة" | "تكريم" | "مبادرة" | "مسابقة" | "مشروع" | "إنجاز طلابي" | "مشاركة مهنية";

export interface Achievement {
  id: string;
  kind: AchKind;
  title: string;
  date: string;
  desc: string;
  image?: string;
}

export interface PlanRow {
  unit: string;
  content: string;
  weeks: string;
  hours: number;
  activities: string;
  status: "منفذة" | "قيد التنفيذ" | "مجدولة";
}

export interface PlanWork {
  id: string;
  title: string;
  type: "ورقة عمل" | "واجب" | "نشاط إثرائي" | "اختبار";
  week: string;
}

export interface StudentData {
  before: number;
  after: number;
  students: number;
  excelling: number;
  support: number;
  subjects: { name: string; before: number; after: number }[];
  trend: { label: string; value: number }[];
  levels: { label: string; value: number }[];
}

export interface FileLibItem {
  id: string;
  name: string;
  kind: "ملف" | "صورة";
  url?: string;
  size: string;
  date: string;
}

export interface State {
  teacher: Teacher;
  criteria: Criterion[];
  evidence: Evidence[];
  practices: Practice[];
  development: DevItem[];
  achievements: Achievement[];
  plan: { t1: PlanRow[]; t2: PlanRow[] };
  works: PlanWork[];
  student: StudentData;
  files: FileLibItem[];
}

/* ===================== أدوات عامة ===================== */
export const uid = () => Math.random().toString(36).slice(2, 10);

export const AR_DIGITS = "٠١٢٣٤٥٦٧٨٩";
export const toAr = (n: number | string) =>
  String(n).replace(/[0-9]/g, (d) => AR_DIGITS[Number(d)]);

export const fmtDate = (iso: string) => {
  try {
    return new Date(iso).toLocaleDateString("ar-EG-u-nu-latn", { day: "numeric", month: "long", year: "numeric" });
  } catch {
    return iso;
  }
};

export const EVIDENCE_TYPES: EvidenceType[] = ["PDF", "Word", "PowerPoint", "Excel", "صورة", "فيديو", "رابط"];
export const PRACTICE_CATEGORIES: PracticeCategory[] = [
  "دروس نموذجية",
  "استراتيجيات تدريس",
  "أنشطة صفية",
  "تعلم تعاوني",
  "تعلم رقمي",
  "مشاريع الطلاب",
  "مبادرات",
  "مسابقات لغوية",
];
export const DEV_KINDS: DevKind[] = ["دورة", "ورشة عمل", "مؤتمر", "مجتمع تعلم", "بحث", "قراءة مهنية", "مبادرة"];
export const ACH_KINDS: AchKind[] = ["شهادة", "تكريم", "مبادرة", "مسابقة", "مشروع", "إنجاز طلابي", "مشاركة مهنية"];

/* صور مرجعية (مكتبة Pexels) */
export const IMG = {
  portrait: "https://images.pexels.com/photos/5212361/pexels-photo-5212361.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=1200&w=800",
  discuss: "https://images.pexels.com/photos/5212342/pexels-photo-5212342.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=627&w=1200",
  coop: "https://images.pexels.com/photos/8617759/pexels-photo-8617759.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=627&w=1200",
  digital: "https://images.pexels.com/photos/5905488/pexels-photo-5905488.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=627&w=1200",
  project: "https://images.pexels.com/photos/7396377/pexels-photo-7396377.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=627&w=1200",
  env: "https://images.pexels.com/photos/5212331/pexels-photo-5212331.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=627&w=1200",
  interaction: "https://images.pexels.com/photos/8617762/pexels-photo-8617762.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=627&w=1200",
  contest: "https://images.pexels.com/photos/8423095/pexels-photo-8423095.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=627&w=1200",
  support: "https://images.pexels.com/photos/5212354/pexels-photo-5212354.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=627&w=1200",
  engage: "https://images.pexels.com/photos/8423008/pexels-photo-8423008.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=627&w=1200",
};

/* ===================== معايير الأداء (المرجع الأساسي) ===================== */
const SEED_CRITERIA: Criterion[] = [
  {
    id: 1,
    title: "أداء الواجبات الوظيفية",
    short: "الالتزام التام بالمهام الوظيفية والأنظمة المدرسية، وإثبات الحضور والفاعل اليومية داخل الميدان.",
    indicators: [
      "يحضر الدوام اليومي في المواعيد الرسمية دون انقطاع مبرر",
      "ينفذ المناوبات والمهام المسندة بدقة وتوقيت",
      "يشارك في الإذاعة المدرسية وحصص النشاط بانتظام",
      "يستجيب للمهام الرسمية الموكلة من الإدارة بوقتها",
    ],
    required: [
      "الحضور والانصراف",
      "المناوبات",
      "الإشراف اليومي",
      "المشاركة في حصص النشاط",
      "الإذاعة المدرسية",
      "تنفيذ المهام الرسمية",
      "ما يثبت الالتزام بالمهام الوظيفية",
    ],
    impact: "استقرار الحركة المدرسية اليومي، وبيئة عمل منتظمة يشعر فيها الطلاب والزملاء بالمسؤولية النموذجية.",
    reflection: "الالتزام بالواجب اليومي لا يُرى في يومه، لكنه يتراكم عبر العام ليصبح سيرة مهنية يوثقها الحضور قبل الشواهد.",
    proofs: ["قيد الحضور والانصراف الإلكتروني", "توزيع المناوبات المعتمد"],
    reports: ["تقرير الالتزام بالواجبات الوظيفية – الفصل الأول", "تقرير المشاركة في الإذاعة والنشاط"],
    icon: "clipboard",
  },
  {
    id: 2,
    title: "التفاعل مع المجتمع المهني",
    short: "التنتمي الفاعل لمجتمعات التعلم المهني وتبادل الخبرات مع الزملاء للنمو المستمر.",
    indicators: [
      "يحضر اجتماعات مجتمع التعلم المهني ويشارك في نقاشاتها",
      "يبادر بزيارات صفية متبادلة مع الزملاء",
      "يشارك زملاءه موارد وممارسات مجرّبة",
      "يحوّل مخرجات المجتمعات إلى ممارسات صفية موثقة",
    ],
    required: [
      "حضور مجتمعات التعلم المهني",
      "المشاركة فيها",
      "تبادل الزيارات الصفية",
      "توثيق التعاون مع الزملاء",
      "الدورات والبرامج التدريبية",
      "ملف النمو المهني",
    ],
    impact: "نمو مهني جماعي، وانتقال الممارسات الفاعلة بين الصفوف، وثقافة تعاون تسبق أي تقييم فردي.",
    reflection: "أفضل ما تعلمته هذا العام لم يأتي من دورة، بل من زيارة صفية قصيرة كشفت لي قوة سؤال واحد جيد.",
    proofs: ["دعوة المشاركة في مجتمع اللغة العربية", "سجل الزيارات الصفية"],
    reports: ["تقرير حضور مجتمعات التعلم المهني"],
    icon: "users",
  },
  {
    id: 3,
    title: "التفاعل مع أولياء الأمور",
    short: "بناء شراكة مستمرة مع الأسرة عبر قنوات التواصل الرسمية، ومتابعة أبنائهم ودعمهم.",
    indicators: [
      "يتواصل مع أولياء الأمور عبر المنصات الرسمية بصفة دورية",
      "يرسل الخطط والواجبات والإشعارات في مواعيدها",
      "يرصد الطلاب المحتاجين للدعم ويبني لهم خططا علاجية",
      "يوثق جهوده في المتابعة ويقيّم أثرها",
    ],
    required: [
      "التواصل مع أولياء الأمور",
      "إرسال الخطط والواجبات",
      "إشعارات الطلاب",
      "التواصل عبر المنصات الرسمية",
      "توثيق متابعة الطلاب",
      "الخطط العلاجية للطلاب المحتاجين للدعم",
    ],
    impact: "شراكة أسرية فاعلة انعكست على حضور الطلاب واستجاباتهم، وانخفاض ملحوظ في حالات التأخر.",
    reflection: "رسالة واحدة موجّهة لولي أمر في وقتها، تغني عن اجتماع كامل — التوقيت نصف الرسالة.",
    proofs: ["نماذج رسائل المنصة الرسمية", "سجل المتابعة الأسبوعية"],
    reports: ["تقرير التواصل مع أولياء الأمور"],
    icon: "heart",
  },
  {
    id: 4,
    title: "التنوع في استراتيجيات التدريس",
    short: "توظيف خليط مدروس من الاستراتيجيات النشطة بما يناسب المحتوى والمستوى والغاية.",
    indicators: [
      "يوظف ثلاث استراتيجيات نشطة على الأقل في الدرس الواحد",
      "يوازن بين العمل الفردي والجماعي والمناقشة",
      "يستخدم التعلم بالاستقصاء والقائم على المشكلات",
      "يوثق حصصه بصورًا ومخططات وفيديوهات",
    ],
    required: [
      "التعلم التعاوني",
      "المناقشة",
      "التعلم النشط",
      "التعلم القائم على المشكلات",
      "التعلم بالاستقصاء",
      "استخدام استراتيجيات متنوعة",
      "صور وفيديوهات ومخططات للحصص",
    ],
    impact: "تفاعل صفّي مرتفع ومتجدد، وطلاب ينتقلون من المتلقي إلى الباحث والحاجج.",
    reflection: "الاستراتيجية ليست اختيارًا من قائمة، بل قرارًا يتخذه المعلم لحظة بلحظة لصالح المتعلم.",
    proofs: ["مخططات حصص موثقة", "نماذج أنشطة استقصائية"],
    reports: ["تقرير تنوع الاستراتيجيات – عينة من 6 حصص"],
    icon: "layers",
  },
  {
    id: 5,
    title: "تحسين نتائج المتعلمين",
    short: "تتبّع النتائج وتحليلها، ثم تصميم تدخلات مدروسة ترفع متوسطات الطلاب وتوسّع دائرة التفوق.",
    indicators: [
      "يحلل نتائج كل اختبار قبل البدء بوحدة جديدة",
      "يصمم تدخلات علاجية للطلاب المتعثرين",
      "يبني برامج إثرائية للطلاب المتفوقين",
      "يقارن النتائج قبل التدخل وبعده ويرصد الأثر",
    ],
    required: [
      "نتائج الاختبارات",
      "تحليل نتائج الطلاب",
      "الخطط العلاجية",
      "برامج الطلاب المتفوقين",
      "أنشطة إثرائية",
      "مقارنة نتائج الطلاب قبل وبعد التدخل التعليمي",
    ],
    impact: "ارتفاع متوسط المادة من 68.4 إلى 84.2 خلال العام، وارتفاع عدد الطلاب المتفوقين إلى 9 طلاب.",
    reflection: "النتيجة رقم، لكن القصة وراء الرقم هي التي تصنع القرار التعليمي القادم.",
    proofs: ["جداول مقارنة قبل/بعد", "خطط علاجية منفذة"],
    reports: ["تقرير أثر التدخلات العلاجية", "تقرير برنامج المتفوقين"],
    icon: "chartUp",
  },
  {
    id: 6,
    title: "إعداد وتنفيذ خطة التعلم",
    short: "تخطيط منهجي متدرج من الخطة الفصلية إلى خطة الدرس، مع أدوات وأوراق عمل مساندة.",
    indicators: [
      "يعد الخطة الفصلية ويتوافق مع التقويم المدرسي",
      "يوزع المنهج على الأسابيع بمرونة واقعية",
      "يحضر دروسه بأهداف سلوكية قابلة للرصد",
      "يستخدم أوراق عمل متدرجة تتوافق مع المستويات",
    ],
    required: [
      "الخطة الفصلية",
      "توزيع المنهج",
      "تحضير الدروس",
      "خطط الأسابيع",
      "الواجبات",
      "الأنشطة الصفية",
      "أوراق العمل",
      "خطط التدريس",
    ],
    impact: "انسيابية تدريس دون فجوات، وإمكانية تعويض أي تأخير دون ضغط على الختام.",
    reflection: "التخطيط الجيد يظهر حين تنحرف الخطة: فالمُعدّ بحكمة يعرف أين يعوّض وكيف.",
    proofs: ["الخطة الفصلية المعتمدة", "عينة تحضيرات أسبوعية"],
    reports: ["تقرير موثوقية التنفيذ مقابل الخطة الفصلية"],
    icon: "book",
  },
  {
    id: 7,
    title: "توظيف تقنيات ووسائل التعلم",
    short: "اختيار التقنية المناسبة للغاية لا العكس، من المنصات والتطبيقات إلى الذكاء الاصطناعي التعليمي.",
    indicators: [
      "يوظف المنصات التعليمية في التمارين والتقويم",
      "يصمم عروضًا وأوراق عمل تفاعلية",
      "يستعين بالذكاء الاصطناعي في تصميم الأنشطة",
      "يوازن بين الوسائط الحسية والرقمية",
    ],
    required: [
      "استخدام المنصات التعليمية",
      "العروض التفاعلية",
      "التطبيقات التعليمية",
      "تنويع أنشطة الطلاب الرقمية",
      "أوراق العمل الرقمية",
      "الاختبارات الإلكترونية",
      "استخدام الذكاء الاصطناعي في التعليم",
      "الوسائل التقنية المستخدمة داخل الدرس",
    ],
    impact: "تقويم فوري يتلقى الطالب نتيجته خلال دقائق، ونشاط رقمي صنفه الطلاب من الأعلى تفاعلًا.",
    reflection: "التقنية تفشل حين تصبح العرض لا الوسيلة؛ اختبرت ذلك في حصة كاملة ثم أعيدت صياغة الهدف.",
    proofs: ["روابط اختبارات إلكترونية", "نماذج أوراق عمل رقمية"],
    reports: ["تقرير توظيف التقنية في عينة من 5 حصص"],
    icon: "monitor",
  },
  {
    id: 8,
    title: "تهيئة البيئة التعليمية",
    short: "تصميم بيئة صفية آمنة ومحفزة: تنظيم المكان والوقت وتهيئة الطلاب نفسيًا للتعلم.",
    indicators: [
      "ينظم البيئة الصفية وفق مبادئ الوصول والأمان",
      "يخصص ركنًا للأنشطة والقراءة",
      "يدير انتقال الطلاب بين الأنشطة بهدوء",
      "يبدأ كل حصة بطقس تهيئة ثابت",
    ],
    required: [
      "إدارة الصف",
      "تنظيم البيئة الصفية",
      "ضبط وقت الحصة",
      "تهيئة الطلاب للتعلم",
      "توفير بيئة آمنة ومحفزة",
      "صور من البيئة الصفية",
    ],
    impact: "تقلص زمن الانتقال بين الأنشطة إلى أقل من دقيقتين، وارتفاع مؤشرات شعور الطلاب بالأمان.",
    reflection: "البيئة الصفية نص يصدره المعلم قبل أن يفتح فمه — ترتيب المقاعد قرار تخطيطي.",
    proofs: ["مخطط توزيع الصف", "صور موثقة للركن والقاعة"],
    reports: ["تقرير تهيئة البيئة الصفية"],
    icon: "sprout",
  },
  {
    id: 9,
    title: "الإدارة الصفية",
    short: "توجيه سير الدرس وتوزيع الوقت وإدارة التفاعل، بحيث يبقى الجميع ضمن مدار التعلم.",
    indicators: [
      "يوزع وقت الحصة بمراحل واضحة قابلة للقياس",
      "يدير أسئلته توزيعًا عادلاً بين المستويات",
      "يدير التفاعل والتشويش دون إيقاف الدرس",
      "يوثق الممارسات الصفية التي تنجح",
    ],
    required: [
      "توجيه أسئلة محفزة",
      "توزيع الوقت",
      "تنظيم سير الدرس",
      "إدارة التفاعل داخل الصف",
      "توثيق الممارسات الصفية",
    ],
    impact: "نسبة مشاركة طلابية تجاوزت 80% في الحصص الموثقة، ودروس تسير دون انقطاع طويل.",
    reflection: "إدارة الصف ليست صرامة، بل إيقاع؛ فالدرس الجيد له نبض يعرفه الطلاب قبل معلمهم.",
    proofs: ["جدول توزيع الوقت لعينة دروس", "فيديو موثق لتفاعل صفّي"],
    reports: ["تقرير المراقبة الصفية الداخلية"],
    icon: "clock",
  },
  {
    id: 10,
    title: "تحليل نتائج المتعلمين وتشخيص مستوياتهم",
    short: "القراءة العميقة للنتائج: تشخيص المستويات وتصنيف الطلاب ورصد الاحتياج قبل وصفه.",
    indicators: [
      "يطبق اختبارًا تشخيصيًا بادئًا في مطلع كل فصل",
      "يصنف الطلاب إلى مستويات مع معايير واضحة",
      "يرصد الاحتياج الفردي لا المتوسط فقط",
      "يربط التشخيص بخطة علاجية أو إثرائية",
    ],
    required: [
      "الاختبارات التشخيصية",
      "تحليل النتائج",
      "تحديد مستويات الطلاب",
      "تصنيف الطلاب حسب المستوى",
      "تحديد احتياجات الطلاب",
      "وضع خطط علاجية مناسبة",
    ],
    impact: "خريطة مستويات دقيقة ساعدت في توجيه كل حصة، وخطط علاجية استهدفت 4 طلاب خرجوا منها إلى المستوى المتوسط.",
    reflection: "التشخيص السليم نصف العلاج؛ نصفه الآخر أن يعيد المعلم النظر في حصة هو نفسه قدّمها.",
    proofs: ["نتائج الاختبار التشخيصي", "جدول تصنيف المستويات"],
    reports: ["تقرير تشخيص المستويات – الفصل الثاني"],
    icon: "scan",
  },
  {
    id: 11,
    title: "تنوع أساليب التقويم",
    short: "مجموع متكامل من أساليب التقويم التكويني والختامي، يقيس الأداء لا الحفظ فقط.",
    indicators: [
      "يستخدم ثلاث أدوات تقويم على الأقل أسبوعيًا",
      "يتكامل التقويم التكويني مع الختامي",
      "يعتمد على ملفات إنجاز تعكس مسار الطالب",
      "يعيد استخدام نتائج التقويم في التدريس التالي",
    ],
    required: [
      "الاختبارات الشهرية",
      "الواجبات",
      "المناقشة والمشاركة",
      "الاختبارات التشخيصية",
      "أوراق العمل",
      "المشاريع",
      "ملفات الإنجاز",
      "التقويم التكويني",
      "التقويم الختامي",
    ],
    impact: "صورة شاملة عن تعلم كل طالب من زوايا متعددة، وقرارات تعديلات مستندة إلى أدلة لا انطباعات.",
    reflection: "كل سؤال أتدبره قبل طرحه سؤالا آخر: أي وجه من التعلم يكشف هذا السؤال؟",
    proofs: ["بنوك أسئلة متعددة النمط", "ملف إنجاز نموذجي"],
    reports: ["تقرير أساليب التقويم المعتمدة"],
    icon: "scale",
  },
];

/* ===================== شواهد نموذجية ===================== */
const SEED_EVIDENCE: Evidence[] = [
  { id: "e01", title: "سجل الحضور والانصراف الإلكتروني – الفصل الأول", desc: "استخراج رسمي من نظام مدرستي يوثق انتظام الدوام طوال الفصل.", type: "PDF", date: "2025-09-15", criterionId: 1, subject: "اللغة العربية", semester: "الفصل الأول", notes: "بدون غياب أو تأخير." },
  { id: "e02", title: "صور مناوبات الأسبوع الثالث", desc: "توثيق فوتوغرافي لمناوبة الساحة صباحية.", type: "صورة", date: "2025-10-02", criterionId: 1, subject: "اللغة العربية", semester: "الفصل الأول", image: IMG.project },
  { id: "e03", title: "فيديو الإذاعة المدرسية – الأسبوع السادس", desc: "تسجيل لمشاركتي في تقديم فقرة التعبير الأسبوعية.", type: "فيديو", date: "2025-10-20", criterionId: 1, subject: "اللغة العربية", semester: "الفصل الأول", file: { name: "idhaa-asm6.mp4" } },
  { id: "e04", title: "محضر اجتماع مجتمع التعلم المهني", desc: "محضر اجتماع شهري مع ملخص المخرجات المتفق عليها.", type: "PDF", date: "2025-11-12", criterionId: 2, subject: "اللغة العربية", semester: "الفصل الأول" },
  { id: "e05", title: "سجل تبادل الزيارات الصفية", desc: "4 زيارات منفذة واستقبال زيارتين، مع نماذج الملاحظة.", type: "Word", date: "2025-11-30", criterionId: 2, subject: "اللغة العربية", semester: "الفصل الأول" },
  { id: "e06", title: "توثيق التعاون مع الزملاء في النشاط الثقافي", desc: "صور من إعداد مشترك لمعرض التعبير.", type: "صورة", date: "2025-12-05", criterionId: 2, subject: "اللغة العربية", semester: "الفصل الأول", image: IMG.engage },
  { id: "e07", title: "أرشيف التواصل مع أولياء الأمور", desc: "روابط لرسائل المنصة الرسمية خلال الفصل الأول.", type: "رابط", date: "2025-12-15", criterionId: 3, subject: "اللغة العربية", semester: "الفصل الأول", link: "https://madrasi.example.com/messages" },
  { id: "e08", title: "الخطط العلاجية للطلاب المحتاجين للدعم", desc: "خطتان فرديتان بمعايير نجاح ومواعيد إعادة قياس.", type: "PDF", date: "2026-01-10", criterionId: 3, subject: "اللغة العربية", semester: "الفصل الثاني" },
  { id: "e09", title: "إشعارات الطلاب – الاختبار الشهري الثاني", desc: "قائمة إرسال الإشعارات مع نسب الاطلاع.", type: "Excel", date: "2026-01-18", criterionId: 3, subject: "اللغة العربية", semester: "الفصل الثاني" },
  { id: "e10", title: "مخطط حصة التعلم التعاوني «بنائات الكلام»", desc: "خطة الحصة مع أدوار المجموعات وأدوات الرصد.", type: "PowerPoint", date: "2025-09-28", criterionId: 4, subject: "اللغة العربية", semester: "الفصل الأول", image: IMG.coop },
  { id: "e11", title: "فيديو حصة المناقشة «فن النقاش»", desc: "تسجيل مقتطف من حصة نموذجية بحضور زملاء المادة.", type: "فيديو", date: "2025-10-27", criterionId: 4, subject: "اللغة العربية", semester: "الفصل الأول", image: IMG.discuss, file: { name: "discussion-lesson.mp4" } },
  { id: "e12", title: "صور حصة التعلم بالاستقصاء", desc: "وثائق استقصائية حول النص الشعري مع أسئلة المفتاح.", type: "صورة", date: "2025-11-18", criterionId: 4, subject: "اللغة العربية", semester: "الفصل الأول", image: IMG.digital },
  { id: "e13", title: "تحليل نتائج الاختبار الشهري الأول", desc: "جدول تحليلي بالمستويات والمحتوى الأضعف.", type: "Excel", date: "2025-10-12", criterionId: 5, subject: "اللغة العربية", semester: "الفصل الأول" },
  { id: "e14", title: "مقارنة نتائج الطلاب قبل وبعد التدخل", desc: "مصفوفة مقارنة لعينة 26 طالبًا بعد التدخل العلاجي.", type: "PDF", date: "2026-02-08", criterionId: 5, subject: "اللغة العربية", semester: "الفصل الثاني", image: IMG.support },
  { id: "e15", title: "برنامج إثرائي «قادة الكتابة» للمتفوقين", desc: "برنامج 8 أسابيع مع مهام ومحفزات ونماذج إنتاج.", type: "Word", date: "2026-01-22", criterionId: 5, subject: "اللغة العربية", semester: "الفصل الثاني" },
  { id: "e16", title: "الخطة الفصلية المعتمدة", desc: "الخطة المعتمدة من قسم اللغة العربية مع موافقة الإدارة.", type: "PDF", date: "2025-09-05", criterionId: 6, subject: "اللغة العربية", semester: "الفصل الأول" },
  { id: "e17", title: "جدول توزيع المنهج على الأسابيع", desc: "توزيع مرنة تراعي الاختبارات والعطلات.", type: "Excel", date: "2025-09-05", criterionId: 6, subject: "اللغة العربية", semester: "الفصل الأول" },
  { id: "e18", title: "نماذج تحضير دروس وأوراق عمل", desc: "مجموعة من 6 تحضيرات مع أوراقها المرفقة.", type: "PowerPoint", date: "2025-11-02", criterionId: 6, subject: "اللغة العربية", semester: "الفصل الأول" },
  { id: "e19", title: "عروض تفاعلية على منصة التعلم", desc: "روابط لعروض تفاعلية مدمجة في 4 حصص.", type: "رابط", date: "2025-10-10", criterionId: 7, subject: "اللغة العربية", semester: "الفصل الأول", link: "https://learn.example.com/interactive" },
  { id: "e20", title: "اختبار إلكتروني «قواعد النحو»", desc: "اختبار تفاعلي بنمطين مع تحليل فوري للنتائج.", type: "رابط", date: "2026-01-25", criterionId: 7, subject: "اللغة العربية", semester: "الفصل الثاني", link: "https://quiz.example.com/nahw" },
  { id: "e21", title: "أوراق عمل رقمية بأسئلة تفاعلية", desc: "3 أوراق عمل بتقنية السحب والإفلات مع مفتاح تصحيح.", type: "PDF", date: "2026-02-02", criterionId: 7, subject: "اللغة العربية", semester: "الفصل الثاني" },
  { id: "e22", title: "صور البيئة الصفية – ركن القراءة", desc: "توثيق للركن قبل الإحداث وتطويره.", type: "صورة", date: "2025-09-12", criterionId: 8, subject: "اللغة العربية", semester: "الفصل الأول", image: IMG.env },
  { id: "e23", title: "توثيق الممارسات الصفية – إدارة التفاعل", desc: "ملاحظة ذاتية مصورة لحصتين مع تحليل.", type: "صورة", date: "2025-11-25", criterionId: 9, subject: "اللغة العربية", semester: "الفصل الأول", image: IMG.interaction },
  { id: "e24", title: "الاختبار التشخيصي البادئ", desc: "بنك 40 سؤالًا يغطي مهارات الفصلين.", type: "PDF", date: "2025-09-08", criterionId: 10, subject: "اللغة العربية", semester: "الفصل الأول" },
  { id: "e25", title: "تصنيف الطلاب حسب المستويات", desc: "جدول تصنيف (متقدم / متوسط / يحتاج دعم) مع المعايير.", type: "Excel", date: "2025-09-20", criterionId: 10, subject: "اللغة العربية", semester: "الفصل الأول" },
  { id: "e26", title: "ملف إنجاز طالب «نموذج»", desc: "ملف متكامل يوثق مسار طالب من التشخيص حتى الختام.", type: "PDF", date: "2026-02-10", criterionId: 11, subject: "اللغة العربية", semester: "الفصل الثاني" },
];

/* ===================== الممارسات ===================== */
const SEED_PRACTICES: Practice[] = [
  { id: "p1", title: "درس نموذجي: «فن النقاش الموجه»", category: "دروس نموذجية", desc: "درس نموذجي استضاف 6 معلمين من مواد متعددة، بُني على نقاش موجّه حول نص أدبي، مع بطاقات أدوار وتقييم أدائي.", goal: "تحويل الطالب من متلقٍّ إلى حاجج يقدم حجته بالأدلة.", strategy: "المناقشة الموجهة + بطاقات الأدوار", impact: "اعتمد أسلوب بطاقات الأدوار لاحقًا في 3 حصص، وارتفعت جودة الحجج الكتابية في إنتاج أسبوعين.", image: IMG.discuss, files: [{ name: "خطة-النقاش.pptx", type: "PowerPoint" }, { name: "بطاقات-الأدوار.pdf", type: "PDF" }], date: "2025-10-27" },
  { id: "p2", title: "نشاط «المتعلم الصغير»", category: "تعلم تعاوني", desc: "يقدم كل طالب لمجموعته قاعدة نحوية في 3 دقائق بعد تدريب قصير، ضمن بنية تعلم يعلّم بعضنا بعضًا.", goal: "تثبيت التعلم عبر التعليم، وبناء الثقة في التعبير الشفهي.", strategy: "التعلم التعاوني ( Peer Teaching )", impact: "تحسن الأداء الشفهي لدى 11 طالبًا من أضعف الأصوات في الصف.", image: IMG.coop, files: [{ name: "مخطط-النشاط.pdf", type: "PDF" }], date: "2025-11-10" },
  { id: "p3", title: "حصة «لغة الضاد التفاعلية»", category: "تعلم رقمي", desc: "حصة على المنصة التعليمية بتقنية الألعاب: بطاقات مراجعة، سباق فرق، وفورية تصحيح فوري.", goal: "رفع الاستجابة الصفية إلى 100% خلال التمارين.", strategy: "التعلم الرقمي + الألعاب التعليمية", impact: "متوسط الاستجابة في التمارين الرقمية 94% مقابل 61% بالورق.", image: IMG.digital, files: [{ name: "روابط-الحصة.docx", type: "Word" }], date: "2025-12-01" },
  { id: "p4", title: "مشروع «الصحيفة الصفية الرقمية»", category: "مشاريع الطلاب", desc: "مشروع فصلي: يكتب الطلاب ويحررون ويصممون صحيفة رقمية تعكس مهاراتهم اللغوية عبر 6 أعداد.", goal: "دمج مهارات الكتابة والتحرير والتصميم في منتج حقيقي.", strategy: "التعلم بالمشاريع", impact: "نشر العدد الأخير على قناة المدرسة، وشارك فيه 18 طالبًا بإنتاج 24 مادة.", image: IMG.project, files: [{ name: "دليل-المشروع.pdf", type: "PDF" }, { name: "قالب-الصحيفة.pptx", type: "PowerPoint" }], date: "2026-02-05" },
  { id: "p5", title: "مبادرة «ركن القراءة الحي»", category: "مبادرات", desc: "تحويل ركن القراءة إلى محطة أسبوعية بنظام استعارة داخلي وقائمة رغبة يحددها الطلاب.", goal: "بناء عادة قراءة يومية 10 دقائق.", strategy: "التدريب على العادات + الخيار الذاتي", impact: "ارتفاع مؤشر القراءة الطوعية من 22% إلى 58% بعد 8 أسابيع.", image: IMG.env, files: [{ name: "لوائح-الركن.docx", type: "Word" }], date: "2025-09-12" },
  { id: "p6", title: "«تحدي الكتابة الإبداعية»", category: "مسابقات لغوية", desc: "مسابقة داخلية على جولتين (قصص قصيرة ثم خطابة) بنظام تحكيم من زملاء وطلاب.", goal: "رفع سقف الطموح الإبداعي لدى الطلاب.", strategy: "المسابقة التحفيزية + التحكيم النافذ", impact: "تأهل 3 طلاب لتمثيل المدرسة في أولمبياد اللغة العربية.", image: IMG.contest, files: [{ name: "لوائح-المسابقة.pdf", type: "PDF" }], date: "2025-11-20" },
];

/* ===================== التطوير المهني ===================== */
const SEED_DEV: DevItem[] = [
  { id: "d1", kind: "دورة", title: "التعلم النشط وأساليبه", org: "مدار", date: "2025-08-14", hours: 24, cert: "شهادة إتمام معتمدة", link: "https://madar.example.com/c1" },
  { id: "d2", kind: "ورشة عمل", title: "الذكاء الاصطناعي في التعليم", org: "مشروع قائد", date: "2026-01-18", hours: 16, cert: "شهادة ورشة عملية" },
  { id: "d3", kind: "مؤتمر", title: "مؤتمر التعليم الرقمي – جلسة «مستقبل التقويم»", org: "مركز المؤتمرات الوطني", date: "2025-12-09", hours: 8, cert: "شهادة حضور" },
  { id: "d4", kind: "مجتمع تعلم", title: "مجتمع اللغة العربية المهني – عضو فعّال", org: "منصة مدرستي", date: "2025-10-01", hours: 30, cert: "سجل مشاركات موثق" },
  { id: "d5", kind: "بحث", title: "أثر التعلم التعاوني على التحصيل اللغوي", org: "بحث تربوي ذاتي", date: "2026-02-14", hours: 40, cert: "نسخة البحث النهائية" },
];

/* ===================== الإنجازات ===================== */
const SEED_ACH: Achievement[] = [
  { id: "a1", kind: "تكريم", title: "تكريم «المعلم المميز» من الإدارة المدرسية", date: "2025-12-20", desc: "تكريم عن التزام مهني ومشاركة فاعلة في مجتمعات التعلم." },
  { id: "a2", kind: "مسابقة", title: "المركز الثاني في مسابقة أفضل درس تقويمي", date: "2026-01-30", desc: "درس تقويمي تفاعلي حاز المركز الثاني على مستوى القطاع." },
  { id: "a3", kind: "مبادرة", title: "إطلاق مبادرة «ركن القراءة الحي»", date: "2025-09-12", desc: "مبادرة مدرسية مستمرة أثّرت في عادات القراءة داخل الصف." },
  { id: "a4", kind: "مشروع", title: "مشروع «الصحيفة الصفية الرقمية»", date: "2026-02-05", desc: "مشروع إنتاجي جماعي نُشر على قناة المدرسة الرسمية." },
  { id: "a5", kind: "إنجاز طلابي", title: "3 طلاب في أولمبياد اللغة العربية", date: "2025-11-20", desc: "تأهل 3 طلاب لتمثيل المدرسة بناءً على نتائج التحدي الداخلي.", image: IMG.support },
  { id: "a6", kind: "مشاركة مهنية", title: "ورشة «صناعة أوراق العمل الرقمية» في معرض التعليم", date: "2025-12-10", desc: "ورشة تقديمية لزملاء من 4 مدارس ضمن فعاليات المعرض." },
];

/* ===================== الخطة التعليمية ===================== */
const SEED_PLAN: State["plan"] = {
  t1: [
    { unit: "الوحدة الأولى: في رحاب العربية", content: "مراجعة بنائات الكلمة (اسم / فعل / حرف)", weeks: "الأسبوع 1 – 2", hours: 10, activities: "بطاقات مراجعة، نقاش موجه، اختبار تشخيصي", status: "منفذة" },
    { unit: "الوحدة الثانية: فن التعبير", content: "أنواع النص السردي وبناء الفكرة", weeks: "الأسبوع 3 – 5", hours: 14, activities: "متعلم صغير، مسودة أولى، مراجعة أقران", status: "منفذة" },
    { unit: "الوحدة الثالثة: إجازة النص", content: "تحليل القصيدة: موضوعها ووسائلها", weeks: "الأسبوع 6 – 8", hours: 12, activities: "استقصاء جماعي، خريطة ذهنية، اختبار شهري", status: "منفذة" },
    { unit: "الوحدة الرابعة: قواعد دقيقة", content: "المبتدأ والخبر وحالات الرفع", weeks: "الأسبوع 9 – 11", hours: 13, activities: "ألعاب رقمية، أوراق عمل متدرجة", status: "منفذة" },
    { unit: "الوحدة الخامسة: لغة الإعلام", content: "الكتابة الإخبارية ومعايير المصداقية", weeks: "الأسبوع 12 – 13", hours: 10, activities: "مشروع الصحيفة، نشر العدد الثالث", status: "منفذة" },
  ],
  t2: [
    { unit: "الوحدة الأولى: النص النقدي", content: "عناصر المقال النقدي وحجج الكاتب", weeks: "الأسبوع 14 – 16", hours: 12, activities: "نقاش تحكيمي، تحليل مقارنة", status: "قيد التنفيذ" },
    { unit: "الوحدة الثانية: بلاغة الخطاب", content: "البديع ومقامات التوظيف", weeks: "الأسبوع 17 – 19", hours: 12, activities: "معرض إنتاج، تقييم أقران", status: "مجدولة" },
    { unit: "الوحدة الثالثة: ورشة الكتابة", content: "من الفكرة إلى النص النهائي", weeks: "الأسبوع 20 – 22", hours: 13, activities: "مسودة متدرجة، تدقيق ذاتي", status: "مجدولة" },
    { unit: "الوحدة الرابعة: مراجعة ختامية", content: "تكامل المهارات واستعداد للختامي", weeks: "الأسبوع 23 – 24", hours: 11, activities: "اختبارات تدريبية، خطة علاجية مركزة", status: "مجدولة" },
  ],
};

const SEED_WORKS: PlanWork[] = [
  { id: "w1", title: "ورقة عمل «بنائات الكلام»", type: "ورقة عمل", week: "الأسبوع 2" },
  { id: "w2", title: "واجب كتابي: مشهد سردي قصير", type: "واجب", week: "الأسبوع 4" },
  { id: "w3", title: "نشاط إثرائي: تحليل قصيدة", type: "نشاط إثرائي", week: "الأسبوع 7" },
  { id: "w4", title: "اختبار شهري – الوحدة الثالثة", type: "اختبار", week: "الأسبوع 8" },
  { id: "w5", title: "ورقة عمل رقمية: حالة الرفع", type: "ورقة عمل", week: "الأسبوع 10" },
];

/* ===================== بيانات النتائج ===================== */
const SEED_STUDENT: StudentData = {
  before: 68.4,
  after: 84.2,
  students: 26,
  excelling: 9,
  support: 4,
  subjects: [
    { name: "النحو", before: 61.2, after: 80.5 },
    { name: "النصوص", before: 70.1, after: 85.3 },
    { name: "الأدب", before: 74.6, after: 88.2 },
    { name: "البلاغة", before: 66.9, after: 82.4 },
  ],
  trend: [
    { label: "البداية", value: 66 },
    { label: "منتصف ف1", value: 72 },
    { label: "نهاية ف1", value: 78 },
    { label: "منتصف ف2", value: 82 },
    { label: "الختامي", value: 86 },
  ],
  levels: [
    { label: "متقدم (90+)", value: 40 },
    { label: "جيد (75–89)", value: 42 },
    { label: "يحتاج دعم (أقل من 75)", value: 18 },
  ],
};

/* ===================== الحالة الابتدائية ===================== */
export const INITIAL_STATE: State = {
  teacher: {
    name: "سعيد عزيز ال مرعي",
    specialty: "اللغة العربية",
    school: "مدرسة النور الثانوية",
    year: "1447هـ – 2025/2026م",
    photo: IMG.portrait,
    degree: "بكالوريوس لغة عربية – ماجستير تقويم تعليمي (قيد الإتمام)",
    license: "رخصة مهنية سارية – رقم الترخيص: 2047-118-334",
    experience: 9,
    skills: ["تخطيط الدروس", "التقويم المبنِي على الأدلة", "إدارة الصف", "تقنيات التعليم", "التعلم التعاوني", "الذكاء الاصطناعي التعليمي", "صناعة الاختبارات", "إدارة المشاريع الطلابية"],
    interests: ["مجتمعات التعلم المهني", "التعليم التفاعلي", "تطوير أدوات التقويم", "ريادة التعلم الرقمي"],
  },
  criteria: SEED_CRITERIA,
  evidence: SEED_EVIDENCE,
  practices: SEED_PRACTICES,
  development: SEED_DEV,
  achievements: SEED_ACH,
  plan: SEED_PLAN,
  works: SEED_WORKS,
  student: SEED_STUDENT,
  files: [
    { id: "f1", name: "الخطة-الفصلية-1447.pdf", kind: "ملف", size: "820 ك.ب", date: "2025-09-05" },
    { id: "f2", name: "صور-ركن-القراءة.jpg", kind: "صورة", size: "1.2 م.ب", date: "2025-09-12" },
  ],
};

/* ===================== الحسابات ===================== */
export function criterionStatus(c: Criterion, evidence: Evidence[]): DocStatus {
  const n = evidence.filter((e) => e.criterionId === c.id).length;
  if (n === 0) return "غير موثق";
  if (n < 3) return "قيد التوثيق";
  return "موثق";
}

export interface CompletionPart {
  key: string;
  label: string;
  value: number;
  target: number;
  weight: number;
}

export function computeCompletion(s: State): { total: number; parts: CompletionPart[] } {
  const t = s.teacher;
  const personalFields = [t.name, t.specialty, t.degree, t.school, t.license, t.photo, String(t.experience || 0), t.skills.length ? "y" : ""];
  const personal = personalFields.filter((x) => x.trim() !== "").length;
  const documented = s.criteria.filter((c) => criterionStatus(c, s.evidence) === "موثق").length;
  const parts: CompletionPart[] = [
    { key: "personal", label: "البيانات الشخصية", value: personal, target: 8, weight: 15 },
    { key: "criteria", label: "توثيق المعايير", value: documented, target: s.criteria.length, weight: 25 },
    { key: "evidence", label: "الشواهد المرفوعة", value: Math.min(s.evidence.length, 30), target: 30, weight: 20 },
    { key: "dev", label: "التطوير المهني", value: Math.min(s.development.length, 8), target: 8, weight: 10 },
    { key: "practices", label: "الممارسات المهنية", value: Math.min(s.practices.length, 8), target: 8, weight: 10 },
    { key: "achievements", label: "الإنجازات", value: Math.min(s.achievements.length, 7), target: 7, weight: 10 },
    { key: "reports", label: "التقارير الجاهزة", value: 6, target: 6, weight: 10 },
  ];
  const total = Math.floor(parts.reduce((sum, p) => sum + (p.value / p.target) * p.weight, 0));
  return { total: Math.min(100, total), parts };
}

export function computeStats(s: State) {
  const courses = s.development.filter((d) => d.kind === "دورة" || d.kind === "ورشة عمل").length;
  const initiatives =
    s.development.filter((d) => d.kind === "مبادرة").length + s.achievements.filter((a) => a.kind === "مبادرة").length;
  const projects = s.practices.filter((p) => p.category === "مشاريع الطلاب").length + s.achievements.filter((a) => a.kind === "مشروع").length;
  return {
    experience: s.teacher.experience,
    courses,
    initiatives,
    evidence: s.evidence.length,
    activities: s.practices.length,
    projects,
    achievements: s.achievements.length,
  };
}

export function downloadText(filename: string, content: string, mime = "text/plain") {
  const blob = new Blob(["\ufeff" + content], { type: `${mime};charset=utf-8` });
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = filename;
  a.click();
  setTimeout(() => URL.revokeObjectURL(url), 4000);
}
