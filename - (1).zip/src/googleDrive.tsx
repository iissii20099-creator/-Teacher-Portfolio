/**
 * تكامل Google Drive — معزول بالكامل في هذا الملف.
 * يدير: مفتاح التفعيل، الـ Client ID، ربط الحساب، تغيير الحساب، إنهاء الجلسة، حذف الحساب، الرفع والبحث.
 * للتعطيل من الواجهة: لوحة التحكم ← النسخ والإعدادات ← «ربط Google Drive» (إيقاف).
 * للإزالة من الكود: احذف هذا الملف ثم أزل استيراده واستخدامه من src/App.tsx و src/pages/Dashboard.tsx و src/pages/Evidence.tsx.
 */
import { createContext, useCallback, useContext, useEffect, useRef, useState, type ReactNode } from "react";

declare global {
  interface Window {
    google?: any;
  }
}

const LS_KEY = "gdrive-client-id";
const LS_ENABLED = "gdrive-enabled";
const LS_ACCOUNT = "gdrive-account";
const SCOPES = "https://www.googleapis.com/auth/drive";
const DRIVE = "https://www.googleapis.com/drive/v3";
const UPLOAD = "https://www.googleapis.com/upload/drive/v3";
const FOLDER_MIME = "application/vnd.google-apps.folder";

/** يستخرج معرّف مجلد/ملف من أي صيغة رابط في Drive */
export function parseDriveId(input: string): string | null {
  const s = (input || "").trim();
  if (!s) return null;
  if (/^[\w-]{15,}$/.test(s)) return s;
  const patterns = [/\/folders\/([\w-]{15,})/, /[?&]id=([\w-]{15,})/, /\/file\/d\/([\w-]{15,})/, /\/document\/d\/([\w-]{15,})/, /#folders\/([\w-]{15,})/];
  for (const p of patterns) {
    const m = s.match(p);
    if (m) return m[1];
  }
  return null;
}

async function toBlob(body: Blob | string): Promise<{ blob: Blob; mime: string }> {
  if (body instanceof Blob) return { blob: body, mime: body.type || "application/octet-stream" };
  if (body.startsWith("data:")) {
    const mime = body.slice(5, body.indexOf(";")) || "application/octet-stream";
    const r = await fetch(body);
    return { blob: await r.blob(), mime };
  }
  return { blob: new Blob([body], { type: "text/plain;charset=utf-8" }), mime: "text/plain;charset=utf-8" };
}

export interface DriveUser {
  name: string;
  email: string;
  picture: string;
  quota?: { limit: number; usage: number };
}

export interface DriveFile {
  id: string;
  name: string;
  mimeType: string;
  size?: string;
  webViewLink: string;
  thumbnailLink?: string;
  modifiedTime?: string;
}

interface DriveApi {
  enabled: boolean;
  setEnabled: (v: boolean) => void;
  clientId: string;
  clientIdValid: boolean;
  saveClientId: (v: string) => void;
  forgetClientId: () => void;
  ready: boolean;
  signedIn: boolean;
  account: DriveUser | null;
  busy: boolean;
  error: string;
  clearError: () => void;
  signIn: (opts?: { selectAccount?: boolean }) => Promise<void>;
  signOut: () => void;
  deleteAccount: () => void;
  refreshAccount: () => Promise<void>;
  upload: (file: File) => Promise<DriveFile>;
  search: (q?: string) => Promise<DriveFile[]>;
  /** استدعاء Drive API عام — يعيد JSON */
  api: <T = any>(url: string, init?: RequestInit) => Promise<T>;
  /** استدعاء يعيد النص الخام (لتحميل محتوى ملف) */
  apiText: (url: string) => Promise<string>;
  /** إنشاء مجلد داخل أب محدد */
  mkdir: (name: string, parentId: string) => Promise<DriveFile>;
  /** يبحث عن ابن بالاسم داخل أب (مجلد أو ملف) */
  findChild: (parentId: string, name: string, folderOnly?: boolean) => Promise<DriveFile | null>;
  /** يوجد المجلد أو ينشئه */
  ensureChild: (parentId: string, name: string) => Promise<DriveFile>;
  /** ينقل ملفاً إلى مجلد آخر */
  moveTo: (fileId: string, newParentId: string) => Promise<void>;
  /** يرفع محتوى (نص أو Blob أو data URL) كملف داخل مجلد */
  uploadBytes: (name: string, mimeType: string, body: Blob | string, parentId?: string) => Promise<DriveFile>;
}

const Ctx = createContext<DriveApi | null>(null);

export function useDrive(): DriveApi {
  const c = useContext(Ctx);
  if (!c) throw new Error("useDrive must be used inside DriveProvider");
  return c;
}

export const isDriveUrl = (s?: string | null) => !!s && s.includes("drive.google.com");

function readAccount(): DriveUser | null {
  try {
    const raw = localStorage.getItem(LS_ACCOUNT);
    if (!raw) return null;
    const p = JSON.parse(raw);
    return p && typeof p.name === "string" ? (p as DriveUser) : null;
  } catch {
    return null;
  }
}

/* ترجمة رموز أخطاء Google إلى تشخيص عربي دقيق */
export const AUTH_ERRORS: Record<string, string> = {
  origin_mismatch: "أصل هذا الموقع غير مُدرج في Google Cloud — أضف العنوان المطلوب حرفياً في لوحة التشخيص أدناه إلى Authorized JavaScript origins",
  idpiframe_initialization_failed: "تعذّر تهيئة نافذة Google — غالباً بسبب حجب ملفات تعريف الارتباط لجهات خارجية في المتصفح، أو لأن أصل الموقع غير مُدرج",
  invalid_client: "الـ Client ID غير صحيح أو محذوف — تأكد أنه من نوع Web application ومن نفس المشروع الذي فعّلت فيه Drive API",
  unauthorized_client: "هذا الـ Client ID غير مصرّح له بهذا التدفق — أنشئ OAuth client ID بنوع Web application",
  invalid_request: "طلب المصادقة مرفوض — تحقق من خلو الـ Client ID من المسافات والأسطر الزائدة عند اللصق",
  access_denied: "تم رفض الإذن من النافذة — أعد المحاولة واختر حسابك ثم اضغط Allow",
  popup_failed_to_open: "المتصفح حجب نافذة Google — اسمح بالنوافذ المنبثقة لهذا الموقع من شريط العنوان ثم أعد المحاولة",
  popup_closed: "أُغلقت نافذة Google قبل إتمام الدخول — أعد المحاولة وأكمل اختيار الحساب حتى النهاية",
  popup_failed_to_load: "تعذّر تحميل نافذة Google — تحقق من اتصال الإنترنت أو من إضافة تقيدها",
  user_logged_out: "لا يوجد حساب Google مسجَّل الدخول في هذا المتصفح — افتح accounts.google.com وسجّل الدخول أولاً",
  unknown: "فشل غير محدد من Google — راجع قائمة التشخيص أدناه للتحقق من الإعدادات",
};

export function describeAuthError(code: string): string {
  const msg = AUTH_ERRORS[code] ?? AUTH_ERRORS.unknown;
  return `${msg} — رمز الخطأ: ${code}`;
}

export function DriveProvider({ children }: { children: ReactNode }) {
  const [clientId, setClientId] = useState(() => localStorage.getItem(LS_KEY) ?? "");
  const [enabled, setEnabledState] = useState<boolean>(() => {
    const raw = localStorage.getItem(LS_ENABLED);
    if (raw !== null) return raw === "1";
    return !!localStorage.getItem(LS_KEY);
  });
  const [ready, setReady] = useState(false);
  const [signedIn, setSignedIn] = useState(false);
  const [saved, setSaved] = useState<DriveUser | null>(readAccount);
  const [live, setLive] = useState<DriveUser | null>(null);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState("");
  const tokenClient = useRef<any>(null);
  const hasToken = useRef(false);

  const account = live ?? saved;
  const clientIdValid = /^[0-9]+-[a-z0-9]+\.apps\.googleusercontent\.com$/i.test(clientId.trim());

  const persistAccount = useCallback((u: DriveUser) => {
    setLive(u);
    setSaved(u);
    try {
      localStorage.setItem(LS_ACCOUNT, JSON.stringify(u));
    } catch {
      /* تجاهل */
    }
  }, []);

  /* إنهاء الجلسة بصمت (خروج / تعطيل / حذف حساب) */
  const releaseSession = useCallback(() => {
    try {
      tokenClient.current?.revokeAccess?.();
    } catch {
      /* تجاهل */
    }
    hasToken.current = false;
    tokenClient.current = null;
    setSignedIn(false);
    setLive(null);
  }, []);

  const saveClientId = useCallback((v: string) => {
    const clean = v.trim();
    setClientId(clean);
    localStorage.setItem(LS_KEY, clean);
    setEnabledState(true);
    localStorage.setItem(LS_ENABLED, "1");
    tokenClient.current = null;
    setError("");
  }, []);

  /* مفتاح التشغيل/الإيقاف الكامل — يُخفي كل عناصر الربط من الموقع */
  const setEnabled = useCallback(
    (v: boolean) => {
      setEnabledState(v);
      localStorage.setItem(LS_ENABLED, v ? "1" : "0");
      if (!v) {
        releaseSession();
        setError("");
      }
    },
    [releaseSession]
  );

  /* مسح الـ Client ID وإيقاف الربط نهائياً */
  const forgetClientId = useCallback(() => {
    releaseSession();
    setClientId("");
    localStorage.removeItem(LS_KEY);
    setSaved(null);
    localStorage.removeItem(LS_ACCOUNT);
    setEnabledState(false);
    localStorage.setItem(LS_ENABLED, "0");
    setError("");
  }, [releaseSession]);

  /* حذف الحساب المرتبط فقط (يبقى Client ID والتفعيل كما هما) */
  const deleteAccount = useCallback(() => {
    releaseSession();
    setSaved(null);
    localStorage.removeItem(LS_ACCOUNT);
    setError("");
  }, [releaseSession]);

  /* تحميل خدمة Google فقط عند التفعيل ووجود Client ID */
  useEffect(() => {
    if (!clientId || !enabled) {
      setReady(false);
      return;
    }
    if (window.google?.accounts?.oauth2) {
      setReady(true);
      return;
    }
    setReady(false);
    const s = document.createElement("script");
    s.src = "https://accounts.google.com/gsi/client";
    s.async = true;
    s.onload = () => setReady(true);
    s.onerror = () => setError("تعذّر تحميل خدمة Google — تحقق من اتصال الإنترنت ثم أعد المحاولة.");
    document.head.appendChild(s);
  }, [clientId, enabled]);

  /* طلب رمز الوصول — مع خيار إظهار قائمة اختيار الحساب */
  const requestToken = useCallback(
    (prompt: string) =>
      new Promise<string>((res, rej) => {
        if (location.protocol === "file:") {
          rej(new Error("مصادقة Google لا تعمل من ملف محلي (file://) — افتح الموقع عبر رابط https أو localhost ثم أعد المحاولة."));
          return;
        }
        if (!window.isSecureContext) {
          rej(new Error(`المتصفح يحجب مصادقة Google لأن العنوان غير آمن (${location.protocol}//) — يلزم https أو localhost.`));
          return;
        }
        if (!window.google?.accounts?.oauth2) {
          rej(new Error("خدمة Google لم تكتمل جاهزيتها بعد — انتظر لحظات ثم أعد المحاولة."));
          return;
        }
        if (!tokenClient.current) {
          tokenClient.current = window.google.accounts.oauth2.initTokenClient({
            client_id: clientId,
            scope: SCOPES,
            callback: (r: any) => {
              if (r.error || !r.access_token) {
                rej(new Error(describeAuthError(String(r.error ?? "unknown"))));
                return;
              }
              hasToken.current = true;
              res(r.access_token);
            },
            error_callback: (e: any) => rej(new Error(describeAuthError(String(e?.type ?? "unknown")))),
          });
        }
        tokenClient.current.requestAccessToken({ prompt });
      }),
    [clientId]
  );

  const getAccessToken = useCallback(async () => {
    if (hasToken.current) {
      try {
        return await requestToken("");
      } catch {
        hasToken.current = false;
      }
    }
    return requestToken("consent");
  }, [requestToken]);

  const apiFetch = useCallback(
    async (url: string, init: RequestInit = {}) => {
      let token = await getAccessToken();
      let res = await fetch(url, { ...init, headers: { ...(init.headers || {}), Authorization: `Bearer ${token}` } });
      if (res.status === 401) {
        token = await getAccessToken();
        res = await fetch(url, { ...init, headers: { ...(init.headers || {}), Authorization: `Bearer ${token}` } });
      }
      if (!res.ok) {
        let msg = `خطأ من Google Drive (${res.status})`;
        try {
          msg = (await res.json())?.error?.message ?? msg;
        } catch {
          /* تجاهل */
        }
        throw new Error(msg);
      }
      return res.json();
    },
    [getAccessToken]
  );

  /* جلب بيانات الحساب والمساحة من Drive نفسه */
  const loadAccount = useCallback(async () => {
    try {
      const data = await apiFetch("https://www.googleapis.com/drive/v3/about?fields=user(displayName,emailAddress,photoLink),storageQuota(limit,usage)");
      const u = data?.user;
      if (u?.displayName) {
        persistAccount({
          name: u.displayName,
          email: u.emailAddress ?? "",
          picture: u.photoLink ?? "",
          quota: data.storageQuota?.limit
            ? { limit: Number(data.storageQuota.limit), usage: Number(data.storageQuota.usage ?? 0) }
            : undefined,
        });
      }
    } catch {
      /* لا نُفشل الدخول بسبب بيانات الحساب */
    }
  }, [apiFetch, persistAccount]);

  const signIn = useCallback(
    async (opts?: { selectAccount?: boolean }) => {
      setBusy(true);
      setError("");
      try {
        await requestToken(opts?.selectAccount ? "select_account consent" : hasToken.current ? "" : "consent");
        setSignedIn(true);
        await loadAccount();
        if (!live && !saved) persistAccount({ name: "حساب Google", email: "", picture: "" });
      } catch (e) {
        setError(e instanceof Error ? e.message : "فشل تسجيل الدخول في Google.");
        setSignedIn(false);
      } finally {
        setBusy(false);
      }
    },
    [requestToken, loadAccount, live, saved, persistAccount]
  );

  const signOut = useCallback(() => {
    releaseSession();
    setError("");
  }, [releaseSession]);

  const upload = useCallback(
    async (file: File) => {
      setError("");
      const boundary = `----gdrive${Date.now().toString(36)}`;
      const head = `--${boundary}\r\nContent-Type: application/json; charset=UTF-8\r\n\r\n`;
      const tail = `\r\n--${boundary}\r\nContent-Type: ${file.type || "application/octet-stream"}\r\n\r\n`;
      const end = `\r\n--${boundary}--`;
      const body = new Blob([head, JSON.stringify({ name: file.name }), tail, file, end]);
      const data = await apiFetch(
        `https://www.googleapis.com/upload/drive/v3/files?uploadType=multipart&fields=id,name,mimeType,size,webViewLink,thumbnailLink,createdTime`,
        { method: "POST", body, headers: { "Content-Type": `multipart/related; boundary=${boundary}` } }
      );
      return data as DriveFile;
    },
    [apiFetch]
  );

  const apiText = useCallback(
    async (url: string) => {
      let token = await getAccessToken();
      let res = await fetch(url, { headers: { Authorization: `Bearer ${token}` } });
      if (res.status === 401) {
        token = await getAccessToken();
        res = await fetch(url, { headers: { Authorization: `Bearer ${token}` } });
      }
      if (!res.ok) {
        let msg = `خطأ من Google Drive (${res.status})`;
        try {
          msg = (await res.json())?.error?.message ?? msg;
        } catch {
          /* تجاهل */
        }
        throw new Error(msg);
      }
      return res.text();
    },
    [getAccessToken]
  );

  /* ---------- عمليات المجلدات ---------- */
  const mkdir = useCallback(
    (name: string, parentId: string) =>
      apiFetch(`${DRIVE}/files`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ name, mimeType: FOLDER_MIME, parents: [parentId] }),
      }) as Promise<DriveFile>,
    [apiFetch]
  );

  const findChild = useCallback(
    async (parentId: string, name: string, folderOnly = true) => {
      const q = encodeURIComponent(
        `'${parentId}' in parents and name = '${name.replace(/'/g, "")}' and trashed = false${folderOnly ? ` and mimeType = '${FOLDER_MIME}'` : ""}`
      );
      const r = await apiFetch(`${DRIVE}/files?fields=files(id,name,mimeType,webViewLink)&pageSize=1&q=${q}`);
      return (r.files?.[0] ?? null) as DriveFile | null;
    },
    [apiFetch]
  );

  const ensureChild = useCallback(
    async (parentId: string, name: string) => (await findChild(parentId, name)) ?? (await mkdir(name, parentId)),
    [findChild, mkdir]
  );

  const moveTo = useCallback(
    async (fileId: string, newParentId: string) => {
      const cur = await apiFetch(`${DRIVE}/files/${fileId}?fields=parents`);
      const old = (cur.parents ?? []).join(",");
      const qs = old ? `addParents=${newParentId}&removeParents=${encodeURIComponent(old)}` : `addParents=${newParentId}`;
      await apiFetch(`${DRIVE}/files/${fileId}?${qs}&fields=id,parents`, { method: "PATCH" });
    },
    [apiFetch]
  );

  const uploadBytes = useCallback(
    async (name: string, mimeType: string, body: Blob | string, parentId?: string) => {
      const { blob, mime } = await toBlob(body);
      const boundary = `----tp${Date.now().toString(36)}${Math.random().toString(36).slice(2, 6)}`;
      const meta = JSON.stringify({ name, mimeType: mime || mimeType, ...(parentId ? { parents: [parentId] } : {}) });
      const parts = new Blob([
        `--${boundary}\r\nContent-Type: application/json; charset=UTF-8\r\n\r\n`,
        meta,
        `\r\n--${boundary}\r\nContent-Type: ${mime || mimeType}\r\n\r\n`,
        blob,
        `\r\n--${boundary}--`,
      ]);
      return (await apiFetch(`${UPLOAD}/files?uploadType=multipart`, {
        method: "POST",
        body: parts,
        headers: { "Content-Type": `multipart/related; boundary=${boundary}` },
      })) as DriveFile;
    },
    [apiFetch]
  );

  const search = useCallback(
    async (q?: string) => {
      const raw = (q ?? "").trim();
      let query: string;
      if (/^[a-zA-Z0-9_-]{20,}$/.test(raw)) query = `id = '${raw}'`;
      else if (raw) query = `name contains '${raw.replace(/'/g, "")}'`;
      else query = `modifiedTime > '2023-01-01T00:00:00'`;
      const data = await apiFetch(
        `https://www.googleapis.com/drive/v3/files?spaces=drive&pageSize=12&orderBy=modifiedTime%20desc&fields=files(id,name,mimeType,size,thumbnailLink,webViewLink,modifiedTime)&q=${encodeURIComponent(query)}`
      );
      return (data.files ?? []) as DriveFile[];
    },
    [apiFetch]
  );

  const value: DriveApi = {
    enabled,
    setEnabled,
    clientId,
    clientIdValid,
    saveClientId,
    forgetClientId,
    ready,
    signedIn,
    account,
    busy,
    error,
    clearError: () => setError(""),
    signIn,
    signOut,
    deleteAccount,
    refreshAccount: loadAccount,
    upload,
    search,
    api: apiFetch,
    apiText,
    mkdir,
    findChild,
    ensureChild,
    moveTo,
    uploadBytes,
  };

  return <Ctx.Provider value={value}>{children}</Ctx.Provider>;
}
