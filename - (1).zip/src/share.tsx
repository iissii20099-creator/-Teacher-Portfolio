/**
 * مركز النشر والحماية — ترميز الملف، القفل بكلمة مرور، وضع العرض، وتصدير نسخة مستقلة.
 */
import { createContext, useContext, type ReactNode } from "react";
import type { State } from "./data";

export interface LockData {
  salt: string;
  hash: string;
  at: string;
}

export interface Payload {
  v: 1;
  state: State;
  lock: LockData | null;
}

const LOCK_KEY = "tp-lock";
const UNLOCK_KEY = "tp-unlocked";

/* ===================== ترميز ثنائي آمن للرابط ===================== */
function b64urlEncode(bytes: Uint8Array) {
  let s = "";
  const chunk = 0x8000;
  for (let i = 0; i < bytes.length; i += chunk) {
    s += String.fromCharCode.apply(null, Array.from(bytes.subarray(i, i + chunk)) as unknown as number[]);
  }
  return btoa(s).replace(/\+/g, "-").replace(/\//g, "_").replace(/=+$/, "");
}

function b64urlDecode(str: string) {
  const b = str.replace(/-/g, "+").replace(/_/g, "/");
  const bin = atob(b + "=".repeat((4 - (b.length % 4)) % 4));
  const out = new Uint8Array(bin.length);
  for (let i = 0; i < bin.length; i++) out[i] = bin.charCodeAt(i);
  return out;
}

const CS = (): any => (globalThis as any).CompressionStream;
const DS = (): any => (globalThis as any).DecompressionStream;

/** ضغط آمن: يعود للبيانات الخام إن تعذّر الضغط بدل أن يفشل整个过程 */
async function gzipSafe(bytes: Uint8Array): Promise<Uint8Array> {
  const C = CS();
  if (!C) return bytes;
  try {
    if (typeof (Blob.prototype as any).stream !== "function") return bytes;
    const owned = bytes.slice();
    const stream = new Blob([owned.buffer as ArrayBuffer]).stream().pipeThrough(new C());
    const out = new Uint8Array(await new Response(stream).arrayBuffer());
    return out.byteLength > 0 ? out : bytes;
  } catch {
    return bytes;
  }
}

async function gunzipSafe(bytes: Uint8Array): Promise<Uint8Array> {
  const D = DS();
  if (bytes[0] !== 0x1f || bytes[1] !== 0x8b || !D) return bytes;
  try {
    if (typeof (Blob.prototype as any).stream !== "function") return bytes;
    const owned = bytes.slice();
    const stream = new Blob([owned.buffer as ArrayBuffer]).stream().pipeThrough(new D());
    return new Uint8Array(await new Response(stream).arrayBuffer());
  } catch {
    return bytes;
  }
}

export interface EncodeResult {
  code: string;
  rawBytes: number;
  outBytes: number;
  compressed: boolean;
  urlLength: number;
}

export async function encodePayload(p: Payload, base: string): Promise<EncodeResult> {
  const json = new TextEncoder().encode(JSON.stringify(p));
  const out = await gzipSafe(json);
  const code = b64urlEncode(out);
  return {
    code,
    rawBytes: json.byteLength,
    outBytes: out.byteLength,
    compressed: out.byteLength < json.byteLength,
    urlLength: base.length + 4 + code.length,
  };
}

export async function decodePayload(code: string): Promise<Payload> {
  const raw = b64urlDecode(code);
  const json = await gunzipSafe(raw);
  const parsed = JSON.parse(new TextDecoder().decode(json));
  if (!parsed || !parsed.state || !parsed.state.teacher) throw new Error("البيانات المضمّنة في الرابط غير صالحة");
  return parsed as Payload;
}

/* ===================== كلمة المرور ===================== */
function toHex(buf: ArrayBuffer) {
  return Array.from(new Uint8Array(buf))
    .map((b) => b.toString(16).padStart(2, "0"))
    .join("");
}

function weakHash(s: string) {
  let h1 = 0x811c9dc5;
  let h2 = 0x1000193;
  for (let i = 0; i < s.length; i++) {
    h1 = (h1 ^ s.charCodeAt(i)) * 16777619 >>> 0;
    h2 = (h2 + s.charCodeAt(i) * (i + 7)) >>> 0;
  }
  return `${h1.toString(16)}${h2.toString(16)}`;
}

export async function hashPassword(pw: string, salt?: string): Promise<LockData> {
  const s = salt ?? (typeof globalThis.crypto?.randomUUID === "function" ? crypto.randomUUID() : `s${Date.now()}${Math.random()}`);
  const secret = `${s}::${pw}`;
  let hash: string;
  if (typeof globalThis.crypto?.subtle?.digest === "function") {
    try {
      hash = toHex(await crypto.subtle.digest("SHA-256", new TextEncoder().encode(secret)));
    } catch {
      hash = weakHash(secret);
    }
  } else {
    hash = weakHash(secret);
  }
  return { salt: s, hash, at: new Date().toISOString() };
}

export async function verifyPassword(pw: string, lock: LockData): Promise<boolean> {
  const t = await hashPassword(pw, lock.salt);
  return t.hash === lock.hash;
}

export const getLock = (): LockData | null => {
  try {
    const raw = localStorage.getItem(LOCK_KEY);
    return raw ? (JSON.parse(raw) as LockData) : null;
  } catch {
    return null;
  }
};
export const saveLock = (l: LockData | null) => {
  if (l) localStorage.setItem(LOCK_KEY, JSON.stringify(l));
  else localStorage.removeItem(LOCK_KEY);
};
export const isUnlocked = () => sessionStorage.getItem(UNLOCK_KEY) === "1";
export const markUnlocked = () => sessionStorage.setItem(UNLOCK_KEY, "1");

/* ===================== قراءة نسخة مشاركة عند الإقلاع ===================== */
export async function readShared(): Promise<Payload | null> {
  const el = document.getElementById("tp-state");
  if (el && el.textContent) {
    try {
      const p = JSON.parse(el.textContent) as Payload;
      if (p && p.state && p.state.teacher) return p;
    } catch {
      /* تجاهل */
    }
  }
  const m = location.hash.match(/[#&]f=([^&]+)/);
  if (m) {
    try {
      return await decodePayload(decodeURIComponent(m[1]));
    } catch {
      /* تجاهل */
    }
  }
  return null;
}

/* ===================== تصدير نسخة HTML مستقلة ===================== */
export async function exportStandalone(payload: Payload, filename: string): Promise<void> {
  const json = JSON.stringify(payload).replace(/</g, "\\u003c");
  const tag = `<script type="application/json" id="tp-state">${json}</script>`;
  let html = "";

  /* الطريقة الأولى: جلب نسخة الموقع الأصلية (تعمل عبر http) */
  try {
    const res = await fetch(location.href.split("#")[0], { cache: "no-store" });
    if (res.ok) html = await res.text();
  } catch {
    html = "";
  }

  /* الطريقة الثانية: نسخ الصفحة الحالية من DOM (تعمل حتى من ملف محلي) */
  if (!html.includes("</head>")) {
    const clone = document.documentElement.cloneNode(true) as HTMLElement;
    clone.querySelectorAll("#tp-state").forEach((n) => n.remove());
    const root = clone.querySelector("#root");
    if (root) root.innerHTML = "";
    html = `<!doctype html>\n${clone.outerHTML}`;
  }
  if (!html.includes("</head>")) throw new Error("تعذّر بناء نسخة مستقلة من هذه الصفحة.");

  html = html.replace("</head>", `${tag}</head>`);
  const url = URL.createObjectURL(new Blob([html], { type: "text/html;charset=utf-8" }));
  const a = document.createElement("a");
  a.href = url;
  a.download = filename;
  a.click();
  setTimeout(() => URL.revokeObjectURL(url), 20000);
}

/* ===================== تنزيل/نسخ ===================== */
export async function copyText(t: string): Promise<boolean> {
  try {
    await navigator.clipboard.writeText(t);
    return true;
  } catch {
    try {
      const ta = document.createElement("textarea");
      ta.value = t;
      ta.style.position = "fixed";
      ta.style.opacity = "0";
      document.body.appendChild(ta);
      ta.select();
      const ok = document.execCommand("copy");
      document.body.removeChild(ta);
      return ok;
    } catch {
      return false;
    }
  }
}

/* ===================== سياق المشاركة والعرض ===================== */
export interface ShareCtl {
  shared: boolean;
  viewer: boolean;
  setViewer: (v: boolean) => void;
  lock: LockData | null;
  setLock: (l: LockData | null) => void;
}

export const ShareCtx = createContext<ShareCtl | null>(null);

export function ShareProvider({ value, children }: { value: ShareCtl; children: ReactNode }) {
  return <ShareCtx.Provider value={value}>{children}</ShareCtx.Provider>;
}

export function useShare(): ShareCtl {
  const c = useContext(ShareCtx);
  if (!c) throw new Error("useShare must be used inside ShareProvider");
  return c;
}

/** هل نحن في وضع العرض (للقراءة فقط)؟ */
export function useViewer(): boolean {
  return useContext(ShareCtx)?.viewer ?? false;
}

export const slug = (name: string) => name.trim().replace(/\s+/g, "-").slice(0, 60) || "معلم";
