import { createContext, useContext } from "react";

export type PageId =
  | "home"
  | "profile"
  | "criteria"
  | "criterion"
  | "plan"
  | "practices"
  | "results"
  | "evidence"
  | "achievements"
  | "development"
  | "reports"
  | "share"
  | "dashboard"
  | "closing";

export interface View {
  page: PageId;
  param?: number;
}

export const NavCtx = createContext<(page: PageId, param?: number) => void>(() => {});
export const useNav = () => useContext(NavCtx);
