import { createContext, useContext, useEffect, useMemo, useState, type ReactNode } from "react";
import {
  INITIAL_STATE,
  type Achievement,
  type Criterion,
  type DevItem,
  type Evidence,
  type FileLibItem,
  type Practice,
  type State,
  type Teacher,
  uid,
} from "./data";

const KEY = "teacher-portfolio-v1";

export /** الاسم الافتراضي السابق — يُستبدل تلقائياً في أي نسخة محفوظة */
const LEGACY_NAME = "عبدالله بن سعد الحربي";
const CURRENT_NAME = "سعيد عزيز ال مرعي";

export function migrate(p: State): State {
  if (p.teacher?.name !== LEGACY_NAME) return p;
  return { ...p, teacher: { ...p.teacher, name: CURRENT_NAME } };
}

export function load(): State {
  try {
    const raw = localStorage.getItem(KEY);
    if (raw) {
      const p = JSON.parse(raw) as State;
      if (p && p.teacher && Array.isArray(p.criteria) && Array.isArray(p.evidence)) {
        const m = migrate(p);
        if (m !== p) localStorage.setItem(KEY, JSON.stringify(m));
        return m;
      }
    }
  } catch {
    /* تجاهل */
  }
  return INITIAL_STATE;
}

interface StoreApi {
  state: State;
  updateTeacher(p: Partial<Teacher>): void;
  addCriterion(c: Omit<Criterion, "id">): void;
  updateCriterion(id: number, p: Partial<Criterion>): void;
  removeCriterion(id: number): void;
  addEvidence(e: Omit<Evidence, "id">): void;
  updateEvidence(id: string, p: Partial<Evidence>): void;
  removeEvidence(id: string): void;
  addPractice(p: Omit<Practice, "id">): void;
  updatePractice(id: string, p: Partial<Practice>): void;
  removePractice(id: string): void;
  addDev(d: Omit<DevItem, "id">): void;
  updateDev(id: string, p: Partial<DevItem>): void;
  removeDev(id: string): void;
  addAch(a: Omit<Achievement, "id">): void;
  updateAch(id: string, p: Partial<Achievement>): void;
  removeAch(id: string): void;
  addFile(f: Omit<FileLibItem, "id">): void;
  removeFile(id: string): void;
  importState(s: State): void;
  reset(): void;
}

const Ctx = createContext<StoreApi | null>(null);

export function StoreProvider({
  children,
  initial,
  persist = true,
}: {
  children: ReactNode;
  initial?: State;
  persist?: boolean;
}) {
  const [state, setState] = useState<State>(() => initial ?? load());

  useEffect(() => {
    if (!persist) return;
    try {
      localStorage.setItem(KEY, JSON.stringify(state));
    } catch {
      /* قد تتجاوز الملفات السعة — نتجاهل بصمت */
    }
  }, [state, persist]);

  const api = useMemo<StoreApi>(
    () => ({
      state,
      updateTeacher: (p) => setState((s) => ({ ...s, teacher: { ...s.teacher, ...p } })),
      addCriterion: (c) =>
        setState((s) => ({ ...s, criteria: [...s.criteria, { ...c, id: Math.max(0, ...s.criteria.map((x) => x.id)) + 1 }] })),
      updateCriterion: (id, p) =>
        setState((s) => ({ ...s, criteria: s.criteria.map((c) => (c.id === id ? { ...c, ...p } : c)) })),
      removeCriterion: (id) =>
        setState((s) => ({
          ...s,
          criteria: s.criteria.filter((c) => c.id !== id),
          evidence: s.evidence.filter((e) => e.criterionId !== id),
        })),
      addEvidence: (e) => setState((s) => ({ ...s, evidence: [{ ...e, id: uid() }, ...s.evidence] })),
      updateEvidence: (id, p) =>
        setState((s) => ({ ...s, evidence: s.evidence.map((e) => (e.id === id ? { ...e, ...p } : e)) })),
      removeEvidence: (id) => setState((s) => ({ ...s, evidence: s.evidence.filter((e) => e.id !== id) })),
      addPractice: (p) => setState((s) => ({ ...s, practices: [{ ...p, id: uid() }, ...s.practices] })),
      updatePractice: (id, p) =>
        setState((s) => ({ ...s, practices: s.practices.map((x) => (x.id === id ? { ...x, ...p } : x)) })),
      removePractice: (id) => setState((s) => ({ ...s, practices: s.practices.filter((x) => x.id !== id) })),
      addDev: (d) => setState((s) => ({ ...s, development: [{ ...d, id: uid() }, ...s.development] })),
      updateDev: (id, p) =>
        setState((s) => ({ ...s, development: s.development.map((x) => (x.id === id ? { ...x, ...p } : x)) })),
      removeDev: (id) => setState((s) => ({ ...s, development: s.development.filter((x) => x.id !== id) })),
      addAch: (a) => setState((s) => ({ ...s, achievements: [{ ...a, id: uid() }, ...s.achievements] })),
      updateAch: (id, p) =>
        setState((s) => ({ ...s, achievements: s.achievements.map((x) => (x.id === id ? { ...x, ...p } : x)) })),
      removeAch: (id) => setState((s) => ({ ...s, achievements: s.achievements.filter((x) => x.id !== id) })),
      addFile: (f) => setState((s) => ({ ...s, files: [{ ...f, id: uid() }, ...s.files] })),
      removeFile: (id) => setState((s) => ({ ...s, files: s.files.filter((f) => f.id !== id) })),
      importState: (s) => setState(s),
      reset: () => setState(initial ?? INITIAL_STATE),
    }),
    [state]
  );

  return <Ctx.Provider value={api}>{children}</Ctx.Provider>;
}

export function useStore(): StoreApi {
  const ctx = useContext(Ctx);
  if (!ctx) throw new Error("useStore must be used within StoreProvider");
  return ctx;
}
