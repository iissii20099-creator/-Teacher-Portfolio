import { useMemo, useState } from "react";
import { ACH_KINDS, fmtDate, type AchKind, type Achievement } from "../data";
import { useStore } from "../store";
import { EightStar, Field, Icon, Modal, Reveal, SectionHead } from "../components/ui";
import { cn } from "../utils/cn";

export const ACH_ICON: Record<AchKind, string> = {
  شهادة: "award",
  تكريم: "trophy",
  مبادرة: "flag",
  مسابقة: "star",
  مشروع: "rocket",
  "إنجاز طلابي": "cap",
  "مشاركة مهنية": "users",
};

/* ===================== نموذج إنجاز ===================== */
export function AchievementForm({ initial, onDone }: { initial?: Achievement; onDone: () => void }) {
  const { addAch, updateAch } = useStore();
  const [f, setF] = useState(() =>
    initial
      ? { ...initial }
      : { id: "", kind: "شهادة" as AchKind, title: "", date: new Date().toISOString().slice(0, 10), desc: "", image: undefined as string | undefined }
  );
  const [msg, setMsg] = useState("");
  const set = <K extends keyof Achievement>(k: K, v: Achievement[K]) => setF((x) => ({ ...x, [k]: v }));

  const submit = () => {
    if (!f.title.trim()) {
      setMsg("أدخل عنوان الإنجاز أولاً.");
      return;
    }
    const payload = { kind: f.kind, title: f.title.trim(), date: f.date, desc: f.desc.trim(), image: f.image || undefined };
    if (initial) updateAch(initial.id, payload);
    else addAch(payload);
    onDone();
  };

  return (
    <div className="space-y-4">
      <div className="grid grid-cols-2 gap-3">
        <Field label="نوع الإنجاز">
          <select className="inp" value={f.kind} onChange={(e) => set("kind", e.target.value as AchKind)}>
            {ACH_KINDS.map((k) => (
              <option key={k}>{k}</option>
            ))}
          </select>
        </Field>
        <Field label="التاريخ">
          <input type="date" className="inp" value={f.date} onChange={(e) => set("date", e.target.value)} />
        </Field>
      </div>
      <Field label="عنوان الإنجاز *">
        <input className="inp" value={f.title} onChange={(e) => set("title", e.target.value)} placeholder="مثال: تكريم المعلم المميز" />
      </Field>
      <Field label="الوصف">
        <textarea className="inp min-h-[70px]" value={f.desc} onChange={(e) => set("desc", e.target.value)} placeholder="سياق الإنجاز وقيمته المهنية…" />
      </Field>
      <Field label="رابط صورة (اختياري)">
        <input className="inp" dir="ltr" value={f.image ?? ""} onChange={(e) => set("image", e.target.value)} placeholder="https://…" />
      </Field>
      {msg && <p className="rounded-lg border border-gold-500/40 bg-gold-100 px-3 py-2 text-xs font-bold text-gold-700">{msg}</p>}
      <div className="flex justify-end gap-2 border-t border-gold-200/60 pt-4">
        <button className="btn-ghost" onClick={onDone}>إلغاء</button>
        <button className="btn-primary" onClick={submit}>
          <Icon name="check" size={15} /> {initial ? "حفظ التعديلات" : "إضافة الإنجاز"}
        </button>
      </div>
    </div>
  );
}

/* ===================== صفحة الإنجازات ===================== */
export function AchievementsPage() {
  const { state, removeAch } = useStore();
  const [kind, setKind] = useState("");
  const [editing, setEditing] = useState<Achievement | null>(null);
  const [adding, setAdding] = useState(false);

  const list = useMemo(() => state.achievements.filter((a) => (kind ? a.kind === kind : true)), [state.achievements, kind]);

  return (
    <div className="mx-auto max-w-6xl px-4 py-10 md:px-6">
      <div className="flex flex-wrap items-end justify-between gap-4">
        <SectionHead
          no="القسم ٠٨"
          title="الإنجازات والتكريمات"
          desc="ما تُرك من أثر يستحق الاحتفاظ به: شهادات، تكريمات، مبادرات، مسابقات، مشاريع، وإنجازات طلابية."
          icon="trophy"
        />
        <button className="btn-primary no-print no-viewer shrink-0" onClick={() => setAdding(true)}>
          <Icon name="plus" size={16} /> إضافة إنجاز
        </button>
      </div>

      <Reveal className="mb-7 flex gap-2 overflow-x-auto pb-2">
        <button
          onClick={() => setKind("")}
          className={cn(
            "shrink-0 rounded-full border px-4 py-1.5 text-xs font-bold transition",
            !kind ? "border-pine-800 bg-pine-900 text-cream" : "border-gold-300/70 bg-cream text-pine-800 hover:border-gold-500"
          )}
        >
          الكل ({state.achievements.length})
        </button>
        {ACH_KINDS.map((k) => {
          const n = state.achievements.filter((a) => a.kind === k).length;
          if (!n) return null;
          return (
            <button
              key={k}
              onClick={() => setKind(k)}
              className={cn(
                "shrink-0 rounded-full border px-4 py-1.5 text-xs font-bold transition",
                kind === k ? "border-pine-800 bg-pine-900 text-cream" : "border-gold-300/70 bg-cream text-pine-800 hover:border-gold-500"
              )}
            >
              {k} ({n})
            </button>
          );
        })}
      </Reveal>

      {list.length === 0 ? (
        <div className="rounded-xl border border-dashed border-sand-dark bg-cream/60 py-16 text-center">
          <Icon name="trophy" size={30} className="mx-auto text-gold-400" />
          <p className="mt-3 text-sm font-bold text-ink-soft">لا توجد إنجازات في هذا التصنيف بعد</p>
        </div>
      ) : (
        <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {list.map((a, i) => (
            <Reveal key={a.id} delay={Math.min(i * 70, 400)}>
              <div className="card-lift gold-sheen group relative flex h-full flex-col overflow-hidden rounded-xl border border-gold-200/80 bg-cream shadow-soft hover:border-gold-400">
                <EightStar className="absolute -left-5 -top-5 h-16 w-16 text-gold-200/40 transition-transform duration-700 group-hover:rotate-45" />
                {a.image && (
                  <div className="relative h-40 overflow-hidden">
                    <img src={a.image} alt={a.title} className="h-full w-full object-cover transition-transform duration-700 group-hover:scale-105" />
                    <span className="absolute inset-0 bg-gradient-to-t from-pine-950/50 to-transparent" />
                  </div>
                )}
                <div className="relative flex flex-1 flex-col p-5">
                  <div className="flex items-center justify-between">
                    <span className="flex h-11 w-11 items-center justify-center rounded-full border border-gold-400/60 bg-gold-100/60 text-gold-600">
                      <Icon name={ACH_ICON[a.kind]} size={20} />
                    </span>
                    <span className="rounded-full border border-gold-400/40 bg-gold-100/70 px-2.5 py-0.5 text-[10px] font-extrabold text-gold-700">{a.kind}</span>
                  </div>
                  <h4 className="mt-3 font-display text-xl font-bold leading-snug text-pine-900">{a.title}</h4>
                  <p className="mt-1.5 line-clamp-3 text-xs leading-relaxed text-ink-soft">{a.desc}</p>
                  <div className="mt-auto flex items-center justify-between border-t border-sand-deep/60 pt-3">
                    <span className="flex items-center gap-1.5 text-[11px] font-bold text-ink-faint">
                      <Icon name="calendar" size={13} className="text-gold-500" /> {fmtDate(a.date)}
                    </span>
                    <button className="icon-btn no-viewer h-7 w-7" onClick={() => setEditing(a)} aria-label="تعديل">
                      <Icon name="pencil" size={13} />
                    </button>
                  </div>
                </div>
              </div>
            </Reveal>
          ))}
        </div>
      )}

      <Modal open={adding} onClose={() => setAdding(false)} title="إضافة إنجاز" wide>
        <AchievementForm onDone={() => setAdding(false)} />
      </Modal>
      <Modal open={!!editing} onClose={() => setEditing(null)} title="تعديل الإنجاز" wide>
        {editing && (
          <div>
            <AchievementForm initial={editing} onDone={() => setEditing(null)} />
            <div className="mt-4 border-t border-gold-200/60 pt-4">
              <ConfirmRemove onConfirm={() => { removeAch(editing.id); setEditing(null); }} />
            </div>
          </div>
        )}
      </Modal>
    </div>
  );
}

function ConfirmRemove({ onConfirm }: { onConfirm: () => void }) {
  return (
    <div className="flex items-center justify-between">
      <span className="text-xs font-bold text-clay">حذف الإنجاز نهائياً من الملف؟</span>
      <ConfirmRemoveBtn onConfirm={onConfirm} />
    </div>
  );
}

function ConfirmRemoveBtn({ onConfirm }: { onConfirm: () => void }) {
  const [arm, setArm] = useState(false);
  return (
    <button
      className={cn("btn-danger", arm && "border-clay bg-clay text-white hover:bg-clay")}
      onClick={() => (arm ? onConfirm() : setArm(true))}
    >
      <Icon name="trash" size={13} />
      {arm ? "تأكيد الحذف" : "حذف"}
    </button>
  );
}
