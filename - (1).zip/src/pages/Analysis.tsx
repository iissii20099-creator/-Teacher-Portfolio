import { useMemo, useState } from "react";
import { DEV_KINDS, fmtDate, toAr, type DevItem, type DevKind } from "../data";
import { useStore } from "../store";
import { BarCompare, Donut, Field, Icon, Modal, Reveal, SectionHead, StatCard, TrendLine, useCountUp, useInView } from "../components/ui";
import { cn } from "../utils/cn";

/* ===================== صفحة نتائج الطلاب ===================== */
export function ResultsPage() {
  const { state } = useStore();
  const s = state.student;
  const gain = s.after - s.before;
  const gainPct = Math.round((gain / s.before) * 100);

  return (
    <div className="mx-auto max-w-6xl px-4 py-10 md:px-6">
      <SectionHead
        no="القسم ٠٦"
        title="تحسين نتائج الطلاب"
        desc="صفحة تحليلية تفاعلة: متوسطات قبل التدخل وبعده، مسار التحسن، توزيع المستويات، والأثر على الفئات — شهادة حية للمعيارين الخامس والعاشر."
        icon="chartUp"
      />

      <div className="grid grid-cols-2 gap-3 md:grid-cols-3 lg:grid-cols-6">
        <StatCard icon="clock" value={s.before} label="المتوسط قبل التدخل" />
        <StatCard icon="chartUp" value={s.after} label="المتوسط بعد التدخل" delay={60} />
        <div className="col-span-2">
          <Reveal delay={120}>
            <div className="card-lift relative h-full overflow-hidden rounded-xl border border-gold-400/50 bg-pine-900 p-4 text-center text-cream shadow-soft">
              <span className="mx-auto flex h-10 w-10 items-center justify-center rounded-full border border-gold-400/60 bg-pine-800 text-gold-300">
                <Icon name="sparkles" size={18} />
              </span>
              <div className="mt-2 font-display text-4xl font-bold text-gold-300">
                +{gain} <span className="text-xl">نقطة</span>
              </div>
              <div className="mt-1 text-xs font-bold text-cream/75">نسبة التحسن {gainPct}%</div>
            </div>
          </Reveal>
        </div>
        <StatCard icon="users" value={s.students} label="الطلاب المستفيدون" delay={180} />
        <StatCard icon="trophy" value={s.excelling} label="الطلاب المتفوقون" delay={240} />
        <StatCard icon="heart" value={s.support} label="يحتاجون علاجاً" delay={300} />
      </div>

      <div className="mt-8 grid grid-cols-1 gap-6 lg:grid-cols-2">
        <Reveal>
          <div className="h-full rounded-xl border border-gold-200/80 bg-cream p-5 shadow-soft md:p-6">
            <h3 className="mb-5 flex items-center gap-2 font-display text-xl font-bold text-pine-900">
              <Icon name="chartUp" size={19} className="text-gold-600" /> التحسن حسب المحاور
            </h3>
            <BarCompare data={s.subjects.map((x) => ({ label: x.name, before: x.before, after: x.after }))} />
          </div>
        </Reveal>
        <Reveal delay={100}>
          <div className="h-full rounded-xl border border-gold-200/80 bg-cream p-5 shadow-soft md:p-6">
            <h3 className="mb-3 flex items-center gap-2 font-display text-xl font-bold text-pine-900">
              <Icon name="chartUp" size={19} className="text-gold-600" /> مسار التحسن عبر العام
            </h3>
            <TrendLine points={s.trend} />
          </div>
        </Reveal>
      </div>

      <div className="mt-6 grid grid-cols-1 gap-6 lg:grid-cols-2">
        <Reveal>
          <div className="h-full rounded-xl border border-gold-200/80 bg-cream p-5 shadow-soft md:p-6">
            <h3 className="mb-5 flex items-center gap-2 font-display text-xl font-bold text-pine-900">
              <Icon name="target" size={19} className="text-gold-600" /> توزيع مستويات الطلاب الحالي
            </h3>
            <Donut slices={s.levels} centerValue={toAr(s.students)} centerLabel="طالباً" />
          </div>
        </Reveal>
        <Reveal delay={100}>
          <div className="flex h-full flex-col gap-4">
            <div className="rounded-xl border-r-4 border-pine-600 bg-pine-50 p-5">
              <h4 className="flex items-center gap-2 text-sm font-extrabold text-pine-800">
                <Icon name="heart" size={16} /> البرنامج العلاجي
              </h4>
              <p className="mt-2 text-xs leading-relaxed text-ink">
                خطة أسبوعية لـ {toAr(s.support)} طلاب بمستوى «يحتاج دعم»: حصص دعم قصيرة، أوراق عمل متدرجة، وإعادة قياس شهرية — خرج طالبان منها إلى المستوى المتوسط حتى الآن.
              </p>
            </div>
            <div className="rounded-xl border-r-4 border-gold-500 bg-gold-100/50 p-5">
              <h4 className="flex items-center gap-2 text-sm font-extrabold text-gold-700">
                <Icon name="trophy" size={16} /> برنامج المتفوقين «قادة الكتابة»
              </h4>
              <p className="mt-2 text-xs leading-relaxed text-ink">
                8 أسابيع من المهام الإثرائية: كتابة صحفية، نقد أدبي، وتحرير جماعي — أسّس للمشروع الذي مثّل المادة في معرض المدرسة.
              </p>
            </div>
            <div className="rounded-xl border-r-4 border-olive-500 bg-olive-100/70 p-5">
              <h4 className="flex items-center gap-2 text-sm font-extrabold text-olive-600">
                <Icon name="sparkles" size={16} /> أنشطة إثرائية
              </h4>
              <p className="mt-2 text-xs leading-relaxed text-ink">
                تحدي الكتابة الإبداعية، الصحيفة الصفية، وركن القراءة الحي — كلها موثقة في قسم الممارسات المهنية.
              </p>
            </div>
          </div>
        </Reveal>
      </div>
    </div>
  );
}

/* ===================== نموذج تطوير مهني ===================== */
export function DevForm({ initial, onDone }: { initial?: DevItem; onDone: () => void }) {
  const { addDev, updateDev } = useStore();
  const [f, setF] = useState(() =>
    initial
      ? { ...initial }
      : { id: "", kind: "دورة" as DevKind, title: "", org: "", date: new Date().toISOString().slice(0, 10), hours: 12, cert: "", link: "" }
  );
  const [msg, setMsg] = useState("");
  const set = <K extends keyof DevItem>(k: K, v: DevItem[K]) => setF((x) => ({ ...x, [k]: v }));

  const submit = () => {
    if (!f.title.trim()) {
      setMsg("أدخل العنوان أولاً.");
      return;
    }
    const payload = { kind: f.kind, title: f.title.trim(), org: f.org.trim(), date: f.date, hours: Number(f.hours) || 0, cert: f.cert.trim(), link: (f.link ?? "").trim() || undefined };
    if (initial) updateDev(initial.id, payload);
    else addDev(payload);
    onDone();
  };

  return (
    <div className="space-y-4">
      <div className="grid grid-cols-2 gap-3">
        <Field label="النوع">
          <select className="inp" value={f.kind} onChange={(e) => set("kind", e.target.value as DevKind)}>
            {DEV_KINDS.map((k) => (
              <option key={k}>{k}</option>
            ))}
          </select>
        </Field>
        <Field label="التاريخ">
          <input type="date" className="inp" value={f.date} onChange={(e) => set("date", e.target.value)} />
        </Field>
      </div>
      <Field label="العنوان *">
        <input className="inp" value={f.title} onChange={(e) => set("title", e.target.value)} placeholder="مثال: دورة التعلم النشط" />
      </Field>
      <div className="grid grid-cols-2 gap-3">
        <Field label="الجهة">
          <input className="inp" value={f.org} onChange={(e) => set("org", e.target.value)} />
        </Field>
        <Field label="عدد الساعات">
          <input type="number" min={0} className="inp" value={f.hours} onChange={(e) => set("hours", Number(e.target.value))} />
        </Field>
      </div>
      <Field label="الشهادة / الشاهد">
        <input className="inp" value={f.cert} onChange={(e) => set("cert", e.target.value)} placeholder="مثال: شهادة إتمام معتمدة" />
      </Field>
      <Field label="رابط الشهادة (اختياري)">
        <input className="inp" dir="ltr" value={f.link ?? ""} onChange={(e) => set("link", e.target.value)} placeholder="https://…" />
      </Field>
      {msg && <p className="rounded-lg border border-gold-500/40 bg-gold-100 px-3 py-2 text-xs font-bold text-gold-700">{msg}</p>}
      <div className="flex justify-end gap-2 border-t border-gold-200/60 pt-4">
        <button className="btn-ghost" onClick={onDone}>إلغاء</button>
        <button className="btn-primary" onClick={submit}>
          <Icon name="check" size={15} /> {initial ? "حفظ التعديلات" : "إضافة"}
        </button>
      </div>
    </div>
  );
}

/* ===================== صفحة التطوير المهني ===================== */
const DEV_ICON: Record<DevKind, string> = {
  دورة: "cap",
  "ورشة عمل": "pencil",
  مؤتمر: "building",
  "مجتمع تعلم": "users",
  بحث: "bookOpen",
  "قراءة مهنية": "book",
  مبادرة: "flag",
};

function HoursStat({ value }: { value: number }) {
  const { ref, on } = useInView<HTMLDivElement>();
  const v = useCountUp(value, on, 1300);
  return (
    <div ref={ref} className="card-lift relative overflow-hidden rounded-xl border border-gold-400/50 bg-pine-900 p-5 text-center text-cream shadow-soft">
      <div className="font-display text-5xl font-bold text-gold-300">{Math.round(v)}</div>
      <div className="mt-1 text-xs font-bold text-cream/75">ساعة تطوير مهني معتمدة هذا العام</div>
    </div>
  );
}

export function DevelopmentPage() {
  const { state, removeDev } = useStore();
  const [kind, setKind] = useState("");
  const [editing, setEditing] = useState<DevItem | null>(null);
  const [adding, setAdding] = useState(false);
  const totalHours = state.development.reduce((a, b) => a + b.hours, 0);

  const list = useMemo(() => state.development.filter((d) => (kind ? d.kind === kind : true)), [state.development, kind]);

  return (
    <div className="mx-auto max-w-6xl px-4 py-10 md:px-6">
      <div className="flex flex-wrap items-end justify-between gap-4">
        <SectionHead
          no="القسم ٠٩"
          title="التطوير المهني المستمر"
          desc="الدورات، ورش العمل، المؤتمرات، مجتمعات التعلم، البحوث، والقراءات — كل عنصر بجهته وساعاته وشهادته."
          icon="rocket"
        />
        <button className="btn-primary no-print no-viewer shrink-0" onClick={() => setAdding(true)}>
          <Icon name="plus" size={16} /> إضافة عنصر تطوير
        </button>
      </div>

      <Reveal className="mb-7 grid grid-cols-1 gap-4 sm:grid-cols-3">
        <HoursStat value={totalHours} />
        <div className="sm:col-span-2 rounded-xl border border-gold-200/80 bg-cream p-5 shadow-soft">
          <p className="text-xs font-extrabold text-ink-faint">ملخص العام الدراسي</p>
          <div className="mt-3 flex flex-wrap gap-x-6 gap-y-2 text-sm font-bold text-ink">
            {DEV_KINDS.map((k) => {
              const n = state.development.filter((d) => d.kind === k).length;
              return (
                <span key={k} className="flex items-center gap-1.5">
                  <Icon name={DEV_ICON[k]} size={15} className="text-gold-600" />
                  {k}: <span className="font-display text-lg text-pine-800">{toAr(n)}</span>
                </span>
              );
            })}
          </div>
        </div>
      </Reveal>

      <Reveal className="mb-6 flex gap-2 overflow-x-auto pb-2">
        <button
          onClick={() => setKind("")}
          className={cn(
            "shrink-0 rounded-full border px-4 py-1.5 text-xs font-bold transition",
            !kind ? "border-pine-800 bg-pine-900 text-cream" : "border-gold-300/70 bg-cream text-pine-800 hover:border-gold-500"
          )}
        >
          الكل ({state.development.length})
        </button>
        {DEV_KINDS.map((k) => {
          const n = state.development.filter((d) => d.kind === k).length;
          if (!n) return null;
          return (
            <button
              key={k}
              onClick={() => setKind(k)}
              className={cn(
                "shrink-0 rounded-full border px-4 py-1.5 text-xs font-bold transition",
                kind === k ? "border-pine-800 bg-pine-900 text-cream" : "border-gold-300/70 bg-cream text-pine-800 hover:border-gold-500"
              )}
            >
              {k} ({n})
            </button>
          );
        })}
      </Reveal>

      <div className="space-y-3">
        {list.map((d, i) => (
          <Reveal key={d.id} delay={Math.min(i * 60, 360)}>
            <div className="card-lift group flex flex-wrap items-center gap-4 rounded-xl border border-gold-200/80 bg-cream p-4 shadow-soft hover:border-gold-400 md:px-5">
              <span className="flex h-12 w-12 shrink-0 items-center justify-center rounded-lg border border-gold-300/70 bg-gold-100/50 text-gold-600">
                <Icon name={DEV_ICON[d.kind]} size={22} />
              </span>
              <div className="min-w-0 flex-1">
                <div className="flex flex-wrap items-center gap-2">
                  <span className="rounded-full border border-pine-600/20 bg-pine-50 px-2 py-0.5 text-[10px] font-extrabold text-pine-700">{d.kind}</span>
                  <span className="text-[11px] font-bold text-ink-faint">{fmtDate(d.date)}</span>
                </div>
                <h4 className="mt-1 truncate font-display text-lg font-bold text-pine-900">{d.title}</h4>
                <p className="text-xs font-bold text-ink-soft">
                  {d.org} · {toAr(d.hours)} ساعة
                </p>
              </div>
              <div className="flex items-center gap-2">
                {d.cert && (
                  <span className="hidden items-center gap-1.5 rounded-full border border-gold-400/40 bg-gold-100/70 px-3 py-1 text-[11px] font-extrabold text-gold-700 sm:flex">
                    <Icon name="award" size={13} /> {d.cert}
                  </span>
                )}
                {d.link && (
                  <a className="icon-btn" href={d.link} target="_blank" rel="noreferrer" title="فتح رابط الشهادة">
                    <Icon name="external" size={14} />
                  </a>
                )}
                <button className="icon-btn no-viewer" onClick={() => setEditing(d)} aria-label="تعديل">
                  <Icon name="pencil" size={14} />
                </button>
                <ConfirmRemove onConfirm={() => removeDev(d.id)} />
              </div>
            </div>
          </Reveal>
        ))}
        {list.length === 0 && (
          <div className="rounded-xl border border-dashed border-sand-dark bg-cream/60 py-14 text-center">
            <Icon name="rocket" size={28} className="mx-auto text-gold-400" />
            <p className="mt-3 text-sm font-bold text-ink-soft">لا توجد عناصر في هذا التصنيف بعد</p>
          </div>
        )}
      </div>

      <Modal open={adding} onClose={() => setAdding(false)} title="إضافة عنصر تطوير مهني" wide>
        <DevForm onDone={() => setAdding(false)} />
      </Modal>
      <Modal open={!!editing} onClose={() => setEditing(null)} title="تعديل عنصر التطوير" wide>
        {editing && <DevForm initial={editing} onDone={() => setEditing(null)} />}
      </Modal>
    </div>
  );
}

function ConfirmRemove({ onConfirm }: { onConfirm: () => void }) {
  const [arm, setArm] = useState(false);
  return (
    <button
      className={cn("btn-danger", arm && "border-clay bg-clay text-white hover:bg-clay")}
      onClick={() => (arm ? onConfirm() : setArm(true))}
      title="حذف"
    >
      <Icon name="trash" size={13} />
      {arm ? "تأكيد" : ""}
    </button>
  );
}
