import { useMemo, useState } from "react";
import { computeCompletion, computeStats, downloadText, toAr, type State } from "../data";
import { useStore } from "../store";
import { useNav } from "../nav";
import {
  copyText,
  encodePayload,
  exportStandalone,
  hashPassword,
  saveLock,
  slug,
  useShare,
  type EncodeResult,
} from "../share";

const kb = (n: number) => `${(n / 1024).toFixed(n / 1024 >= 10 ? 0 : 1)} ك.ب`;
import { EightStar, Field, GoldDivider, Icon, OrnateCard, Reveal, SectionHead, Switch } from "../components/ui";
import { cn } from "../utils/cn";

/** نسخة خفيفة: تُسقط الصور المضمّنة داخل المتصفح لأنها تضخّم الرابط */
function lighten(s: State): State {
  const clean = (u?: string) => (u && u.startsWith("data:") ? undefined : u);
  return {
    ...s,
    teacher: { ...s.teacher, photo: s.teacher.photo?.startsWith("data:") ? "" : s.teacher.photo },
    evidence: s.evidence.map((e) => ({ ...e, image: clean(e.image), file: e.file ? { ...e.file, url: clean(e.file.url) } : e.file })),
    practices: s.practices.map((p) => ({ ...p, image: clean(p.image) })),
    achievements: s.achievements.map((a) => ({ ...a, image: clean(a.image) })),
    files: s.files.map((f) => ({ ...f, url: clean(f.url) })),
  };
}

const sizeTone = (n: number) =>
  n < 2000
    ? { cls: "border-pine-600/25 bg-pine-50 text-pine-700", txt: "قصير — آمن للإرسال في أي تطبيق" }
    : n < 30000
      ? { cls: "border-gold-500/35 bg-gold-100 text-gold-700", txt: "طويل — أرفقه كنص أو ملف؛ بعض تطبيقات المراسلة تقتطعه" }
      : { cls: "border-clay/30 bg-clay/10 text-clay", txt: "طويل جداً — استخدم «ملف مستقل باسمك» بدل الرابط" };

export function SharePage() {
  const { state } = useStore();
  const { shared, viewer, setViewer, lock, setLock } = useShare();
  const nav = useNav();
  const t = state.teacher;
  const comp = useMemo(() => computeCompletion(state), [state]);
  const stats = useMemo(() => computeStats(state), [state]);

  const [withImages, setWithImages] = useState(false);
  const [link, setLink] = useState("");
  const [busy, setBusy] = useState(false);
  const [msg, setMsg] = useState("");
  const [copied, setCopied] = useState(false);

  const [pw, setPw] = useState("");
  const [pw2, setPw2] = useState("");
  const [pwMsg, setPwMsg] = useState("");
  const [showPw, setShowPw] = useState(false);

  const [expMsg, setExpMsg] = useState("");
  const [expBusy, setExpBusy] = useState(false);

  const base = location.href.split("#")[0];
  const fileName = `ملف-إنجاز-${slug(t.name)}.html`;

  const [enc, setEnc] = useState<EncodeResult | null>(null);
  const [msgTone, setMsgTone] = useState<"err" | "ok">("err");

  const generate = async () => {
    setBusy(true);
    setMsg("");
    setEnc(null);

    const build = async (st: State) => {
      const r = await encodePayload({ v: 1, state: st, lock }, base);
      setEnc(r);
      setLink(`${base}#f=${r.code}`);
      setCopied(false);
    };
    const fail = (e: unknown) =>
      `تعذّر إنشاء الرابط — ${e instanceof Error ? e.message : "سبب غير معروف"}. الحل الأسهل: استخدم «ملف مستقل باسمك» أدناه، فهو لا يتأثر بطول الرابط.`;

    try {
      await build(withImages ? state : lighten(state));
    } catch (e) {
      if (withImages) {
        /* إعادة محاولة تلقائية بالنسخة الخفيفة */
        try {
          await build(lighten(state));
          setWithImages(false);
          setMsgTone("ok");
          setMsg("الصور المضمّنة كانت أكبر من أن تُحمل داخل رابط — أُنشئ الرابط بالنسخة الخفيفة بنجاح.");
          return;
        } catch (e2) {
          setMsgTone("err");
          setMsg(fail(e2));
        }
      } else {
        setMsgTone("err");
        setMsg(fail(e));
      }
      setLink("");
      setEnc(null);
    } finally {
      setBusy(false);
    }
  };

  const doExport = async () => {
    setExpBusy(true);
    setExpMsg("");
    try {
      await exportStandalone({ v: 1, state: withImages ? state : lighten(state), lock }, fileName);
      setExpMsg(`تم تنزيل «${fileName}» — ارفعه على Google Drive أو منصة مدرستي ثم أرسل رابطه للجهة.`);
    } catch (e) {
      setExpMsg(`تعذّر تجهيز الملف المستقل — ${e instanceof Error ? e.message : "سبب غير معروف"}. جرّب رابط المشاركة أو تصدير PDF.`);
    } finally {
      setExpBusy(false);
    }
  };

  const applyLock = async () => {
    if (pw.length < 4) return setPwMsg("كلمة المرور 4 أحرف على الأقل.");
    if (pw !== pw2) return setPwMsg("الكلمتان غير متطابقتين.");
    const l = await hashPassword(pw);
    saveLock(l);
    setLock(l);
    setPw("");
    setPw2("");
    setPwMsg("تم تعيين كلمة المرور ✓ — ستُطلب عند كل فتح جديد للملف.");
    if (link) setLink("");
  };

  const dropLock = () => {
    saveLock(null);
    setLock(null);
    setPwMsg("تم إلغاء القفل — الملف يُفتح مباشرة.");
    if (link) setLink("");
  };

  const tone = link ? sizeTone(link.length) : null;

  return (
    <div className="mx-auto max-w-6xl px-4 py-10 md:px-6">
      <SectionHead
        no="القسم ١١"
        title="مركز النشر والحماية"
        desc="حوّل ملفك إلى رابط باسمك، أو ملف مستقل تُرسل رابطه للجهة — مع وضع عرض للقراءة فقط وقفل بكلمة مرور."
        icon="shield"
      />

      <div className="grid grid-cols-1 gap-6 lg:grid-cols-12">
        {/* ================= العمود الأيمن: الإرسال والحماية ================= */}
        <div className="space-y-6 lg:col-span-5">
          {/* بطاقة الإرسال */}
          <Reveal>
            <OrnateCard className="p-5 md:p-6">
              <p className="text-[10px] font-extrabold tracking-wide text-gold-600">بطاقة الإرسال</p>
              <h3 className="mt-1 font-display text-2xl font-bold leading-snug text-pine-900">
                ملف إنجاز <span className="text-gold-600">{t.name}</span>
              </h3>
              <dl className="mt-4 space-y-2.5 border-y border-gold-200/70 py-4 text-xs font-bold">
                {[
                  ["الجهة", t.school],
                  ["المعلم", t.name],
                  ["التخصص", t.specialty],
                  ["العام الدراسي", t.year],
                  ["المحتوى", `${toAr(stats.evidence)} شاهداً · ${toAr(state.criteria.length)} معياراً · اكتمال ${comp.total}٪`],
                ].map(([k, v]) => (
                  <div key={k} className="flex gap-3">
                    <dt className="w-24 shrink-0 text-ink-faint">{k}</dt>
                    <dd className="flex-1 text-ink">{v}</dd>
                  </div>
                ))}
              </dl>
              <div className="mt-4 flex flex-wrap items-center gap-2">
                <span className="rounded-md border border-sand-deep bg-cream-deep/70 px-2.5 py-1 text-[10px] font-bold text-ink-soft" dir="ltr">
                  {fileName}
                </span>
                {lock && (
                  <span className="flex items-center gap-1 rounded-md border border-pine-600/25 bg-pine-50 px-2.5 py-1 text-[10px] font-extrabold text-pine-700">
                    <Icon name="shield" size={11} /> محمي بكلمة مرور
                  </span>
                )}
                <button className="btn-ghost !px-3 !py-1 !text-[11px]" onClick={() => nav("profile")}>
                  <Icon name="pencil" size={12} /> تعديل بياناتي
                </button>
              </div>
            </OrnateCard>
          </Reveal>

          {/* الحماية */}
          <Reveal delay={80}>
            <div className="relative overflow-hidden rounded-xl border border-gold-500/30 bg-pine-900 p-5 text-cream shadow-soft md:p-6">
              <EightStar className="anim-spin-slow absolute -left-12 -top-12 h-40 w-40 text-gold-500/10" />
              <div className="relative">
                <h3 className="flex items-center gap-2 font-display text-xl font-bold text-gold-300">
                  <Icon name="shield" size={19} /> الحماية بكلمة مرور
                </h3>
                <p className="mt-2 text-xs leading-relaxed text-cream/70">
                  تُخزَّن الكلمة كبصمة مشفّرة (SHA-256) داخل متصفحك — لا تُحفظ نصاً، ولا تُرسل لأي جهة. تُطلب مرة واحدة عند فتح الملف.
                </p>

                {shared ? (
                  <p className="mt-4 rounded-lg border border-gold-500/30 bg-pine-800/60 px-3 py-2 text-[11px] font-bold text-cream/80">
                    هذه نسخة معروضة للقراءة — إعدادات الحماية يملكها صاحب الملف فقط.
                  </p>
                ) : lock ? (
                  <div className="mt-4 space-y-3">
                    <div className="flex items-center gap-2 rounded-lg border border-pine-500/40 bg-pine-800/60 px-3 py-2 text-xs font-extrabold">
                      <span className="anim-pulse-gold h-2 w-2 rounded-full bg-gold-400" /> القفل مُفعّل منذ {new Date(lock.at).toLocaleDateString("ar-EG-u-nu-latn")}
                    </div>
                    <div className="flex flex-wrap gap-2">
                      <button className="btn-gold" onClick={dropLock}>
                        <Icon name="x" size={14} /> إلغاء القفل
                      </button>
                    </div>
                    <div className="grid grid-cols-2 gap-3 border-t border-cream/10 pt-3">
                      <Field label="كلمة مرور جديدة">
                        <input type={showPw ? "text" : "password"} className="inp" value={pw} onChange={(e) => setPw(e.target.value)} placeholder="••••" />
                      </Field>
                      <Field label="تأكيد الكلمة">
                        <input type={showPw ? "text" : "password"} className="inp" value={pw2} onChange={(e) => setPw2(e.target.value)} placeholder="••••" />
                      </Field>
                    </div>
                    <div className="flex flex-wrap items-center gap-3">
                      <button className="btn-primary" onClick={applyLock}>
                        <Icon name="refresh" size={14} /> تغيير كلمة المرور
                      </button>
                      <button className="flex items-center gap-1.5 text-[11px] font-bold text-cream/70 hover:text-gold-300" onClick={() => setShowPw((v) => !v)}>
                        <Icon name={showPw ? "x" : "eye"} size={13} /> {showPw ? "إخفاء" : "إظهار"}
                      </button>
                    </div>
                  </div>
                ) : (
                  <div className="mt-4 space-y-3">
                    <div className="grid grid-cols-2 gap-3">
                      <Field label="كلمة المرور">
                        <input type={showPw ? "text" : "password"} className="inp" value={pw} onChange={(e) => setPw(e.target.value)} placeholder="4 أحرف على الأقل" />
                      </Field>
                      <Field label="تأكيد كلمة المرور">
                        <input type={showPw ? "text" : "password"} className="inp" value={pw2} onChange={(e) => setPw2(e.target.value)} placeholder="أعد كتابتها" />
                      </Field>
                    </div>
                    <div className="flex flex-wrap items-center gap-3">
                      <button className="btn-gold" onClick={applyLock}>
                        <Icon name="shield" size={14} /> قفل الملف
                      </button>
                      <button className="flex items-center gap-1.5 text-[11px] font-bold text-cream/70 hover:text-gold-300" onClick={() => setShowPw((v) => !v)}>
                        <Icon name={showPw ? "x" : "eye"} size={13} /> {showPw ? "إخفاء" : "إظهار"}
                      </button>
                    </div>
                  </div>
                )}
                {pwMsg && <p className="mt-3 rounded-lg border border-gold-500/40 bg-gold-100/10 px-3 py-2 text-[11px] font-bold text-gold-200">{pwMsg}</p>}
              </div>
            </div>
          </Reveal>

          {/* وضع العرض */}
          <Reveal delay={140}>
            <div className="rounded-xl border border-gold-200/80 bg-cream p-5 shadow-soft">
              <div className="flex flex-wrap items-center justify-between gap-3">
                <div className="min-w-0">
                  <h3 className="flex items-center gap-2 font-display text-lg font-bold text-pine-900">
                    <Icon name="eye" size={17} className="text-gold-600" /> وضع العرض للجهة
                  </h3>
                  <p className="mt-1.5 text-[11px] font-bold leading-relaxed text-ink-soft">
                    يُخفي لوحة التحكم وكل أزرار الإضافة والتعديل والحذف، ويبقى الملف للعرض والطباعة فقط — كما ستراه الجهة تماماً.
                  </p>
                </div>
                <Switch checked={viewer} onChange={setViewer} label="تفعيل وضع العرض" />
              </div>
              {viewer && !shared && (
                <div className="mt-3 flex flex-wrap items-center gap-2 rounded-lg border border-pine-600/20 bg-pine-50 px-3 py-2">
                  <span className="flex items-center gap-1.5 text-[11px] font-extrabold text-pine-700">
                    <span className="anim-pulse-gold h-2 w-2 rounded-full bg-pine-600" /> أنت الآن في وضع العرض
                  </span>
                  <button className="btn-ghost ms-auto !px-3 !py-1 !text-[11px]" onClick={() => setViewer(false)}>
                    خروج من وضع العرض
                  </button>
                </div>
              )}
            </div>
          </Reveal>
        </div>

        {/* ================= العمود الأيسر: الرابط والملف ================= */}
        <div className="space-y-6 lg:col-span-7">
          {/* الملف المستقل */}
          <Reveal>
            <div className="relative overflow-hidden rounded-xl border-2 border-gold-400/60 bg-cream p-5 shadow-lift md:p-6">
              <span className="absolute left-0 top-0 rounded-br-lg border border-gold-400/50 bg-gold-500 px-3 py-1 text-[10px] font-extrabold text-white">
                الخيار الموصى به
              </span>
              <h3 className="mt-4 flex items-center gap-2 font-display text-2xl font-bold text-pine-900">
                <Icon name="fileText" size={21} className="text-gold-600" /> ملف مستقل باسمك
              </h3>
              <p className="mt-2 max-w-xl text-xs leading-relaxed text-ink-soft">
                يُنزَّل ملف HTML واحد يحتوي ملف إنجازك كاملاً ببياناتك الحالية — يفتح في أي متصفح دون إنترنت ودون تنصيب، ويمكن رفعه على Drive أو منصة مدرستي وإرسال رابطه القصير للجهة.
              </p>
              <div className="mt-4 flex flex-wrap items-center gap-2">
                <button className="btn-primary" onClick={doExport} disabled={expBusy || shared}>
                  <Icon name="download" size={15} /> {expBusy ? "جارٍ التجهيز…" : `تنزيل ${fileName}`}
                </button>
                <span className="rounded-md border border-sand-deep bg-cream-deep/70 px-2.5 py-1 text-[10px] font-bold text-ink-faint">
                  {withImages ? "يتضمّن الصور المضمّنة (حجم أكبر)" : "نسخة خفيفة — الصور المضمّنة مستثناة"}
                </span>
              </div>
              {expMsg && <p className="mt-3 rounded-lg border border-gold-500/40 bg-gold-100 px-3 py-2 text-[11px] font-bold leading-relaxed text-gold-700">{expMsg}</p>}
            </div>
          </Reveal>

          {/* دليل الإرسال */}
          <Reveal delay={80}>
            <div className="rounded-xl border border-gold-200/80 bg-cream p-5 shadow-soft md:p-6">
              <h3 className="flex items-center gap-2 font-display text-lg font-bold text-pine-900">
                <Icon name="flag" size={17} className="text-gold-600" /> كيف أرسله للجهة؟
              </h3>
              <ol className="mt-4 space-y-3">
                {[
                  "اضبط بياناتك في «الملف الشخصي» (الاسم، التخصص، المدرسة، العام الدراسي) — فهي التي تظهر على بطاقة الإرسال واسم الملف.",
                  "فعّل وضع العرض للجهة، واضبط كلمة مرور إن أردت حماية المحتوى.",
                  "نزّل الملف المستقل باسمك، ثم ارفعه على Google Drive أو منصة مدرستي أو البريد الرسمي.",
                  "انسخ رابط الملف من هناك وأرسله للجهة مع كلمة المرور عبر قناة منفصلة (رسالة جوال مثلاً).",
                ].map((s, i) => (
                  <li key={i} className="flex items-start gap-3">
                    <span className="mt-0.5 flex h-6 w-6 shrink-0 items-center justify-center rounded-full border border-gold-400/60 bg-gold-100/60 font-display text-sm font-bold text-gold-700">
                      {toAr(i + 1)}
                    </span>
                    <span className="text-xs font-bold leading-relaxed text-ink">{s}</span>
                  </li>
                ))}
              </ol>
            </div>
          </Reveal>

          {/* رابط المشاركة */}
          <Reveal delay={140}>
            <div className="rounded-xl border border-gold-200/80 bg-cream p-5 shadow-soft md:p-6">
              <div className="flex flex-wrap items-end justify-between gap-3">
                <div>
                  <h3 className="flex items-center gap-2 font-display text-lg font-bold text-pine-900">
                    <Icon name="link" size={17} className="text-gold-600" /> رابط مشاركة يحمل بياناتك
                  </h3>
                  <p className="mt-1.5 max-w-xl text-[11px] font-bold leading-relaxed text-ink-soft">
                    الرابط يفتح الملف نفسه ببياناتك الحالية ووضع العرض — بلا استضافة ولا خادم. يعمل مباشرة بين متصفح ومتصفح.
                  </p>
                </div>
                <label className="flex cursor-pointer items-center gap-2 rounded-lg border border-sand-deep bg-cream-deep/60 px-3 py-2">
                  <input type="checkbox" className="h-4 w-4 accent-[#8f6e33]" checked={withImages} onChange={(e) => { setWithImages(e.target.checked); setLink(""); }} />
                  <span className="text-[11px] font-extrabold text-ink">تضمين الصور المضمّنة</span>
                </label>
              </div>

              <button className="btn-gold mt-4" onClick={generate} disabled={busy || shared}>
                <Icon name={busy ? "refresh" : "sparkles"} size={15} className={busy ? "animate-spin" : ""} />
                {busy ? "جارٍ ضغط البيانات…" : link ? "إعادة توليد الرابط" : "إنشاء رابط المشاركة"}
              </button>
              {msg && (
                <p
                  className={cn(
                    "mt-3 rounded-lg border px-3 py-2 text-[11px] font-bold leading-relaxed",
                    msgTone === "ok" ? "border-pine-600/25 bg-pine-50 text-pine-700" : "border-clay/30 bg-clay/10 text-clay"
                  )}
                >
                  {msg}
                </p>
              )}

              {link && tone && (
                <div className="mt-4 space-y-3">
                  <div className="flex gap-2">
                    <input className="inp !py-2.5 font-mono !text-[11px]" dir="ltr" readOnly value={link} onFocus={(e) => e.target.select()} />
                    <button className="btn-primary shrink-0" onClick={async () => { setCopied(await copyText(link)); setTimeout(() => setCopied(false), 2200); }}>
                      <Icon name={copied ? "check" : "folder"} size={15} /> {copied ? "تم النسخ" : "نسخ"}
                    </button>
                  </div>
                  <div className="flex flex-wrap items-center gap-2">
                    <span className={cn("rounded-full border px-2.5 py-0.5 text-[10px] font-extrabold", tone.cls)}>
                      {toAr(link.length)} حرف · {tone.txt}
                    </span>
                    {enc && (
                      <span className="rounded-full border border-sand-deep bg-cream-deep/70 px-2.5 py-0.5 text-[10px] font-extrabold text-ink-soft">
                        حجم البيانات {kb(enc.rawBytes)}
                        {enc.compressed ? ` → ${kb(enc.outBytes)} بعد الضغط (${toAr(Math.round((1 - enc.outBytes / enc.rawBytes) * 100))}٪ توفير)` : " · الضغط غير متاح في هذا المتصفح"}
                      </span>
                    )}
                    <a className="btn-ghost !px-3 !py-1 !text-[11px]" href={link} target="_blank" rel="noreferrer">
                      <Icon name="external" size={12} /> معاينة كما يراها المستلم
                    </a>
                    <button
                      className="btn-ghost !px-3 !py-1 !text-[11px]"
                      onClick={() => downloadText(`رابط-ملف-إنجاز-${slug(t.name)}.txt`, `${t.name} — ${t.specialty}\n${t.school}\n\n${link}\n`)}
                    >
                      <Icon name="download" size={12} /> تنزيل الرابط كنص
                    </button>
                  </div>
                  <p className="text-[10px] font-bold leading-relaxed text-ink-faint">
                    الصور والروابط القادمة من Google Drive تظهر فقط لمن يملك صلاحية الوصول إليها في حسابك.
                  </p>
                </div>
              )}
            </div>
          </Reveal>

          <GoldDivider />

          <Reveal>
            <div className="rounded-xl border border-gold-200/80 bg-cream-deep/50 p-5">
              <h4 className="flex items-center gap-2 text-sm font-extrabold text-pine-900">
                <Icon name="printer" size={15} className="text-gold-600" /> بديل سريع: نسخة PDF رسمية
              </h4>
              <p className="mt-1.5 text-[11px] font-bold leading-relaxed text-ink-soft">
                إن اكتفت الجهة بمستند، افتح أي تقرير من «التقارير» ثم اختر تصدير PDF — أو اطبع هذه الصفحة كاملة كملف تعريفي.
              </p>
              <div className="mt-3 flex flex-wrap gap-2">
                <button className="btn-soft" onClick={() => nav("reports")}>
                  <Icon name="chevron" size={14} /> الذهاب إلى التقارير
                </button>
                <button className="btn-ghost" onClick={() => window.print()}>
                  <Icon name="printer" size={14} /> طباعة هذه الصفحة
                </button>
              </div>
            </div>
          </Reveal>
        </div>
      </div>
    </div>
  );
}
