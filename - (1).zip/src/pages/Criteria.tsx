import { useMemo, useState } from "react";
import { criterionStatus, toAr, type Evidence } from "../data";
import { useStore } from "../store";
import { useNav } from "../nav";
import { EvidenceCard, EvidenceForm } from "./Evidence";
import { EightStar, GoldDivider, Icon, Kicker, Modal, Reveal, SectionHead, StatusBadge } from "../components/ui";
import { cn } from "../utils/cn";

/* ===================== صفحة قائمة المعايير ===================== */
export function CriteriaPage() {
  const { state } = useStore();
  const nav = useNav();
  const statuses = state.criteria.map((c) => criterionStatus(c, state.evidence));
  const counts = {
    موثق: statuses.filter((s) => s === "موثق").length,
    "قيد التوثيق": statuses.filter((s) => s === "قيد التوثيق").length,
    "غير موثق": statuses.filter((s) => s === "غير موثق").length,
  };

  return (
    <div className="mx-auto max-w-6xl px-4 py-10 md:px-6">
      <SectionHead
        no="القسم ٠٣"
        title="معايير الأداء الوظيفي"
        desc="المحور الأساسي للملف: أحد عشر معياراً تستند إليها كل شواهد التوثيق. اضغط أي معيار لفتح صفحته التفصيلية ومؤشراته وشواهده وتأمله المهني."
        icon="grid"
      />

      <Reveal className="mb-6 flex flex-wrap items-center gap-3">
        <StatusBadge status="موثق" className="!px-3.5 !py-1.5 !text-xs" />
        <StatusBadge status="قيد التوثيق" className="!px-3.5 !py-1.5 !text-xs" />
        <StatusBadge status="غير موثق" className="!px-3.5 !py-1.5 !text-xs" />
        <span className="text-xs font-bold text-ink-faint">
          {counts["موثق"]} موثق · {counts["قيد التوثيق"]} قيد التوثيق · {counts["غير موثق"]} غير موثق
        </span>
      </Reveal>

      {/* شريط تنقل سريع بين المعايير */}
      <Reveal className="no-print mb-8">
        <div className="flex gap-2 overflow-x-auto pb-2">
          {state.criteria.map((c) => (
            <button
              key={c.id}
              onClick={() => nav("criterion", c.id)}
              className="shrink-0 rounded-full border border-gold-300/70 bg-cream px-3.5 py-1.5 text-xs font-bold text-pine-800 transition hover:border-gold-500 hover:bg-gold-100"
            >
              {toAr(c.id)} · {c.title.length > 18 ? c.title.slice(0, 18) + "…" : c.title}
            </button>
          ))}
        </div>
      </Reveal>

      <div className="grid grid-cols-1 gap-4 md:grid-cols-2 xl:grid-cols-3">
        {state.criteria.map((c, i) => {
          const st = criterionStatus(c, state.evidence);
          const n = state.evidence.filter((e) => e.criterionId === c.id).length;
          return (
            <Reveal key={c.id} delay={Math.min(i * 70, 420)}>
              <button
                onClick={() => nav("criterion", c.id)}
                className="card-lift gold-sheen group relative flex h-full w-full flex-col overflow-hidden rounded-xl border border-gold-200/80 bg-cream p-5 text-right shadow-soft hover:border-gold-400"
              >
                <span className="pointer-events-none absolute -left-3 -top-5 font-display text-[86px] font-bold leading-none text-gold-200/50 transition-colors group-hover:text-gold-300/60">
                  {toAr(c.id)}
                </span>
                <div className="relative">
                  <span className="flex h-11 w-11 items-center justify-center rounded-full border border-gold-400/50 bg-gold-100/50 text-gold-600 transition-colors group-hover:border-gold-500 group-hover:bg-gold-100">
                    <Icon name={c.icon} size={21} />
                  </span>
                  <div className="mt-3 flex items-center justify-between gap-2">
                    <span className="text-[10px] font-extrabold tracking-wide text-gold-600">المعيار {toAr(c.id)}</span>
                    <StatusBadge status={st} />
                  </div>
                  <h3 className="mt-1.5 font-display text-[22px] font-bold leading-snug text-pine-900">{c.title}</h3>
                  <p className="mt-2 line-clamp-2 text-xs leading-relaxed text-ink-soft">{c.short}</p>
                  <div className="mt-4 flex items-center justify-between border-t border-sand-deep/60 pt-3">
                    <span className="text-[11px] font-bold text-ink-faint">
                      {n} من الشواهد المرفوعة
                    </span>
                    <span className="flex items-center gap-1 text-xs font-extrabold text-pine-700 transition-transform group-hover:-translate-x-1">
                      عرض المعيار <Icon name="chevron" size={14} />
                    </span>
                  </div>
                </div>
              </button>
            </Reveal>
          );
        })}
      </div>
    </div>
  );
}

/* ===================== صفحة تفصيل المعيار ===================== */
export function CriterionPage({ id }: { id: number }) {
  const { state } = useStore();
  const nav = useNav();
  const c = state.criteria.find((x) => x.id === id);
  const [adding, setAdding] = useState(false);
  const [editing, setEditing] = useState<Evidence | null>(null);

  const mine = useMemo(() => state.evidence.filter((e) => e.criterionId === id).sort((a, b) => b.date.localeCompare(a.date)), [state.evidence, id]);

  if (!c) {
    return (
      <div className="mx-auto max-w-3xl px-4 py-24 text-center">
        <p className="font-display text-2xl text-pine-900">المعيار غير موجود</p>
        <button className="btn-primary mt-5" onClick={() => nav("criteria")}>
          العودة إلى المعايير
        </button>
      </div>
    );
  }

  const st = criterionStatus(c, state.evidence);
  const docPct = Math.min(100, (mine.length / 3) * 100);

  return (
    <div className="mx-auto max-w-6xl px-4 py-10 md:px-6">
      <button onClick={() => nav("criteria")} className="no-print mb-6 flex items-center gap-1.5 text-xs font-extrabold text-pine-700 transition hover:text-pine-900">
        <Icon name="chevron" size={14} className="rotate-180" />
        جميع المعايير
      </button>

      {/* ترويسة المعيار */}
      <Reveal>
        <div className="relative overflow-hidden rounded-xl border border-gold-300/60 bg-pine-900 p-6 text-cream shadow-soft md:p-8">
          <EightStar className="anim-spin-slow absolute -left-10 -top-10 h-40 w-40 text-gold-500/15" />
          <EightStar className="anim-spin-slow absolute -bottom-14 -right-8 h-44 w-44 text-gold-500/10" />
          <div className="relative flex flex-wrap items-center gap-5">
            <span className="flex h-16 w-16 shrink-0 items-center justify-center rounded-full border-2 border-gold-400/60 bg-pine-800 text-gold-300">
              <Icon name={c.icon} size={30} />
            </span>
            <div className="min-w-0 flex-1">
              <Kicker>معيار أداء وظيفي · {toAr(c.id)} من {toAr(state.criteria.length)}</Kicker>
              <h2 className="font-display text-3xl font-bold leading-tight md:text-4xl">{c.title}</h2>
              <p className="mt-2 max-w-2xl text-sm leading-relaxed text-cream/80">{c.short}</p>
            </div>
            <div className="flex flex-col items-center gap-2">
              <StatusBadge status={st} />
              <span className="font-display text-3xl font-bold text-gold-300">{toAr(mine.length)}</span>
              <span className="-mt-1.5 text-[10px] font-bold text-cream/70">شاهد مرفوع</span>
            </div>
          </div>
        </div>
      </Reveal>

      <div className="mt-6 grid grid-cols-1 gap-6 lg:grid-cols-3">
        {/* العمود الرئيسي */}
        <div className="space-y-6 lg:col-span-2">
          {/* المؤشرات */}
          <Reveal>
            <div className="rounded-xl border border-gold-200/80 bg-cream p-5 shadow-soft md:p-6">
              <h3 className="flex items-center gap-2 font-display text-xl font-bold text-pine-900">
                <Icon name="target" size={19} className="text-gold-600" /> مؤشرات المعيار
              </h3>
              <ol className="mt-4 space-y-3">
                {c.indicators.map((ind, i) => (
                  <li key={i} className="flex items-start gap-3">
                    <span className="mt-0.5 flex h-6 w-6 shrink-0 items-center justify-center rounded-full border border-gold-400/60 bg-gold-100/60 font-display text-sm font-bold text-gold-700">
                      {toAr(i + 1)}
                    </span>
                    <span className="text-sm leading-relaxed text-ink">{ind}</span>
                  </li>
                ))}
              </ol>
            </div>
          </Reveal>

          {/* الشواهد المطلوبة */}
          <Reveal>
            <div className="rounded-xl border border-gold-200/80 bg-cream p-5 shadow-soft md:p-6">
              <h3 className="flex items-center gap-2 font-display text-xl font-bold text-pine-900">
                <Icon name="clipboard" size={19} className="text-gold-600" /> الشواهد المطلوبة
              </h3>
              <ul className="mt-4 grid grid-cols-1 gap-2 sm:grid-cols-2">
                {c.required.map((r) => (
                  <li key={r} className="flex items-center gap-2 rounded-lg border border-sand-deep/70 bg-cream-deep/60 px-3 py-2 text-xs font-bold text-ink">
                    <Icon name="check" size={13} className="shrink-0 text-olive-500" />
                    {r}
                  </li>
                ))}
              </ul>
            </div>
          </Reveal>

          {/* الشواهد المرفوعة */}
          <Reveal>
            <div className="rounded-xl border border-gold-200/80 bg-cream p-5 shadow-soft md:p-6">
              <div className="flex flex-wrap items-center justify-between gap-3">
                <h3 className="flex items-center gap-2 font-display text-xl font-bold text-pine-900">
                  <Icon name="folder" size={19} className="text-gold-600" /> الشواهد المرفوعة
                  <span className="rounded-full bg-pine-50 px-2 py-0.5 text-xs font-bold text-pine-700">{mine.length}</span>
                </h3>
                <button className="btn-gold no-viewer" onClick={() => setAdding(true)}>
                  <Icon name="plus" size={15} /> إضافة شاهد
                </button>
              </div>
              {mine.length === 0 ? (
                <div className="mt-4 rounded-lg border border-dashed border-sand-dark bg-cream-deep/50 py-10 text-center text-xs font-bold text-ink-faint">
                  لم يُرفع أي شاهد لهذا المعيار بعد — ابدأ بالوثائق الأقرب إلى يدك.
                </div>
              ) : (
                <div className="mt-4 grid grid-cols-1 gap-4 sm:grid-cols-2">
                  {mine.map((e) => (
                    <EvidenceCard key={e.id} e={e} onEdit={(x) => setEditing(x)} compact />
                  ))}
                </div>
              )}
            </div>
          </Reveal>

          {/* الأدلة والتقارير */}
          <div className="grid grid-cols-1 gap-6 md:grid-cols-2">
            <Reveal>
              <div className="h-full rounded-xl border border-gold-200/80 bg-cream p-5 shadow-soft">
                <h3 className="flex items-center gap-2 font-display text-lg font-bold text-pine-900">
                  <Icon name="shield" size={17} className="text-gold-600" /> الأدلة
                </h3>
                <ul className="mt-3 space-y-2.5">
                  {c.proofs.map((p) => (
                    <li key={p} className="flex items-start gap-2 text-xs leading-relaxed text-ink">
                      <span className="mt-1.5 h-1.5 w-1.5 shrink-0 rounded-full bg-gold-500" />
                      {p}
                    </li>
                  ))}
                </ul>
              </div>
            </Reveal>
            <Reveal delay={90}>
              <div className="h-full rounded-xl border border-gold-200/80 bg-cream p-5 shadow-soft">
                <h3 className="flex items-center gap-2 font-display text-lg font-bold text-pine-900">
                  <Icon name="printer" size={17} className="text-gold-600" /> التقارير
                </h3>
                <ul className="mt-3 space-y-2.5">
                  {c.reports.map((r) => (
                    <li key={r}>
                      <button className="flex w-full items-start justify-between gap-2 rounded-lg border border-sand-deep/70 bg-cream-deep/60 px-3 py-2 text-right text-xs font-bold text-ink transition hover:border-gold-400" onClick={() => nav("reports")}>
                        <span className="leading-relaxed">{r}</span>
                        <Icon name="chevron" size={13} className="mt-0.5 shrink-0 text-gold-500" />
                      </button>
                    </li>
                  ))}
                </ul>
              </div>
            </Reveal>
          </div>

          {/* الأثر والتأمل */}
          <div className="grid grid-cols-1 gap-6 md:grid-cols-2">
            <Reveal>
              <div className="h-full rounded-xl border-r-4 border-gold-500 bg-gold-100/50 p-5">
                <h3 className="flex items-center gap-2 font-display text-lg font-bold text-gold-700">
                  <Icon name="sparkles" size={17} /> الأثر
                </h3>
                <p className="mt-2.5 text-sm leading-relaxed text-ink">{c.impact}</p>
              </div>
            </Reveal>
            <Reveal delay={90}>
              <div className="relative h-full rounded-xl bg-pine-900 p-5 text-cream">
                <Icon name="quote" size={30} className="absolute left-4 top-4 text-gold-500/40" />
                <h3 className="font-display text-lg font-bold text-gold-300">التأمل المهني</h3>
                <p className="mt-2.5 font-display text-lg leading-relaxed text-cream/90">«{c.reflection}»</p>
              </div>
            </Reveal>
          </div>
        </div>

        {/* العمود الجانبي */}
        <div className="space-y-5">
          <Reveal className="lg:sticky lg:top-24">
            <div className="space-y-5">
              <div className="rounded-xl border border-gold-200/80 bg-cream p-5 shadow-soft">
                <h4 className="font-display text-lg font-bold text-pine-900">مستوى التوثيق</h4>
                <div className="mt-3 flex items-center justify-between text-xs font-bold">
                  <StatusBadge status={st} />
                  <span className="text-ink-faint">{toAr(mine.length)} / 3 شواهد</span>
                </div>
                <div className="mt-3 h-2 overflow-hidden rounded-full bg-sand-deep">
                  <div className="h-full rounded-full bg-gradient-to-l from-gold-400 to-pine-600 transition-all duration-1000" style={{ width: `${docPct}%` }} />
                </div>
                <p className="mt-2.5 text-[11px] leading-relaxed text-ink-faint">
                  {st === "موثق" ? "اكتمل توثيق هذا المعيار — استمر في إضافة الشواهد الداعمة." : st === "قيد التوثيق" ? "تبقّى شواهد قليلة لإكمال التوثيق الكامل لهذا المعيار." : "ابدأ برفع أول شاهد حتى ينتقل المعيار إلى حالة قيد التوثيق."}
                </p>
              </div>

              <div className="rounded-xl border border-gold-200/80 bg-cream p-5 shadow-soft">
                <h4 className="mb-3 font-display text-lg font-bold text-pine-900">التنقل السريع</h4>
                <ul className="space-y-1">
                  {state.criteria.map((x) => {
                    const s = criterionStatus(x, state.evidence);
                    const active = x.id === c.id;
                    return (
                      <li key={x.id}>
                        <button
                          onClick={() => nav("criterion", x.id)}
                          className={cn(
                            "flex w-full items-center gap-2.5 rounded-lg px-2.5 py-1.5 text-right text-xs font-bold transition",
                            active ? "bg-pine-900 text-cream" : "text-ink hover:bg-gold-100/60"
                          )}
                        >
                          <span
                            className={cn(
                              "h-2 w-2 shrink-0 rounded-full",
                              s === "موثق" ? "bg-pine-500" : s === "قيد التوثيق" ? "bg-gold-500" : "bg-sand-dark",
                              active && "bg-gold-300"
                            )}
                          />
                          <span className="truncate">
                            {toAr(x.id)}. {x.title}
                          </span>
                        </button>
                      </li>
                    );
                  })}
                </ul>
              </div>

              <button className="btn-soft w-full" onClick={() => nav("evidence")}>
                <Icon name="folder" size={15} /> السجل الموحد للشواهد
              </button>
            </div>
          </Reveal>
        </div>
      </div>

      <GoldDivider className="no-print mx-auto mt-10 max-w-md" />

      <Modal open={adding} onClose={() => setAdding(false)} title={`إضافة شاهد — ${c.title}`} wide>
        <EvidenceForm defaultCriterion={c.id} onDone={() => setAdding(false)} />
      </Modal>
      <Modal open={!!editing} onClose={() => setEditing(null)} title="تعديل الشاهد" wide>
        {editing && <EvidenceForm initial={editing} onDone={() => setEditing(null)} />}
      </Modal>
    </div>
  );
}
