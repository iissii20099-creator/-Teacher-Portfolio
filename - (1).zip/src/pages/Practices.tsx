import { useMemo, useState } from "react";
import { fmtDate, PRACTICE_CATEGORIES, type Practice, type PracticeCategory } from "../data";
import { useStore } from "../store";
import { ConfirmDelete, Field, FileChip, Icon, Modal, Reveal, SectionHead } from "../components/ui";
import { cn } from "../utils/cn";

/* ===================== نموذج ممارسة ===================== */
export function PracticeForm({ initial, onDone }: { initial?: Practice; onDone: () => void }) {
  const { state, addPractice, updatePractice } = useStore();
  const [f, setF] = useState(() =>
    initial
      ? { ...initial, files: initial.files }
      : {
          id: "",
          title: "",
          category: "دروس نموذجية" as PracticeCategory,
          desc: "",
          goal: "",
          strategy: "",
          impact: "",
          image: state.practices[0]?.image,
          files: [] as { name: string; type: string }[],
          date: new Date().toISOString().slice(0, 10),
        }
  );
  const [msg, setMsg] = useState("");
  const set = <K extends keyof Practice>(k: K, v: Practice[K]) => setF((x) => ({ ...x, [k]: v }));

  const submit = () => {
    if (!f.title.trim()) {
      setMsg("أدخل عنوان الممارسة أولاً.");
      return;
    }
    const payload = {
      title: f.title.trim(),
      category: f.category,
      desc: f.desc.trim(),
      goal: f.goal.trim(),
      strategy: f.strategy.trim(),
      impact: f.impact.trim(),
      image: f.image || undefined,
      files: f.files,
      date: f.date,
    };
    if (initial) updatePractice(initial.id, payload);
    else addPractice(payload);
    onDone();
  };

  const libImages = state.files.filter((x) => x.kind === "صورة" && x.url);

  return (
    <div className="space-y-4">
      <Field label="عنوان الممارسة *">
        <input className="inp" value={f.title} onChange={(e) => set("title", e.target.value)} placeholder="مثال: درس نموذجي «النص النقدي»" />
      </Field>
      <div className="grid grid-cols-2 gap-3">
        <Field label="التصنيف">
          <select className="inp" value={f.category} onChange={(e) => set("category", e.target.value as PracticeCategory)}>
            {PRACTICE_CATEGORIES.map((c) => (
              <option key={c}>{c}</option>
            ))}
          </select>
        </Field>
        <Field label="التاريخ">
          <input type="date" className="inp" value={f.date} onChange={(e) => set("date", e.target.value)} />
        </Field>
      </div>
      <Field label="وصف الممارسة">
        <textarea className="inp min-h-[64px]" value={f.desc} onChange={(e) => set("desc", e.target.value)} placeholder="ما الذي حدث داخل الحصة أو النشاط؟" />
      </Field>
      <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
        <Field label="الهدف">
          <input className="inp" value={f.goal} onChange={(e) => set("goal", e.target.value)} placeholder="ماذا ننتظر أن يتعلم الطالب؟" />
        </Field>
        <Field label="الاستراتيجية">
          <input className="inp" value={f.strategy} onChange={(e) => set("strategy", e.target.value)} placeholder="الاستراتيجية أو النمط المستخدم" />
        </Field>
      </div>
      <Field label="الأثر">
        <input className="inp" value={f.impact} onChange={(e) => set("impact", e.target.value)} placeholder="ما الأثر القابل للقياس؟" />
      </Field>
      <Field label="رابط الصورة">
        <input className="inp" dir="ltr" value={f.image ?? ""} onChange={(e) => set("image", e.target.value)} placeholder="https://…" />
      </Field>
      {libImages.length > 0 && (
        <Field label="أو صورة من مكتبة الملفات">
          <select className="inp" value="" onChange={(e) => { const it = libImages.find((x) => x.name === e.target.value); if (it?.url) set("image", it.url); }}>
            <option value="">— اختيار من المكتبة —</option>
            {libImages.map((x) => (
              <option key={x.id}>{x.name}</option>
            ))}
          </select>
        </Field>
      )}
      {msg && <p className="rounded-lg border border-gold-500/40 bg-gold-100 px-3 py-2 text-xs font-bold text-gold-700">{msg}</p>}
      <div className="flex justify-end gap-2 border-t border-gold-200/60 pt-4">
        <button className="btn-ghost" onClick={onDone}>إلغاء</button>
        <button className="btn-primary" onClick={submit}>
          <Icon name="check" size={15} /> {initial ? "حفظ التعديلات" : "إضافة الممارسة"}
        </button>
      </div>
    </div>
  );
}

/* ===================== صفحة الممارسات ===================== */
export function PracticesPage() {
  const { state, removePractice } = useStore();
  const [cat, setCat] = useState("");
  const [viewing, setViewing] = useState<Practice | null>(null);
  const [editing, setEditing] = useState<Practice | null>(null);
  const [adding, setAdding] = useState(false);

  const list = useMemo(() => state.practices.filter((p) => (cat ? p.category === cat : true)), [state.practices, cat]);

  return (
    <div className="mx-auto max-w-6xl px-4 py-10 md:px-6">
      <div className="flex flex-wrap items-end justify-between gap-4">
        <SectionHead
          no="القسم ٠٥"
          title="الممارسات المهنية"
          desc="معرض بصري لما يحدث فعلياً داخل الصف: دروس نموذجية، استراتيجيات، أنشطة، مشاريع طلابية، ومبادرات — كل ممارسة موثقة بهدفها واستراتيجيتها وأثرها."
          icon="bookOpen"
        />
        <button className="btn-primary no-print no-viewer shrink-0" onClick={() => setAdding(true)}>
          <Icon name="plus" size={16} /> إضافة ممارسة
        </button>
      </div>

      <Reveal className="mb-7 flex gap-2 overflow-x-auto pb-2">
        <button
          onClick={() => setCat("")}
          className={cn(
            "shrink-0 rounded-full border px-4 py-1.5 text-xs font-bold transition",
            !cat ? "border-pine-800 bg-pine-900 text-cream" : "border-gold-300/70 bg-cream text-pine-800 hover:border-gold-500"
          )}
        >
          الكل ({state.practices.length})
        </button>
        {PRACTICE_CATEGORIES.map((c) => {
          const n = state.practices.filter((p) => p.category === c).length;
          if (!n) return null;
          return (
            <button
              key={c}
              onClick={() => setCat(c)}
              className={cn(
                "shrink-0 rounded-full border px-4 py-1.5 text-xs font-bold transition",
                cat === c ? "border-pine-800 bg-pine-900 text-cream" : "border-gold-300/70 bg-cream text-pine-800 hover:border-gold-500"
              )}
            >
              {c} ({n})
            </button>
          );
        })}
      </Reveal>

      {list.length === 0 ? (
        <div className="rounded-xl border border-dashed border-sand-dark bg-cream/60 py-16 text-center">
          <Icon name="bookOpen" size={30} className="mx-auto text-gold-400" />
          <p className="mt-3 text-sm font-bold text-ink-soft">لا توجد ممارسات في هذا التصنيف بعد</p>
        </div>
      ) : (
        <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {list.map((p, i) => (
            <Reveal key={p.id} delay={Math.min(i * 70, 400)}>
              <button
                onClick={() => setViewing(p)}
                className="card-lift group relative block h-full w-full overflow-hidden rounded-xl border border-gold-200/80 bg-cream text-right shadow-soft hover:border-gold-400"
              >
                <div className="relative h-44 overflow-hidden">
                  <img src={p.image} alt={p.title} className="h-full w-full object-cover transition-transform duration-700 group-hover:scale-105" />
                  <span className="absolute inset-0 bg-gradient-to-t from-pine-950/60 via-transparent to-transparent" />
                  <span className="absolute right-3 top-3 rounded-full border border-gold-300/60 bg-pine-950/70 px-2.5 py-0.5 text-[10px] font-extrabold text-gold-200 backdrop-blur">
                    {p.category}
                  </span>
                </div>
                <div className="p-4">
                  <h4 className="font-display text-lg font-bold leading-snug text-pine-900">{p.title}</h4>
                  <p className="mt-1.5 line-clamp-2 text-xs leading-relaxed text-ink-soft">{p.desc}</p>
                  <div className="mt-3 flex items-center justify-between border-t border-sand-deep/60 pt-2.5">
                    <span className="text-[10px] font-bold text-ink-faint">{fmtDate(p.date)}</span>
                    <span className="flex items-center gap-1 text-[11px] font-extrabold text-pine-700">
                      التفاصيل <Icon name="chevron" size={12} className="transition-transform group-hover:-translate-x-1" />
                    </span>
                  </div>
                </div>
              </button>
            </Reveal>
          ))}
        </div>
      )}

      {/* نافذة التفاصيل */}
      <Modal open={!!viewing} onClose={() => setViewing(null)} title={viewing?.title ?? ""} wide>
        {viewing && (
          <div className="space-y-4">
            {viewing.image && <img src={viewing.image} alt={viewing.title} className="h-52 w-full rounded-lg border border-gold-200 object-cover" />}
            <div className="flex flex-wrap items-center gap-2">
              <span className="rounded-full border border-gold-400/40 bg-gold-100/70 px-2.5 py-0.5 text-[11px] font-extrabold text-gold-700">{viewing.category}</span>
              <span className="text-[11px] font-bold text-ink-faint">{fmtDate(viewing.date)}</span>
            </div>
            <p className="text-sm leading-relaxed text-ink">{viewing.desc}</p>
            <div className="grid grid-cols-1 gap-3 sm:grid-cols-3">
              <div className="rounded-lg border-r-2 border-pine-600 bg-pine-50 p-3">
                <p className="text-[10px] font-extrabold text-pine-700">الهدف</p>
                <p className="mt-1 text-xs font-bold leading-relaxed text-ink">{viewing.goal || "—"}</p>
              </div>
              <div className="rounded-lg border-r-2 border-gold-500 bg-gold-100/60 p-3">
                <p className="text-[10px] font-extrabold text-gold-700">الاستراتيجية</p>
                <p className="mt-1 text-xs font-bold leading-relaxed text-ink">{viewing.strategy || "—"}</p>
              </div>
              <div className="rounded-lg border-r-2 border-olive-500 bg-olive-100/70 p-3">
                <p className="text-[10px] font-extrabold text-olive-600">الأثر</p>
                <p className="mt-1 text-xs font-bold leading-relaxed text-ink">{viewing.impact || "—"}</p>
              </div>
            </div>
            {viewing.files.length > 0 && (
              <div>
                <p className="lbl">الملفات المرفقة</p>
                <div className="flex flex-wrap gap-2">
                  {viewing.files.map((fl) => (
                    <span key={fl.name} className="flex items-center gap-2 rounded-lg border border-sand-deep bg-cream-deep/60 px-3 py-1.5 text-xs font-bold text-ink">
                      <Icon name="fileText" size={13} className="text-gold-500" /> {fl.name} <FileChip type={fl.type} />
                    </span>
                  ))}
                </div>
              </div>
            )}
            <div className="flex items-center justify-between border-t border-gold-200/60 pt-3">
              <ConfirmDelete onConfirm={() => { removePractice(viewing.id); setViewing(null); }} />
              <button
                className="btn-soft no-viewer"
                onClick={() => {
                  setViewing(null);
                  setEditing(viewing);
                }}
              >
                <Icon name="pencil" size={14} /> تعديل الممارسة
              </button>
            </div>
          </div>
        )}
      </Modal>

      <Modal open={adding} onClose={() => setAdding(false)} title="إضافة ممارسة تعليمية" wide>
        <PracticeForm onDone={() => setAdding(false)} />
      </Modal>
      <Modal open={!!editing} onClose={() => setEditing(null)} title="تعديل الممارسة" wide>
        {editing && <PracticeForm initial={editing} onDone={() => setEditing(null)} />}
      </Modal>
    </div>
  );
}
