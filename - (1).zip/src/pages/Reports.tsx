import { useState } from "react";
import { criterionStatus, fmtDate, toAr, type State } from "../data";
import { useStore } from "../store";
import { EightStar, GoldDivider, Icon, Reveal, SectionHead } from "../components/ui";

interface ReportDef {
  id: string;
  icon: string;
  title: string;
  desc: string;
  build: (s: State) => { stats: [string, string][]; cols: string[]; rows: string[][] };
}

const REPORTS: ReportDef[] = [
  {
    id: "performance",
    icon: "grid",
    title: "تقرير الأداء المهني",
    desc: "ملخص شامل لحالة توثيق المعايير الأحد عشر وعدد شواهد كل معيار.",
    build: (s) => ({
      stats: [
        ["المعايير الموثقة بالكامل", `${s.criteria.filter((c) => criterionStatus(c, s.evidence) === "موثق").length} من ${s.criteria.length}`],
        ["إجمالي الشواهد", toAr(s.evidence.length)],
        ["معدل الاكتمال", `${Math.floor((s.evidence.length / Math.max(1, s.criteria.length * 3)) * 100)}%`],
      ],
      cols: ["#", "المعيار", "الحالة", "الشواهد"],
      rows: s.criteria.map((c) => [toAr(c.id), c.title, criterionStatus(c, s.evidence), toAr(s.evidence.filter((e) => e.criterionId === c.id).length)]),
    }),
  },
  {
    id: "evidence",
    icon: "folder",
    title: "تقرير الشواهد",
    desc: "سجل كامل بكل الشواهد: العنوان، النوع، المعيار المرتبط، والتاريخ.",
    build: (s) => ({
      stats: [
        ["إجمالي الشواهد", toAr(s.evidence.length)],
        ["الفصل الأول", toAr(s.evidence.filter((e) => e.semester === "الفصل الأول").length)],
        ["الفصل الثاني", toAr(s.evidence.filter((e) => e.semester === "الفصل الثاني").length)],
      ],
      cols: ["الشاهد", "النوع", "المعيار", "الفصل", "التاريخ"],
      rows: [...s.evidence]
        .sort((a, b) => b.date.localeCompare(a.date))
        .map((e) => [e.title, e.type, `معيار ${toAr(e.criterionId)}`, e.semester, fmtDate(e.date)]),
    }),
  },
  {
    id: "development",
    icon: "rocket",
    title: "تقرير التطوير المهني",
    desc: "الدورات والورش والمؤتمرات ومجتمعات التعلم مع إجمالي الساعات.",
    build: (s) => ({
      stats: [
        ["إجمالي الساعات", `${toAr(s.development.reduce((a, b) => a + b.hours, 0))} ساعة`],
        ["عدد العناصر", toAr(s.development.length)],
        ["دورات وورش", toAr(s.development.filter((d) => d.kind === "دورة" || d.kind === "ورشة عمل").length)],
      ],
      cols: ["العنصر", "النوع", "الجهة", "الساعات", "التاريخ"],
      rows: s.development.map((d) => [d.title, d.kind, d.org, toAr(d.hours), fmtDate(d.date)]),
    }),
  },
  {
    id: "results",
    icon: "chartUp",
    title: "تقرير نتائج الطلاب",
    desc: "المتوسطات قبل وبعد التدخل، نسبة التحسن، وتوزيع المستويات.",
    build: (s) => {
      const g = Math.round((s.student.after - s.student.before));
      return {
        stats: [
          ["المتوسط قبل التدخل", toAr(s.student.before)],
          ["المتوسط بعد التدخل", toAr(s.student.after)],
          ["نسبة التحسن", `${Math.round((g / s.student.before) * 100)}%`],
          ["الطلاب المستفيدون", toAr(s.student.students)],
        ],
        cols: ["المحور", "قبل", "بعد", "الارتفاع"],
        rows: s.student.subjects.map((x) => [x.name, toAr(x.before), toAr(x.after), `+${toAr(Math.round((x.after - x.before) * 10) / 10)}`]),
      };
    },
  },
  {
    id: "activities",
    icon: "bookOpen",
    title: "تقرير الأنشطة والممارسات",
    desc: "الممارسات المهنية الموثقة: الدروس والاستراتيجيات والمشاريع والمبادرات.",
    build: (s) => ({
      stats: [
        ["عدد الممارسات", toAr(s.practices.length)],
        ["دروس نموذجية", toAr(s.practices.filter((p) => p.category === "دروس نموذجية").length)],
        ["مشاريع طلابية", toAr(s.practices.filter((p) => p.category === "مشاريع الطلاب").length)],
      ],
      cols: ["الممارسة", "التصنيف", "الاستراتيجية", "التاريخ"],
      rows: s.practices.map((p) => [p.title, p.category, p.strategy, fmtDate(p.date)]),
    }),
  },
  {
    id: "initiatives",
    icon: "flag",
    title: "تقرير المبادرات",
    desc: "المبادرات المدرسية والمهنية التي أطلقها المعلم أو شارك فيها.",
    build: (s) => ({
      stats: [
        ["عدد المبادرات", toAr(s.achievements.filter((a) => a.kind === "مبادرة").length + s.development.filter((d) => d.kind === "مبادرة").length)],
        ["مبادرات طلابية", toAr(s.practices.filter((p) => p.category === "مبادرات").length)],
      ],
      cols: ["المبادرة", "النوع", "الوصف", "التاريخ"],
      rows: [
        ...s.achievements.filter((a) => a.kind === "مبادرة").map((a) => [a.title, "إنجاز موثق", a.desc, fmtDate(a.date)]),
        ...s.development.filter((d) => d.kind === "مبادرة").map((d) => [d.title, "تطوير مهني", d.org, fmtDate(d.date)]),
        ...s.practices.filter((p) => p.category === "مبادرات").map((p) => [p.title, "ممارسة صفية", p.impact, fmtDate(p.date)]),
      ],
    }),
  },
];

export function ReportsPage() {
  const { state } = useStore();
  const [openId, setOpenId] = useState<string | null>(null);
  const report = REPORTS.find((r) => r.id === openId);

  if (report) {
    const data = report.build(state);
    const t = state.teacher;
    return (
      <div className="mx-auto max-w-4xl px-4 py-10 md:px-6">
        <div className="no-print mb-6 flex flex-wrap items-center justify-between gap-3">
          <button className="btn-ghost" onClick={() => setOpenId(null)}>
            <Icon name="chevron" size={14} className="rotate-180" /> جميع التقارير
          </button>
          <div className="flex gap-2">
            <button className="btn-primary" onClick={() => window.print()}>
              <Icon name="printer" size={15} /> طباعة التقرير
            </button>
            <button className="btn-gold" onClick={() => window.print()} title="سيُفتح حوار الطباعة — اختر «حفظ كـ PDF»">
              <Icon name="download" size={15} /> تصدير PDF
            </button>
          </div>
        </div>

        <div className="print-root rounded-xl border border-gold-300/70 bg-cream p-6 shadow-soft md:p-10">
          {/* ترويسة التقرير */}
          <div className="text-center">
            <p className="text-sm font-extrabold text-ink-soft">{t.school}</p>
            <p className="mt-0.5 text-xs font-bold text-ink-faint">ملف إنجاز المعلم — {t.year}</p>
            <GoldDivider className="mx-auto mt-4 max-w-sm" />
            <h2 className="mt-4 font-display text-3xl font-bold text-pine-900 md:text-4xl">{report.title}</h2>
            <p className="mt-2 text-xs font-bold text-ink-soft">
              المعلم: {t.name} · {t.specialty} · أُنشئ في {fmtDate(new Date().toISOString())}
            </p>
          </div>

          {/* الملخص */}
          <div className="mt-7 grid grid-cols-2 gap-3 sm:grid-cols-3">
            {data.stats.map(([k, v]) => (
              <div key={k} className="rounded-lg border border-gold-300/50 bg-gold-100/40 p-3 text-center">
                <p className="font-display text-2xl font-bold text-pine-800">{v}</p>
                <p className="mt-0.5 text-[11px] font-extrabold text-ink-soft">{k}</p>
              </div>
            ))}
          </div>

          {/* الجدول */}
          <div className="mt-7 overflow-x-auto rounded-lg border border-sand-deep">
            <table className="w-full min-w-[560px] text-right">
              <thead>
                <tr className="border-b-2 border-gold-400/60 bg-pine-900 text-cream">
                  {data.cols.map((c) => (
                    <th key={c} className="px-3.5 py-2.5 text-xs font-extrabold">
                      {c}
                    </th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {data.rows.map((r, i) => (
                  <tr key={i} className={`border-b border-sand-deep/50 ${i % 2 === 1 ? "bg-cream-deep/40" : ""}`}>
                    {r.map((cell, j) => (
                      <td key={j} className={`px-3.5 py-2.5 text-xs ${j === 0 ? "font-extrabold text-pine-900" : "font-bold text-ink"}`}>
                        {cell}
                      </td>
                    ))}
                  </tr>
                ))}
              </tbody>
            </table>
          </div>

          {/* التوقيعات */}
          <div className="mt-10 grid grid-cols-3 gap-6 text-center">
            {[
              ["المعلم", t.name],
              ["رئيس القسم", ""],
              ["المدير", ""],
            ].map(([role, name]) => (
              <div key={role}>
                <p className="text-xs font-extrabold text-ink-soft">{role}</p>
                {name && <p className="mt-1 text-xs font-bold text-pine-800">{name}</p>}
                <div className="mt-6 border-b border-dashed border-ink-faint" />
                <p className="mt-1.5 text-[10px] font-bold text-ink-faint">التوقيع / التاريخ</p>
              </div>
            ))}
          </div>

          <p className="mt-8 text-center text-[10px] font-bold text-ink-faint">
            وُثق هذا التقرير إلكترونياً ضمن ملف إنجاز المعلم · {t.school} · {t.year}
          </p>
        </div>
      </div>
    );
  }

  return (
    <div className="mx-auto max-w-6xl px-4 py-10 md:px-6">
      <SectionHead
        no="القسم ١٠"
        title="مكتبة التقارير"
        desc="تقارير رسمية تُبنى تلقائياً من بيانات ملفك، قابلة للعرض والطباعة والتصدير كملف PDF — جاهزة للتقديم للإدارة أو للتقييم."
        icon="printer"
      />
      <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-3">
        {REPORTS.map((r, i) => {
          const preview = r.build(state);
          return (
            <Reveal key={r.id} delay={Math.min(i * 70, 380)}>
              <button
                onClick={() => setOpenId(r.id)}
                className="card-lift gold-sheen group flex h-full w-full flex-col overflow-hidden rounded-xl border border-gold-200/80 bg-cream text-right shadow-soft hover:border-gold-400"
              >
                <div className="flex items-center gap-3.5 p-5">
                  <span className="flex h-12 w-12 shrink-0 items-center justify-center rounded-lg border border-gold-300/70 bg-gold-100/50 text-gold-600">
                    <Icon name={r.icon} size={22} />
                  </span>
                  <div>
                    <h3 className="font-display text-xl font-bold text-pine-900">{r.title}</h3>
                    <p className="text-[11px] font-bold text-ink-faint">{preview.rows.length} سطراً من البيانات</p>
                  </div>
                </div>
                <div className="flex flex-1 flex-col justify-between px-5 pb-5">
                  <p className="line-clamp-2 text-xs leading-relaxed text-ink-soft">{r.desc}</p>
                  <span className="mt-3 flex items-center gap-1.5 border-t border-sand-deep/60 pt-3 text-xs font-extrabold text-pine-700">
                    <Icon name="printer" size={13} className="text-gold-500" />
                    فتح التقرير
                    <Icon name="chevron" size={13} className="transition-transform group-hover:-translate-x-1" />
                  </span>
                </div>
                <EightStar className="absolute -left-4 -top-4 h-14 w-14 text-gold-200/40" />
              </button>
            </Reveal>
          );
        })}
      </div>
    </div>
  );
}
