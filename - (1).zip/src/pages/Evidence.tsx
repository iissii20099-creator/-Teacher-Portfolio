import { useMemo, useState } from "react";
import {
  EVIDENCE_TYPES,
  fmtDate,
  toAr,
  type Evidence,
  type EvidenceType,
  type Semester,
} from "../data";
import { useStore } from "../store";
import { useNav } from "../nav";
import { ConfirmDelete, Field, FileChip, Icon, Modal, Reveal, SectionHead } from "../components/ui";
import { isDriveUrl, useDrive, type DriveFile } from "../googleDrive";
import { cn } from "../utils/cn";

/* ===================== رفع الملفات ===================== */
function readFileAsUrl(file: File, cb: (url: string) => void) {
  const r = new FileReader();
  r.onload = () => cb(String(r.result));
  r.readAsDataURL(file);
}

/* ===================== نموذج الشاهد ===================== */
interface Draft {
  title: string;
  desc: string;
  type: EvidenceType;
  date: string;
  criterionId: number;
  subject: string;
  semester: Semester;
  link: string;
  notes: string;
  image?: string;
  file?: { name: string; url?: string };
}

export function EvidenceForm({
  initial,
  defaultCriterion,
  onDone,
}: {
  initial?: Evidence;
  defaultCriterion?: number;
  onDone?: () => void;
}) {
  const { state, addEvidence, updateEvidence } = useStore();
  const [f, setF] = useState<Draft>(() =>
    initial
      ? {
          title: initial.title,
          desc: initial.desc,
          type: initial.type,
          date: initial.date,
          criterionId: initial.criterionId,
          subject: initial.subject,
          semester: initial.semester,
          link: initial.link ?? "",
          notes: initial.notes ?? "",
          image: initial.image,
          file: initial.file,
        }
      : {
          title: "",
          desc: "",
          type: "PDF",
          date: new Date().toISOString().slice(0, 10),
          criterionId: defaultCriterion ?? state.criteria[0]?.id ?? 1,
          subject: state.teacher.specialty,
          semester: "الفصل الأول",
          link: "",
          notes: "",
        }
  );
  const [msg, setMsg] = useState("");
  const set = <K extends keyof Draft>(k: K, v: Draft[K]) => setF((x) => ({ ...x, [k]: v }));

  /* اختيار من Google Drive */
  const d = useDrive();
  const [dq, setDq] = useState("");
  const [dr, setDr] = useState<DriveFile[]>([]);
  const [dBusy, setDBusy] = useState(false);
  const [dErr, setDErr] = useState("");
  const [dMsg, setDMsg] = useState("");
  const doSearch = async () => {
    setDBusy(true);
    setDErr("");
    setDMsg("");
    try {
      setDr(await d.search(dq));
    } catch (e) {
      setDErr(e instanceof Error ? e.message : "تعذّر الوصول إلى Drive.");
    } finally {
      setDBusy(false);
    }
  };
  const pickDrive = (r: DriveFile) => {
    if (r.mimeType.startsWith("image/")) {
      set("image", `https://drive.google.com/thumbnail?id=${r.id}&sz=w1200`);
      setDMsg(`تم اختيار «${r.name}» كصورة من Drive ✓`);
    } else {
      set("file", { name: r.name, url: r.webViewLink });
      if (r.mimeType === "application/pdf") set("type", "PDF");
      setDMsg(`تم ربط «${r.name}» من Drive كملف شاهد ✓`);
    }
    setDErr("");
  };

  const onFile = (file: File | undefined, isImg: boolean) => {
    if (!file) return;
    if (file.size > 700_000) {
      setMsg("حجم الملف يتجاوز 700 ك.ب — تم تسجيل اسم الملف فقط.");
      if (isImg) return;
      set("file", { name: file.name });
      return;
    }
    setMsg("");
    readFileAsUrl(file, (url) => {
      if (isImg) set("image", url);
      else set("file", { name: file.name, url });
    });
  };

  const submit = () => {
    if (!f.title.trim()) {
      setMsg("أدخل عنوان الشاهد أولاً.");
      return;
    }
    const payload = {
      title: f.title.trim(),
      desc: f.desc.trim(),
      type: f.type,
      date: f.date,
      criterionId: f.criterionId,
      subject: f.subject.trim() || "عام",
      semester: f.semester,
      link: f.link.trim() || undefined,
      notes: f.notes.trim() || undefined,
      image: f.image || undefined,
      file: f.file,
    };
    if (initial) updateEvidence(initial.id, payload);
    else addEvidence(payload);
    onDone?.();
  };

  return (
    <div className="space-y-4">
      <Field label="عنوان الشاهد *">
        <input className="inp" value={f.title} onChange={(e) => set("title", e.target.value)} placeholder="مثال: تحليل نتائج الاختبار الشهري" />
      </Field>
      <Field label="وصف الشاهد">
        <textarea className="inp min-h-[70px]" value={f.desc} onChange={(e) => set("desc", e.target.value)} placeholder="ما الذي يوثقه هذا الشاهد؟" />
      </Field>
      <div className="grid grid-cols-2 gap-3">
        <Field label="نوع الشاهد">
          <select className="inp" value={f.type} onChange={(e) => set("type", e.target.value as EvidenceType)}>
            {EVIDENCE_TYPES.map((t) => (
              <option key={t}>{t}</option>
            ))}
          </select>
        </Field>
        <Field label="التاريخ">
          <input type="date" className="inp" value={f.date} onChange={(e) => set("date", e.target.value)} />
        </Field>
        <Field label="المعيار المرتبط">
          <select className="inp" value={f.criterionId} onChange={(e) => set("criterionId", Number(e.target.value))}>
            {state.criteria.map((c) => (
              <option key={c.id} value={c.id}>
                {toAr(c.id)} · {c.title}
              </option>
            ))}
          </select>
        </Field>
        <Field label="الفصل الدراسي">
          <select className="inp" value={f.semester} onChange={(e) => set("semester", e.target.value as Semester)}>
            <option>الفصل الأول</option>
            <option>الفصل الثاني</option>
          </select>
        </Field>
        <Field label="المادة">
          <input className="inp" value={f.subject} onChange={(e) => set("subject", e.target.value)} />
        </Field>
        <Field label="رابط خارجي (اختياري)">
          <input className="inp" dir="ltr" value={f.link} onChange={(e) => set("link", e.target.value)} placeholder="https://" />
        </Field>
      </div>
      <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
        <div>
          <span className="lbl">رفع ملف (PDF / Word / PowerPoint / Excel / فيديو)</span>
          <label className="flex cursor-pointer items-center justify-center gap-2 rounded-lg border border-dashed border-gold-400/60 bg-gold-100/40 px-3 py-3 text-xs font-bold text-pine-800 transition hover:bg-gold-100">
            <Icon name="upload" size={15} />
            {f.file ? f.file.name : "اختيار ملف من الجهاز (حتى 700 ك.ب)"}
            <input type="file" className="hidden" onChange={(e) => onFile(e.target.files?.[0], false)} />
          </label>
        </div>
        <div>
          <span className="lbl">رفع صورة</span>
          <label className="flex cursor-pointer items-center justify-center gap-2 rounded-lg border border-dashed border-gold-400/60 bg-gold-100/40 px-3 py-3 text-xs font-bold text-pine-800 transition hover:bg-gold-100">
            <Icon name="image" size={15} />
            {f.image ? "تم اختيار صورة ✓" : "اختيار صورة من الجهاز"}
            <input type="file" accept="image/*" className="hidden" onChange={(e) => onFile(e.target.files?.[0], true)} />
          </label>
        </div>
      </div>
      {state.files.some((x) => x.kind === "صورة" && x.url) && (
        <Field label="أو اختيار صورة من مكتبة الملفات">
          <select
            className="inp"
            value={f.image && state.files.some((x) => x.url === f.image) ? state.files.find((x) => x.url === f.image)?.name ?? "" : ""}
            onChange={(e) => {
              const it = state.files.find((x) => x.name === e.target.value);
              if (it?.url) set("image", it.url);
            }}
          >
            <option value="">— بدون —</option>
            {state.files
              .filter((x) => x.kind === "صورة" && x.url)
              .map((x) => (
                <option key={x.id}>{x.name}</option>
              ))}
          </select>
        </Field>
      )}
      {d.enabled && d.ready && !!d.account && (
        <div className="rounded-lg border border-pine-600/25 bg-pine-50/70 p-3.5">
          <div className="flex flex-wrap items-center gap-2">
            <Icon name="link" size={15} className="text-pine-700" />
            <span className="text-xs font-extrabold text-pine-900">اختيار من Google Drive</span>
            <span className="text-[10px] font-bold text-ink-faint">صورة أو مستند — يُربط برابط Drive</span>
          </div>
          <div className="mt-2.5 flex gap-2">
            <input
              className="inp !py-1.5 text-xs"
              placeholder="ابحث باسم الملف… (اتركه فارغاً لعرض أحدث الملفات)"
              value={dq}
              onChange={(e) => setDq(e.target.value)}
            />
            <button className="btn-soft shrink-0 !py-1.5" onClick={doSearch} disabled={dBusy}>
              {dBusy ? "جارٍ البحث…" : "بحث"}
            </button>
          </div>
          {dErr && <p className="mt-2 text-[11px] font-bold text-clay">{dErr}</p>}
          {dMsg && <p className="mt-2 text-[11px] font-bold text-pine-700">{dMsg}</p>}
          {dr.length > 0 && (
            <ul className="mt-2.5 max-h-44 space-y-1.5 overflow-y-auto pl-1">
              {dr.map((r) => {
                const isImg = r.mimeType.startsWith("image/");
                const chosen = (isImg && f.image?.includes(r.id)) || (!isImg && f.file?.url === r.webViewLink);
                return (
                  <li key={r.id}>
                    <button
                      onClick={() => pickDrive(r)}
                      className={cn(
                        "flex w-full items-center gap-2.5 rounded-lg border px-2.5 py-1.5 text-right transition",
                        chosen ? "border-pine-600 bg-pine-100" : "border-sand-deep bg-cream hover:border-gold-400"
                      )}
                    >
                      {r.thumbnailLink ? (
                        <img src={r.thumbnailLink} alt="" className="h-9 w-9 rounded-md border border-gold-200 object-cover" />
                      ) : (
                        <span className="flex h-9 w-9 shrink-0 items-center justify-center rounded-md bg-sand-deep/60">
                          <Icon name="fileText" size={15} className="text-ink-faint" />
                        </span>
                      )}
                      <span className="min-w-0 flex-1">
                        <span className="block truncate text-xs font-bold text-ink">{r.name}</span>
                        <span className="block truncate text-[10px] font-bold text-ink-faint" dir="ltr">{r.mimeType}</span>
                      </span>
                      {chosen && <Icon name="check" size={15} className="shrink-0 text-pine-700" />}
                    </button>
                  </li>
                );
              })}
            </ul>
          )}
        </div>
      )}
      <Field label="ملاحظات المعلم">
        <textarea className="inp min-h-[60px]" value={f.notes} onChange={(e) => set("notes", e.target.value)} placeholder="سياق إضافي يفسر قيمة هذا الشاهد…" />
      </Field>
      {msg && <p className="rounded-lg border border-gold-500/40 bg-gold-100 px-3 py-2 text-xs font-bold text-gold-700">{msg}</p>}
      <div className="flex items-center justify-end gap-2 border-t border-gold-200/60 pt-4">
        <button className="btn-ghost" onClick={onDone}>
          إلغاء
        </button>
        <button className="btn-primary" onClick={submit}>
          <Icon name="check" size={15} />
          {initial ? "حفظ التعديلات" : "إضافة الشاهد"}
        </button>
      </div>
    </div>
  );
}

/* ===================== معاينة الشاهد ===================== */
export function EvidencePreview({ e }: { e: Evidence }) {
  const { state } = useStore();
  const crit = state.criteria.find((c) => c.id === e.criterionId);
  return (
    <div className="space-y-4">
      {e.image && <img src={e.image} alt={e.title} className="h-56 w-full rounded-lg border border-gold-200 object-cover" />}
      {e.file?.url && (e.type === "PDF" || e.file.url.startsWith("data:application/pdf")) && (
        <iframe title={e.file.name} src={e.file.url} className="h-96 w-full rounded-lg border border-gold-200 bg-white" />
      )}
      {!e.image && !e.file?.url && (
        <div className="flex flex-col items-center gap-2 rounded-lg border border-dashed border-sand-dark bg-cream-deep py-10 text-center">
          <Icon name="folder" size={28} className="text-gold-500" />
          <p className="text-xs font-bold text-ink-soft">لا يوجد محتوى رقمي مرفق — هذا الشاهد موثّق بعنوانه ووصفه</p>
        </div>
      )}
      <div className="flex flex-wrap items-center gap-2">
        <FileChip type={e.type} />
        <span className="rounded-full border border-pine-600/20 bg-pine-50 px-2.5 py-0.5 text-[11px] font-bold text-pine-700">
          المعيار {toAr(e.criterionId)} · {crit?.title}
        </span>
        <span className="text-[11px] font-bold text-ink-faint">{fmtDate(e.date)} · {e.semester} · {e.subject}</span>
      </div>
      {e.desc && <p className="text-sm leading-relaxed text-ink">{e.desc}</p>}
      {e.notes && <p className="rounded-lg bg-gold-100/60 px-3 py-2 text-xs leading-relaxed text-gold-700">ملاحظة المعلم: {e.notes}</p>}
      <div className="flex flex-wrap gap-2">
        {e.file?.url && (
          <a className="btn-primary" href={e.file.url} download={e.file.name || "الملف"}>
            <Icon name="download" size={15} /> تحميل {e.file.name}
          </a>
        )}
        {e.link && (
          <a className="btn-soft" href={e.link} target="_blank" rel="noreferrer">
            <Icon name="external" size={15} /> فتح الرابط الخارجي
          </a>
        )}
      </div>
    </div>
  );
}

/* ===================== تحميل شاهد ===================== */
export function downloadEvidence(e: Evidence) {
  if (e.file?.url) {
    const a = document.createElement("a");
    a.href = e.file.url;
    a.download = e.file.name || "evidence";
    a.click();
  } else if (e.link) {
    window.open(e.link, "_blank");
  } else {
    const txt = `شاهد: ${e.title}\nالمعيار: ${e.criterionId}\nالنوع: ${e.type}\nالتاريخ: ${fmtDate(e.date)}\nالوصف: ${e.desc}\nملاحظات: ${e.notes ?? "—"}`;
    const blob = new Blob(["\ufeff" + txt], { type: "text/plain;charset=utf-8" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `${e.title}.txt`;
    a.click();
    setTimeout(() => URL.revokeObjectURL(url), 4000);
  }
}

/* ===================== بطاقة الشاهد ===================== */
export function EvidenceCard({
  e,
  onEdit,
  compact,
}: {
  e: Evidence;
  onEdit?: (e: Evidence) => void;
  compact?: boolean;
}) {
  const { state, removeEvidence } = useStore();
  const nav = useNav();
  const [preview, setPreview] = useState(false);
  const crit = state.criteria.find((c) => c.id === e.criterionId);
  const fromDrive = isDriveUrl(e.image) || isDriveUrl(e.link) || isDriveUrl(e.file?.url);
  return (
    <div className="card-lift group flex h-full flex-col overflow-hidden rounded-xl border border-gold-200/80 bg-cream shadow-soft hover:border-gold-400/70">
      {e.image && (
        <button className="relative block h-36 w-full overflow-hidden" onClick={() => setPreview(true)} aria-label="عرض الشاهد">
          <img src={e.image} alt={e.title} className="h-full w-full object-cover transition-transform duration-700 group-hover:scale-105" />
          <span className="absolute inset-0 bg-gradient-to-t from-pine-950/40 to-transparent" />
        </button>
      )}
      <div className="flex flex-1 flex-col gap-2.5 p-4">
        <div className="flex items-start justify-between gap-2">
          <span className="flex items-center gap-1.5">
            <FileChip type={e.type} />
            {fromDrive && (
              <span className="inline-flex items-center gap-1 rounded-md border border-pine-600/25 bg-pine-50 px-1.5 py-0.5 text-[10px] font-extrabold text-pine-700" title="المحتوى من Google Drive">
                <Icon name="link" size={10} /> Drive
              </span>
            )}
          </span>
          <span className="text-[10px] font-bold text-ink-faint">{fmtDate(e.date)}</span>
        </div>
        <h4 className="font-display text-lg font-bold leading-snug text-pine-900">{e.title}</h4>
        <button
          className="w-fit rounded-full border border-pine-600/20 bg-pine-50 px-2.5 py-0.5 text-[10px] font-bold text-pine-700 transition hover:bg-pine-100"
          onClick={() => nav("criterion", e.criterionId)}
        >
          المعيار {toAr(e.criterionId)} · {crit?.title}
        </button>
        {!compact && e.desc && <p className="line-clamp-2 text-xs leading-relaxed text-ink-soft">{e.desc}</p>}
        <div className="mt-auto flex items-center gap-1.5 border-t border-sand-deep/60 pt-2.5">
          <button className="icon-btn h-7 px-2.5 text-[11px] font-bold" onClick={() => setPreview(true)}>
            <Icon name="eye" size={13} /> عرض
          </button>
          <button className="icon-btn h-7 px-2.5 text-[11px] font-bold" onClick={() => downloadEvidence(e)}>
            <Icon name="download" size={13} /> تحميل
          </button>
          {onEdit && (
            <button className="icon-btn no-viewer h-7 px-2.5 text-[11px] font-bold" onClick={() => onEdit(e)}>
              <Icon name="pencil" size={13} /> تعديل
            </button>
          )}
          <ConfirmDelete onConfirm={() => removeEvidence(e.id)} label="" />
        </div>
      </div>
      <Modal open={preview} onClose={() => setPreview(false)} title={e.title} wide>
        <EvidencePreview e={e} />
      </Modal>
    </div>
  );
}

/* ===================== صفحة الشواهد ===================== */
export function EvidencePage() {
  const { state } = useStore();
  const [q, setQ] = useState("");
  const [crit, setCrit] = useState(0);
  const [type, setType] = useState("");
  const [sem, setSem] = useState("");
  const [subj, setSubj] = useState("");
  const [sort, setSort] = useState<"desc" | "asc">("desc");
  const [adding, setAdding] = useState(false);
  const [editing, setEditing] = useState<Evidence | null>(null);

  const subjects = useMemo(() => Array.from(new Set(state.evidence.map((e) => e.subject))), [state.evidence]);

  const list = useMemo(() => {
    return state.evidence
      .filter((e) => (q ? (e.title + e.desc).includes(q) : true))
      .filter((e) => (crit ? e.criterionId === crit : true))
      .filter((e) => (type ? e.type === type : true))
      .filter((e) => (sem ? e.semester === sem : true))
      .filter((e) => (subj ? e.subject === subj : true))
      .sort((a, b) => (sort === "desc" ? b.date.localeCompare(a.date) : a.date.localeCompare(b.date)));
  }, [state.evidence, q, crit, type, sem, subj, sort]);

  return (
    <div className="mx-auto max-w-6xl px-4 py-10 md:px-6">
      <div className="flex flex-wrap items-end justify-between gap-4">
        <SectionHead
          no="القسم ٠٧"
          title="السجل الموحد للشواهد"
          desc="جميع شواهد التوثيق في مكان واحد — ابحث، صفِّ حسب المعيار أو النوع أو الفصل، واعرض أو حمّل ما تريد."
          icon="folder"
        />
        <button className="btn-primary no-print no-viewer shrink-0" onClick={() => setAdding(true)}>
          <Icon name="plus" size={16} /> إضافة شاهد
        </button>
      </div>

      <Reveal className="mb-6 rounded-xl border border-gold-200/80 bg-cream/80 p-4 shadow-soft">
        <div className="grid grid-cols-1 gap-3 md:grid-cols-3 lg:grid-cols-6">
          <div className="relative md:col-span-3">
            <Icon name="search" size={15} className="absolute right-3 top-1/2 -translate-y-1/2 text-ink-faint" />
            <input className="inp pr-9" placeholder="ابحث في عناوين الشواهد وأوصافها…" value={q} onChange={(e) => setQ(e.target.value)} />
          </div>
          <select className="inp" value={crit} onChange={(e) => setCrit(Number(e.target.value))}>
            <option value={0}>كل المعايير</option>
            {state.criteria.map((c) => (
              <option key={c.id} value={c.id}>
                المعيار {toAr(c.id)}
              </option>
            ))}
          </select>
          <select className="inp" value={type} onChange={(e) => setType(e.target.value)}>
            <option value="">كل الأنواع</option>
            {EVIDENCE_TYPES.map((t) => (
              <option key={t}>{t}</option>
            ))}
          </select>
          <select className="inp" value={sem} onChange={(e) => setSem(e.target.value)}>
            <option value="">كل الفصول</option>
            <option>الفصل الأول</option>
            <option>الفصل الثاني</option>
          </select>
          <select className="inp" value={subj} onChange={(e) => setSubj(e.target.value)}>
            <option value="">كل المواد</option>
            {subjects.map((s) => (
              <option key={s}>{s}</option>
            ))}
          </select>
        </div>
        <div className="mt-3 flex items-center justify-between text-[11px] font-bold text-ink-faint">
          <span>
            {list.length} من {state.evidence.length} شاهد
          </span>
          <button className="flex items-center gap-1 text-pine-700 hover:text-pine-900" onClick={() => setSort((s) => (s === "desc" ? "asc" : "desc"))}>
            <Icon name="refresh" size={12} /> ترتيب التاريخ {sort === "desc" ? "تنازلياً" : "تصاعدياً"}
          </button>
        </div>
      </Reveal>

      {list.length === 0 ? (
        <div className="rounded-xl border border-dashed border-sand-dark bg-cream/60 py-16 text-center">
          <Icon name="folder" size={30} className="mx-auto text-gold-400" />
          <p className="mt-3 text-sm font-bold text-ink-soft">لا توجد شواهد مطابقة لمعايير التصفية الحالية</p>
        </div>
      ) : (
        <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {list.map((e, i) => (
            <Reveal key={e.id} delay={Math.min(i * 60, 360)}>
              <EvidenceCard e={e} onEdit={(x) => setEditing(x)} />
            </Reveal>
          ))}
        </div>
      )}

      <Modal open={adding} onClose={() => setAdding(false)} title="إضافة شاهد جديد" wide>
        <EvidenceForm onDone={() => setAdding(false)} />
      </Modal>
      <Modal open={!!editing} onClose={() => setEditing(null)} title="تعديل الشاهد" wide>
        {editing && <EvidenceForm initial={editing} onDone={() => setEditing(null)} />}
      </Modal>
    </div>
  );
}
