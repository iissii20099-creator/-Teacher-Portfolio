import { useMemo, useState } from "react";
import { computeStats, downloadText, toAr } from "../data";
import { useStore } from "../store";
import { useNav } from "../nav";
import { EightStar, GoldDivider, Icon, OrnateCard, Reveal, SectionHead } from "../components/ui";
import { cn } from "../utils/cn";

/* ===================== الصفحة الشخصية ===================== */
function resumeHtml(name: string, rows: [string, string][], skills: string[], interests: string[], dev: string[]) {
  const li = (arr: string[]) => arr.map((x) => `<li>${x}</li>`).join("");
  return `<!doctype html><html lang="ar" dir="rtl"><head><meta charset="utf-8"><title>السيرة الذاتية — ${name}</title></head>
<body style="font-family:Tahoma,Arial,sans-serif;background:#f2ecdc;color:#29312b;padding:40px;max-width:720px;margin:auto;">
<div style="background:#fbf9f1;border:1px solid #d6bc80;padding:32px;border-radius:10px;">
<h1 style="font-size:26px;color:#143125;margin:0 0 4px;">${name}</h1>
<p style="color:#8f6e33;font-weight:bold;margin:0 0 20px;">ملف إنجاز المعلم</p>
${rows.map(([k, v]) => `<p style="margin:6px 0;"><b style="color:#215340;">${k}: </b>${v}</p>`).join("")}
<h2 style="font-size:18px;color:#215340;border-right:3px solid #b4914e;padding-right:8px;">المهارات</h2>
<ul style="line-height:1.9">${li(skills)}</ul>
<h2 style="font-size:18px;color:#215340;border-right:3px solid #b4914e;padding-right:8px;">الاهتمامات المهنية</h2>
<ul style="line-height:1.9">${li(interests)}</ul>
<h2 style="font-size:18px;color:#215340;border-right:3px solid #b4914e;padding-right:8px;">أبرز التطوير المهني</h2>
<ul style="line-height:1.9">${li(dev)}</ul>
</div></body></html>`;
}

export function ProfilePage() {
  const { state } = useStore();
  const nav = useNav();
  const t = state.teacher;
  const stats = computeStats(state);

  const rows: [string, string, string][] = [
    ["name", "الاسم", t.name],
    ["cap", "التخصص", t.specialty],
    ["book", "المؤهل العلمي", t.degree],
    ["building", "جهة العمل", t.school],
    ["clock", "سنوات الخبرة", `${t.experience} سنوات`],
    ["shield", "الرخصة المهنية", t.license],
    ["sparkles", "عدد الدورات والورش", `${stats.courses}`],
  ];

  const downloadResume = () => {
    downloadText(
      `السيرة-الذاتية-${t.name}.html`,
      resumeHtml(
        t.name,
        [
          ["جهة العمل", t.school],
          ["التخصص", t.specialty],
          ["المؤهل العلمي", t.degree],
          ["سنوات الخبرة", `${t.experience} سنوات`],
          ["الرخصة المهنية", t.license],
          ["العام الدراسي", t.year],
        ],
        t.skills,
        t.interests,
        state.development.map((d) => `${d.kind}: ${d.title} — ${d.org} (${d.hours} ساعة)`)
      ),
      "text/html"
    );
  };

  return (
    <div className="mx-auto max-w-6xl px-4 py-10 md:px-6">
      <SectionHead
        no="القسم ٠٢"
        title="الملف الشخصي"
        desc="بطاقة تعريف مهنية كاملة: البيانات الأساسية، المؤهلات، المهارات، والاهتمامات — مع إمكانية تحميل السيرة الذاتية."
        icon="user"
      />

      <div className="grid grid-cols-1 gap-6 lg:grid-cols-3">
        {/* الصورة والبطاقة */}
        <Reveal>
          <div className="space-y-5">
            <OrnateCard className="overflow-hidden">
              <div className="relative">
                <img src={t.photo} alt={t.name} className="h-72 w-full object-cover" />
                <div className="absolute inset-x-0 bottom-0 h-24 bg-gradient-to-t from-pine-950/70 to-transparent" />
                <EightStar className="anim-spin-slow absolute right-3 top-3 h-8 w-8 text-gold-200/70" />
              </div>
              <div className="p-5 text-center">
                <h3 className="font-display text-2xl font-bold text-pine-900">{t.name}</h3>
                <p className="mt-1 text-xs font-bold text-ink-soft">
                  معلم {t.specialty} · {t.experience} سنوات خبرة
                </p>
                <button className="btn-primary mt-4 w-full" onClick={downloadResume}>
                  <Icon name="download" size={15} /> تحميل السيرة الذاتية
                </button>
                <button className="btn-ghost mt-2 w-full" onClick={() => nav("development")}>
                  <Icon name="rocket" size={15} /> سجل التطوير الكامل
                </button>
              </div>
            </OrnateCard>
          </div>
        </Reveal>

        {/* البيانات */}
        <Reveal delay={100} className="lg:col-span-2">
          <div className="h-full space-y-5">
            <div className="rounded-xl border border-gold-200/80 bg-cream p-5 shadow-soft md:p-6">
              <ul className="divide-y divide-sand-deep/60">
                {rows.map(([icon, label, value]) => (
                  <li key={label} className="flex items-center gap-3.5 py-3">
                    <span className="flex h-9 w-9 shrink-0 items-center justify-center rounded-lg border border-gold-300/60 bg-gold-100/50 text-gold-600">
                      <Icon name={icon} size={16} />
                    </span>
                    <span className="w-36 shrink-0 text-xs font-extrabold text-ink-faint">{label}</span>
                    <span className="text-sm font-bold text-ink">{value}</span>
                  </li>
                ))}
              </ul>
            </div>

            <div className="grid grid-cols-1 gap-5 md:grid-cols-2">
              <div className="rounded-xl border border-gold-200/80 bg-cream p-5 shadow-soft">
                <h4 className="flex items-center gap-2 font-display text-lg font-bold text-pine-900">
                  <Icon name="target" size={17} className="text-gold-600" /> المهارات
                </h4>
                <div className="mt-3.5 flex flex-wrap gap-2">
                  {t.skills.map((s) => (
                    <span key={s} className="rounded-full border border-pine-600/20 bg-pine-50 px-3 py-1 text-xs font-bold text-pine-800">
                      {s}
                    </span>
                  ))}
                </div>
              </div>
              <div className="rounded-xl border border-gold-200/80 bg-cream p-5 shadow-soft">
                <h4 className="flex items-center gap-2 font-display text-lg font-bold text-pine-900">
                  <Icon name="heart" size={17} className="text-gold-600" /> الاهتمامات المهنية
                </h4>
                <div className="mt-3.5 flex flex-wrap gap-2">
                  {t.interests.map((s) => (
                    <span key={s} className="rounded-full border border-gold-400/40 bg-gold-100/60 px-3 py-1 text-xs font-bold text-gold-700">
                      {s}
                    </span>
                  ))}
                </div>
              </div>
            </div>

            <div className="rounded-xl border border-gold-200/80 bg-cream p-5 shadow-soft">
              <div className="flex items-center justify-between">
                <h4 className="flex items-center gap-2 font-display text-lg font-bold text-pine-900">
                  <Icon name="cap" size={17} className="text-gold-600" /> أبرز الدورات والبرامج
                </h4>
                <button className="flex items-center gap-1 text-xs font-extrabold text-pine-700 hover:text-pine-900" onClick={() => nav("development")}>
                  الكل <Icon name="chevron" size={13} />
                </button>
              </div>
              <ul className="mt-3 space-y-2">
                {state.development.slice(0, 3).map((d) => (
                  <li key={d.id} className="flex items-center gap-3 rounded-lg border border-sand-deep/70 bg-cream-deep/60 px-3.5 py-2.5">
                    <Icon name={d.kind === "بحث" ? "bookOpen" : "cap"} size={16} className="shrink-0 text-gold-500" />
                    <span className="flex-1 truncate text-xs font-bold text-ink">{d.title}</span>
                    <span className="shrink-0 text-[10px] font-bold text-ink-faint">{d.org}</span>
                  </li>
                ))}
              </ul>
            </div>
          </div>
        </Reveal>
      </div>
      <GoldDivider className="mt-12" />
    </div>
  );
}

/* ===================== الخطة التعليمية ===================== */
const STATUS_CLS: Record<string, string> = {
  منفذة: "border-pine-600/25 bg-pine-50 text-pine-700",
  "قيد التنفيذ": "border-gold-500/35 bg-gold-100 text-gold-700",
  مجدولة: "border-sand-dark/60 bg-sand-deep/50 text-ink-faint",
};

export function PlanPage() {
  const { state } = useStore();
  const nav = useNav();
  const [term, setTerm] = useState<"t1" | "t2">("t1");
  const rows = state.plan[term];
  const totalHours = useMemo(() => rows.reduce((a, b) => a + b.hours, 0), [rows]);

  return (
    <div className="mx-auto max-w-6xl px-4 py-10 md:px-6">
      <SectionHead
        no="القسم ٠٤"
        title="الخطة التعليمية"
        desc="الخطة الفصلية وتوزيع المنهج على الأسابيع والحصص، مع حالة كل وحدة وأوراق العمل والواجبات المساندة — شهادة حيّة للمعيار السادس."
        icon="layout"
      />

      <Reveal className="mb-6 flex flex-wrap items-center justify-between gap-3">
        <div className="flex rounded-lg border border-gold-300/70 bg-cream p-1">
          {(["t1", "t2"] as const).map((k) => (
            <button
              key={k}
              onClick={() => setTerm(k)}
              className={cn(
                "rounded-md px-5 py-1.5 text-sm font-extrabold transition",
                term === k ? "bg-pine-900 text-cream shadow-soft" : "text-ink-soft hover:text-pine-800"
              )}
            >
              {k === "t1" ? "الفصل الدراسي الأول" : "الفصل الدراسي الثاني"}
            </button>
          ))}
        </div>
        <span className="rounded-full border border-gold-300/70 bg-gold-100/60 px-3 py-1 text-xs font-extrabold text-gold-700">
          إجمالي الحصص: {toAr(totalHours)}
        </span>
      </Reveal>

      <div className="grid grid-cols-1 gap-6 lg:grid-cols-3">
        <Reveal className="lg:col-span-2">
          <div className="overflow-x-auto rounded-xl border border-gold-200/80 bg-cream shadow-soft">
            <table className="w-full min-w-[640px] text-right">
              <thead>
                <tr className="border-b border-gold-300/50 bg-pine-900 text-cream">
                  <th className="px-4 py-3 text-xs font-extrabold">الوحدة</th>
                  <th className="px-4 py-3 text-xs font-extrabold">المحتوى</th>
                  <th className="px-4 py-3 text-xs font-extrabold">الأسابيع</th>
                  <th className="px-4 py-3 text-xs font-extrabold">الحصص</th>
                  <th className="px-4 py-3 text-xs font-extrabold">الحالة</th>
                </tr>
              </thead>
              <tbody>
                {rows.map((r, i) => (
                  <tr key={r.unit} className={cn("border-b border-sand-deep/50 transition hover:bg-gold-100/40", i % 2 === 1 && "bg-cream-deep/40")}>
                    <td className="px-4 py-3.5 text-xs font-extrabold text-pine-900">{r.unit}</td>
                    <td className="px-4 py-3.5 text-xs font-bold text-ink-soft">{r.content}</td>
                    <td className="px-4 py-3.5 text-xs font-bold text-ink">{r.weeks}</td>
                    <td className="px-4 py-3.5 text-center font-display text-lg font-bold text-pine-800">{toAr(r.hours)}</td>
                    <td className="px-4 py-3.5">
                      <span className={cn("rounded-full border px-2.5 py-0.5 text-[10px] font-extrabold", STATUS_CLS[r.status])}>{r.status}</span>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
          <div className="mt-4 rounded-xl border border-gold-200/80 bg-cream p-5 shadow-soft">
            <h4 className="flex items-center gap-2 font-display text-lg font-bold text-pine-900">
              <Icon name="clipboard" size={17} className="text-gold-600" /> الأنشطة المخططة في الجدول
            </h4>
            <ul className="mt-3 grid grid-cols-1 gap-2 sm:grid-cols-2">
              {rows.map((r) => (
                <li key={r.unit} className="rounded-lg border border-sand-deep/70 bg-cream-deep/60 px-3 py-2 text-[11px] leading-relaxed text-ink">
                  <b className="text-pine-800">{r.unit.split(":")[0]}:</b> {r.activities}
                </li>
              ))}
            </ul>
          </div>
        </Reveal>

        <div className="space-y-5">
          <Reveal delay={100}>
            <div className="rounded-xl border border-gold-200/80 bg-cream p-5 shadow-soft">
              <h4 className="flex items-center gap-2 font-display text-lg font-bold text-pine-900">
                <Icon name="fileText" size={17} className="text-gold-600" /> أوراق العمل والواجبات
              </h4>
              <ul className="mt-3 space-y-2">
                {state.works.map((w) => (
                  <li key={w.id} className="flex items-center gap-2.5 rounded-lg border border-sand-deep/70 bg-cream-deep/60 px-3 py-2">
                    <span className="rounded-md border border-gold-400/40 bg-gold-100/70 px-1.5 py-0.5 text-[9px] font-extrabold text-gold-700">{w.type}</span>
                    <span className="flex-1 truncate text-xs font-bold text-ink">{w.title}</span>
                    <span className="text-[10px] font-bold text-ink-faint">{w.week}</span>
                  </li>
                ))}
              </ul>
            </div>
          </Reveal>
          <Reveal delay={160}>
            <div className="rounded-xl bg-pine-900 p-5 text-cream">
              <h4 className="font-display text-lg font-bold text-gold-300">ارتباط بالمعيار</h4>
              <p className="mt-2 text-xs leading-relaxed text-cream/75">
                هذه الخطة هي الشاهد الأساسي للمعيار السادس «إعداد وتنفيذ خطة التعلم» — راجع الصفحة التفصيلية للمعيار لبقية الشواهد.
              </p>
              <button className="btn-gold mt-4 w-full" onClick={() => nav("criterion", 6)}>
                <Icon name="chevron" size={14} /> فتح المعيار السادس
              </button>
            </div>
          </Reveal>
        </div>
      </div>
    </div>
  );
}
