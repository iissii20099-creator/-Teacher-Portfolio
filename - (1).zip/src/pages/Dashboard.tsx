import { useEffect, useRef, useState } from "react";
import { criterionStatus, downloadText, fmtDate, toAr, type Criterion, type State } from "../data";
import { useStore } from "../store";
import { computeCompletion } from "../data";
import { ConfirmDelete, Field, FileChip, Icon, Modal, Reveal, SectionHead, StatusBadge, Switch } from "../components/ui";
import { EvidenceForm } from "./Evidence";
import { PracticeForm } from "./Practices";
import { AchievementForm } from "./Achievements";
import { DevForm } from "./Analysis";
import { isDriveUrl, useDrive } from "../googleDrive";
import { SyncPanel } from "../sync";
import { OrganizePanel } from "../organize";
import { copyText } from "../share";
import { cn } from "../utils/cn";

type TabId = "personal" | "criteria" | "evidence" | "dev" | "practices" | "ach" | "files" | "gdrive" | "settings";

const TABS: { id: TabId; label: string; icon: string }[] = [
  { id: "personal", label: "البيانات الشخصية", icon: "user" },
  { id: "criteria", label: "المعايير", icon: "grid" },
  { id: "evidence", label: "الشواهد", icon: "folder" },
  { id: "dev", label: "التطوير المهني", icon: "rocket" },
  { id: "practices", label: "الممارسات", icon: "bookOpen" },
  { id: "ach", label: "الإنجازات", icon: "trophy" },
  { id: "files", label: "الملفات والصور", icon: "upload" },
  { id: "gdrive", label: "Google Drive", icon: "link" },
  { id: "settings", label: "النسخ والإعدادات", icon: "settings" },
];

const CRIT_ICONS = ["clipboard", "users", "heart", "layers", "chartUp", "book", "monitor", "sprout", "clock", "scan", "scale", "target", "flag", "star"];

/* ===================== تبويب البيانات الشخصية ===================== */
function PersonalTab() {
  const { state, updateTeacher } = useStore();
  const t = state.teacher;
  const [f, setF] = useState({ ...t, skillsText: t.skills.join("، "), interestsText: t.interests.join("، ") });
  const [saved, setSaved] = useState(false);
  const save = () => {
    const { skillsText, interestsText, ...rest } = f;
    updateTeacher({
      ...rest,
      skills: skillsText.split(/[،,]/).map((x) => x.trim()).filter(Boolean),
      interests: interestsText.split(/[،,]/).map((x) => x.trim()).filter(Boolean),
      experience: Number(f.experience) || 0,
    });
    setSaved(true);
    setTimeout(() => setSaved(false), 2500);
  };
  const set = <K extends keyof typeof f>(k: K, v: (typeof f)[K]) => setF((x) => ({ ...x, [k]: v }));
  return (
    <div className="rounded-xl border border-gold-200/80 bg-cream p-5 shadow-soft md:p-6">
      <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
        <Field label="الاسم الكامل">
          <input className="inp" value={f.name} onChange={(e) => set("name", e.target.value)} />
        </Field>
        <Field label="التخصص">
          <input className="inp" value={f.specialty} onChange={(e) => set("specialty", e.target.value)} />
        </Field>
        <Field label="المدرسة">
          <input className="inp" value={f.school} onChange={(e) => set("school", e.target.value)} />
        </Field>
        <Field label="العام الدراسي">
          <input className="inp" value={f.year} onChange={(e) => set("year", e.target.value)} />
        </Field>
        <Field label="المؤهل العلمي">
          <input className="inp" value={f.degree} onChange={(e) => set("degree", e.target.value)} />
        </Field>
        <Field label="الرخصة المهنية">
          <input className="inp" value={f.license} onChange={(e) => set("license", e.target.value)} />
        </Field>
        <Field label="سنوات الخبرة">
          <input type="number" min={0} className="inp" value={f.experience} onChange={(e) => set("experience", Number(e.target.value))} />
        </Field>
        <Field label="رابط الصورة الشخصية">
          <input className="inp" dir="ltr" value={f.photo} onChange={(e) => set("photo", e.target.value)} />
        </Field>
        <Field label="المهارات (افصل بينها بفاصلة)">
          <textarea className="inp min-h-[64px]" value={f.skillsText} onChange={(e) => set("skillsText", e.target.value)} />
        </Field>
        <Field label="الاهتمامات المهنية (افصل بينها بفاصلة)">
          <textarea className="inp min-h-[64px]" value={f.interestsText} onChange={(e) => set("interestsText", e.target.value)} />
        </Field>
      </div>
      <div className="mt-5 flex items-center gap-3 border-t border-gold-200/60 pt-4">
        <button className="btn-primary" onClick={save}>
          <Icon name="check" size={15} /> حفظ البيانات
        </button>
        {saved && <span className="text-xs font-extrabold text-pine-700">تم الحفظ ✓</span>}
      </div>
    </div>
  );
}

/* ===================== تبويب المعايير ===================== */
function CriteriaTab() {
  const { state, updateCriterion, addCriterion, removeCriterion } = useStore();
  const [open, setOpen] = useState<number | null>(null);
  const [newTitle, setNewTitle] = useState("");
  const [newShort, setNewShort] = useState("");
  const [newIcon, setNewIcon] = useState("target");
  const [draft, setDraft] = useState<Criterion | null>(null);

  return (
    <div className="space-y-4">
      {state.criteria.map((c) => (
        <div key={c.id} className="rounded-xl border border-gold-200/80 bg-cream shadow-soft">
          <div className="flex flex-wrap items-center gap-3 p-4">
            <span className="font-display text-2xl font-bold text-gold-500">{toAr(c.id)}</span>
            <span className="flex-1 font-display text-lg font-bold text-pine-900">{c.title}</span>
            <StatusBadge status={criterionStatus(c, state.evidence)} />
            <button
              className="icon-btn"
              onClick={() => {
                if (open === c.id) setOpen(null);
                else {
                  setOpen(c.id);
                  setDraft({ ...c });
                }
              }}
              aria-label="تعديل"
            >
              <Icon name="pencil" size={14} />
            </button>
            <ConfirmDelete onConfirm={() => removeCriterion(c.id)} />
          </div>
          {open === c.id && draft && (
            <div className="space-y-3 border-t border-gold-200/60 p-4">
              <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
                <Field label="اسم المعيار">
                  <input className="inp" value={draft.title} onChange={(e) => setDraft({ ...draft, title: e.target.value })} />
                </Field>
                <Field label="الأيقونة">
                  <select className="inp" value={draft.icon} onChange={(e) => setDraft({ ...draft, icon: e.target.value })}>
                    {CRIT_ICONS.map((ic) => (
                      <option key={ic} value={ic}>{ic}</option>
                    ))}
                  </select>
                </Field>
              </div>
              <Field label="الوصف المختصر">
                <textarea className="inp min-h-[54px]" value={draft.short} onChange={(e) => setDraft({ ...draft, short: e.target.value })} />
              </Field>
              <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
                <Field label="المؤشرات (سطر لكل مؤشر)">
                  <textarea className="inp min-h-[90px]" value={draft.indicators.join("\n")} onChange={(e) => setDraft({ ...draft, indicators: e.target.value.split("\n").filter((x) => x.trim()) })} />
                </Field>
                <Field label="الشواهد المطلوبة (سطر لكل شاهد)">
                  <textarea className="inp min-h-[90px]" value={draft.required.join("\n")} onChange={(e) => setDraft({ ...draft, required: e.target.value.split("\n").filter((x) => x.trim()) })} />
                </Field>
                <Field label="الأثر">
                  <textarea className="inp min-h-[60px]" value={draft.impact} onChange={(e) => setDraft({ ...draft, impact: e.target.value })} />
                </Field>
                <Field label="التأمل المهني">
                  <textarea className="inp min-h-[60px]" value={draft.reflection} onChange={(e) => setDraft({ ...draft, reflection: e.target.value })} />
                </Field>
              </div>
              <div className="flex justify-end gap-2">
                <button className="btn-ghost" onClick={() => setOpen(null)}>إلغاء</button>
                <button
                  className="btn-primary"
                  onClick={() => {
                    updateCriterion(c.id, draft);
                    setOpen(null);
                  }}
                >
                  <Icon name="check" size={15} /> حفظ المعيار
                </button>
              </div>
            </div>
          )}
        </div>
      ))}

      <div className="rounded-xl border border-dashed border-gold-400/60 bg-gold-100/30 p-5">
        <h4 className="flex items-center gap-2 font-display text-lg font-bold text-pine-900">
          <Icon name="plus" size={17} className="text-gold-600" /> إضافة معيار جديد
        </h4>
        <div className="mt-3 grid grid-cols-1 gap-3 sm:grid-cols-3">
          <input className="inp" placeholder="اسم المعيار" value={newTitle} onChange={(e) => setNewTitle(e.target.value)} />
          <input className="inp" placeholder="وصف مختصر" value={newShort} onChange={(e) => setNewShort(e.target.value)} />
          <select className="inp" value={newIcon} onChange={(e) => setNewIcon(e.target.value)}>
            {CRIT_ICONS.map((ic) => (
              <option key={ic} value={ic}>{ic}</option>
            ))}
          </select>
        </div>
        <button
          className="btn-primary mt-3"
          onClick={() => {
            if (!newTitle.trim()) return;
            addCriterion({
              title: newTitle.trim(),
              short: newShort.trim() || "معيار إضافي يوثق جانباً من الأداء المهني.",
              indicators: [],
              required: [],
              impact: "—",
              reflection: "—",
              proofs: [],
              reports: [],
              icon: newIcon,
            });
            setNewTitle("");
            setNewShort("");
          }}
        >
          <Icon name="plus" size={15} /> إضافة
        </button>
      </div>
    </div>
  );
}

/* ===================== تبويب الشواهد ===================== */
function EvidenceTab() {
  const { state, removeEvidence } = useStore();
  const [adding, setAdding] = useState(false);
  const [editing, setEditing] = useState<typeof state.evidence[number] | null>(null);
  return (
    <div className="space-y-3">
      <div className="flex items-center justify-between">
        <p className="text-xs font-bold text-ink-soft">{state.evidence.length} شاهد في السجل</p>
        <button className="btn-primary" onClick={() => setAdding(true)}>
          <Icon name="plus" size={15} /> إضافة شاهد
        </button>
      </div>
      {state.evidence.map((e) => (
        <div key={e.id} className="flex flex-wrap items-center gap-3 rounded-xl border border-gold-200/80 bg-cream px-4 py-3 shadow-soft">
          <FileChip type={e.type} />
          <span className="flex-1 truncate text-sm font-bold text-ink">{e.title}</span>
          <span className="text-[11px] font-bold text-ink-faint">معيار {toAr(e.criterionId)} · {fmtDate(e.date)}</span>
          <button className="icon-btn" onClick={() => setEditing(e)} aria-label="تعديل">
            <Icon name="pencil" size={13} />
          </button>
          <ConfirmDelete onConfirm={() => removeEvidence(e.id)} />
        </div>
      ))}
      <Modal open={adding} onClose={() => setAdding(false)} title="إضافة شاهد" wide>
        <EvidenceForm onDone={() => setAdding(false)} />
      </Modal>
      <Modal open={!!editing} onClose={() => setEditing(null)} title="تعديل الشاهد" wide>
        {editing && <EvidenceForm initial={editing} onDone={() => setEditing(null)} />}
      </Modal>
    </div>
  );
}

/* ===================== تبويب الملفات ===================== */
function FilesTab({ onEnableDrive }: { onEnableDrive: () => void }) {
  const { state, addFile, removeFile } = useStore();
  const d = useDrive();
  const [msg, setMsg] = useState("");
  const [busy, setBusy] = useState(false);
  const onDriveFile = async (file: File | undefined) => {
    if (!file || !d.ready) return;
    setBusy(true);
    setMsg(`جارٍ رفع «${file.name}» إلى Google Drive…`);
    try {
      const r = await d.upload(file);
      const isImg = file.type.startsWith("image/");
      addFile({
        name: file.name,
        kind: isImg ? "صورة" : "ملف",
        url: isImg ? `https://drive.google.com/thumbnail?id=${r.id}&sz=w1200` : r.webViewLink,
        size: r.size ?? "—",
        date: new Date().toISOString().slice(0, 10),
      });
      setMsg(`تم رفع «${file.name}» إلى Google Drive وإضافته للمكتبة ✓`);
      void d.refreshAccount();
    } catch (e) {
      setMsg(e instanceof Error ? e.message : "فشل الرفع إلى Google Drive.");
    } finally {
      setBusy(false);
    }
  };
  const onFile = (file: File | undefined, kind: "ملف" | "صورة") => {
    if (!file) return;
    const size = file.size > 1048576 ? `${(file.size / 1048576).toFixed(1)} م.ب` : `${Math.max(1, Math.ceil(file.size / 1024))} ك.ب`;
    const date = new Date().toISOString().slice(0, 10);
    if (file.size > 700_000) {
      addFile({ name: file.name, kind, size, date });
      setMsg(`«${file.name}» أكبر من 700 ك.ب — سُجل اسمه فقط (لحفظ المحتوى كاملاً استخدم رابطاً خارجياً).`);
      return;
    }
    setMsg("");
    const r = new FileReader();
    r.onload = () => {
      addFile({ name: file.name, kind, url: String(r.result), size, date });
      setMsg(`تم رفع «${file.name}» بنجاح ✓`);
    };
    r.readAsDataURL(file);
  };
  return (
    <div className="space-y-4">
      <div className="grid grid-cols-1 gap-3 sm:grid-cols-3">
        <label className="flex cursor-pointer flex-col items-center gap-2 rounded-xl border border-dashed border-gold-400/70 bg-gold-100/40 p-5 text-center transition hover:bg-gold-100">
          <Icon name="upload" size={22} className="text-gold-600" />
          <span className="text-xs font-extrabold text-pine-800">رفع ملف (PDF / Word / PPT / Excel / فيديو)</span>
          <span className="text-[10px] font-bold text-ink-faint">يُحفظ داخل المتصفح (حتى 700 ك.ب)</span>
          <input type="file" className="hidden" onChange={(e) => onFile(e.target.files?.[0], "ملف")} />
        </label>
        <label className="flex cursor-pointer flex-col items-center gap-2 rounded-xl border border-dashed border-gold-400/70 bg-gold-100/40 p-5 text-center transition hover:bg-gold-100">
          <Icon name="image" size={22} className="text-gold-600" />
          <span className="text-xs font-extrabold text-pine-800">رفع صورة (تُستخدم في الشواهد والممارسات)</span>
          <span className="text-[10px] font-bold text-ink-faint">يُحفظ داخل المتصفح (حتى 700 ك.ب)</span>
          <input type="file" accept="image/*" className="hidden" onChange={(e) => onFile(e.target.files?.[0], "صورة")} />
        </label>
        {!d.enabled ? (
          <div className="flex flex-col items-center justify-center gap-1.5 rounded-xl border border-dashed border-sand-dark bg-cream-deep/40 p-5 text-center">
            <Icon name="link" size={20} className="text-ink-faint" />
            <span className="text-xs font-extrabold text-ink-soft">ربط Google Drive مُعطّل</span>
            <span className="text-[10px] font-bold text-ink-faint">الملفات تُحفظ داخل المتصفح فقط</span>
            <button className="btn-ghost mt-1 !px-3 !py-1 !text-[11px]" onClick={onEnableDrive}>
              تفعيل الربط
            </button>
          </div>
        ) : d.ready ? (
          <label className="flex cursor-pointer flex-col items-center gap-2 rounded-xl border border-pine-600/30 bg-pine-50 p-5 text-center transition hover:bg-pine-100">
            <Icon name="link" size={22} className="text-pine-700" />
            <span className="text-xs font-extrabold text-pine-800">{busy ? "جارٍ الرفع إلى Drive…" : "رفع مباشرة إلى Google Drive"}</span>
            <span className="text-[10px] font-bold text-ink-faint">يُحفظ في حسابك ويرتبط بالمكتبة</span>
            <input type="file" className="hidden" disabled={busy} onChange={(e) => onDriveFile(e.target.files?.[0])} />
          </label>
        ) : (
          <div className="flex flex-col items-center justify-center gap-1.5 rounded-xl border border-dashed border-sand-dark bg-cream-deep/40 p-5 text-center">
            <Icon name="link" size={20} className="text-ink-faint" />
            <span className="text-xs font-extrabold text-ink-soft">Google Drive غير متصل</span>
            <span className="text-[10px] font-bold text-ink-faint">اربط حسابك من تبويب Google Drive لتفعيل الرفع</span>
          </div>
        )}
      </div>
      {msg && <p className="rounded-lg border border-gold-500/40 bg-gold-100 px-3 py-2 text-xs font-bold text-gold-700">{msg}</p>}
      <div className="space-y-2">
        {state.files.map((f) => (
          <div key={f.id} className="flex flex-wrap items-center gap-3 rounded-xl border border-gold-200/80 bg-cream px-4 py-2.5 shadow-soft">
            <Icon name={f.kind === "صورة" ? "image" : "fileText"} size={16} className="text-gold-600" />
            <span className="flex-1 truncate text-xs font-bold text-ink">{f.name}</span>
            <span className="rounded-md border border-sand-deep bg-cream-deep px-2 py-0.5 text-[10px] font-bold text-ink-soft">{f.kind}</span>
            <span className="text-[10px] font-bold text-ink-faint">{f.size} · {fmtDate(f.date)}</span>
            {f.url && f.kind === "صورة" && <img src={f.url} alt="" className="h-8 w-8 rounded-md border border-gold-200 object-cover" />}
            <ConfirmDelete onConfirm={() => removeFile(f.id)} />
          </div>
        ))}
        {state.files.length === 0 && <p className="rounded-lg border border-dashed border-sand-dark py-8 text-center text-xs font-bold text-ink-faint">لا توجد ملفات في المكتبة بعد</p>}
      </div>
    </div>
  );
}

/* ===================== تبويب الإعدادات ===================== */
function SettingsTab({ onOpenDrive }: { onOpenDrive: () => void }) {
  const { state, importState, reset } = useStore();
  const d = useDrive();
  const comp = computeCompletion(state);
  const [msg, setMsg] = useState("");
  const fileRef = useRef<HTMLInputElement>(null);
  return (
    <div className="space-y-5">
      <div className="rounded-xl border border-gold-200/80 bg-cream p-5 shadow-soft">
        <h4 className="font-display text-lg font-bold text-pine-900">مؤشر اكتمال الملف — تفصيل الحساب التلقائي</h4>
        <ul className="mt-4 space-y-2.5">
          {comp.parts.map((p) => (
            <li key={p.key} className="flex items-center gap-3 text-xs font-bold">
              <span className="w-32 shrink-0 text-ink-soft">{p.label}</span>
              <span className="h-2 flex-1 overflow-hidden rounded-full bg-sand-deep">
                <span className="block h-full rounded-full bg-gradient-to-l from-gold-400 to-pine-600" style={{ width: `${(p.value / p.target) * 100}%` }} />
              </span>
              <span className="w-14 text-left tabular-nums text-ink-faint" dir="ltr">
                {p.value}/{p.target}
              </span>
              <span className="w-12 text-left font-display text-base text-pine-800" dir="ltr">
                {p.weight}%
              </span>
            </li>
          ))}
        </ul>
        <p className="mt-3 rounded-lg bg-pine-50 px-3 py-2 text-[11px] font-bold leading-relaxed text-pine-800">
          الإجمالي الحالي: <b className="font-display text-lg">{comp.total}٪</b> — يُعاد الحساب تلقائياً مع كل إضافة أو تعديل في أي قسم.
        </p>
      </div>

      {/* التكاملات الخارجية */}
      <div className="rounded-xl border border-gold-200/80 bg-cream p-5 shadow-soft">
        <h4 className="flex items-center gap-2 font-display text-lg font-bold text-pine-900">
          <Icon name="link" size={17} className="text-gold-600" /> التكاملات الخارجية
        </h4>
        <div className="mt-4 flex flex-wrap items-center gap-4 rounded-lg border border-pine-600/20 bg-pine-50/60 p-4">
          <span className="flex h-11 w-11 shrink-0 items-center justify-center rounded-lg border border-gold-300/70 bg-gold-100/60 text-gold-600">
            <Icon name="link" size={20} />
          </span>
          <div className="min-w-[200px] flex-1">
            <p className="flex flex-wrap items-center gap-2 text-sm font-extrabold text-pine-900">
              ربط Google Drive
              {!d.enabled && (
                <span className="rounded-full border border-sand-dark/60 bg-sand-deep/50 px-2 py-0.5 text-[10px] font-extrabold text-ink-faint">
                  مُعطّل
                </span>
              )}
              {d.enabled && d.account && (
                <span className="rounded-full border border-pine-600/25 bg-pine-100 px-2 py-0.5 text-[10px] font-extrabold text-pine-700">
                  مرتبط · {d.account.name}
                </span>
              )}
              {d.enabled && !d.account && (
                <span className="rounded-full border border-gold-400/40 bg-gold-100/70 px-2 py-0.5 text-[10px] font-extrabold text-gold-700">
                  مُفعّل · لا يوجد حساب
                </span>
              )}
            </p>
            <p className="mt-1 text-[11px] font-bold leading-relaxed text-ink-soft">
              {!d.enabled
                ? "لا يظهر أي عنصر مرتبط بـ Drive في الموقع. فعّله متى شئت — أو امسح الـ Client ID لإزالته نهائياً."
                : d.account
                  ? `يمكنك تغيير الحساب أو إنهاء جلسته أو حذفه من الملف${d.signedIn ? " — الجلسة نشطة الآن" : " — الجلسة منتهية وستُطلب الموافقة عند أول عملية"}.`
                  : "يظهر تبويب «Google Drive» في هذه اللوحة، وخيار الرفع المباشر في «الملفات والصور»، واختيار الشواهد من Drive داخل نموذج الإضافة."}
            </p>
          </div>
          <div className="flex flex-wrap items-center gap-2">
            {d.enabled && d.account && (
              <button className="btn-soft" onClick={onOpenDrive}>
                <Icon name="user" size={14} /> إدارة الحساب
              </button>
            )}
            {d.clientId && <ForgetDriveBtn />}
            <Switch checked={d.enabled} onChange={d.setEnabled} label="تفعيل ربط Google Drive" />
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 gap-4 sm:grid-cols-3">
        <button
          className="btn-soft"
          onClick={() => {
            downloadText("ملف-الانجاز-نسخة.json", JSON.stringify(state, null, 2), "application/json");
            setMsg("تم تنزيل نسخة احتياطية كاملة من الملف ✓");
          }}
        >
          <Icon name="download" size={15} /> نسخة احتياطية (JSON)
        </button>
        <button className="btn-ghost" onClick={() => fileRef.current?.click()}>
          <Icon name="upload" size={15} /> استعادة من نسخة
        </button>
        <ResetBtn onReset={() => { reset(); setMsg("تمت استعادة البيانات الأصلية."); }} />
        <input
          ref={fileRef}
          type="file"
          accept="application/json"
          className="hidden"
          onChange={(e) => {
            const f = e.target.files?.[0];
            if (!f) return;
            const r = new FileReader();
            r.onload = () => {
              try {
                const p = JSON.parse(String(r.result)) as State;
                if (p && p.teacher && Array.isArray(p.criteria) && Array.isArray(p.evidence)) {
                  importState(p);
                  setMsg("تم استيراد النسخة بنجاح ✓");
                } else setMsg("الملف لا يحمل بنية صحيحة.");
              } catch {
                setMsg("تعذّر قراءة الملف.");
              }
            };
            r.readAsText(f);
            e.target.value = "";
          }}
        />
      </div>
      {msg && <p className="rounded-lg border border-gold-500/40 bg-gold-100 px-3 py-2 text-xs font-bold text-gold-700">{msg}</p>}
    </div>
  );
}

function ResetBtn({ onReset }: { onReset: () => void }) {
  const [arm, setArm] = useState(false);
  return (
    <button
      className={cn("btn-danger !px-4 !py-2 !text-sm", arm && "border-clay bg-clay text-white hover:bg-clay")}
      onClick={() => (arm ? (setArm(false), onReset()) : setArm(true))}
    >
      <Icon name="refresh" size={15} />
      {arm ? "سيُحذف كل تعديل — تأكيد؟" : "استعادة البيانات الأصلية"}
    </button>
  );
}

/* ===================== قائمة تبويب صغيرة (قوائم القوائم) ===================== */
function MiniList({ children, empty }: { children: React.ReactNode; empty?: boolean }) {
  if (empty)
    return (
      <p className="rounded-lg border border-dashed border-sand-dark py-8 text-center text-xs font-bold text-ink-faint">لا توجد عناصر بعد</p>
    );
  return <>{children}</>;
}

/* ===================== الصفحة الرئيسية للوحة ===================== */
export function DashboardPage() {
  const { state, removeDev, removePractice, removeAch } = useStore();
  const d = useDrive();
  const [tab, setTab] = useState<TabId>("personal");
  const [addDevM, setAddDevM] = useState(false);
  const [addPrM, setAddPrM] = useState(false);
  const [addAchM, setAddAchM] = useState(false);

  /* إذا عُطّل الربط ونحن داخل تبويبه — نعود إلى الإعدادات */
  useEffect(() => {
    if (!d.enabled && tab === "gdrive") setTab("settings");
  }, [d.enabled, tab]);

  const tabs = TABS.filter((t) => t.id !== "gdrive" || d.enabled);

  return (
    <div className="mx-auto max-w-6xl px-4 py-10 md:px-6">
      <SectionHead
        no="لوحة التحكم"
        title="مكتب المعلم — تحرير كل شيء"
        desc="كل ما تراه في الملف قابل للتعديل من هنا: البيانات، المعايير، الشواهد، الدورات، الممارسات، الإنجازات، والملفات — مع نسخة احتياطية واستعادة."
        icon="settings"
      />

      <div className="grid grid-cols-1 gap-6 lg:grid-cols-4">
        {/* الشريط الجانبي */}
        <Reveal>
          <nav className="no-print flex gap-1.5 overflow-x-auto pb-2 lg:sticky lg:top-24 lg:flex-col lg:overflow-visible lg:pb-0">
            {tabs.map((t) => (
              <button
                key={t.id}
                onClick={() => setTab(t.id)}
                className={cn(
                  "flex shrink-0 items-center gap-2.5 rounded-lg border px-3.5 py-2 text-xs font-extrabold transition",
                  tab === t.id ? "border-pine-800 bg-pine-900 text-cream shadow-soft" : "border-gold-200/80 bg-cream text-ink-soft hover:border-gold-400 hover:text-pine-800"
                )}
              >
                <Icon name={t.icon} size={15} className={tab === t.id ? "text-gold-300" : "text-gold-600"} />
                {t.label}
              </button>
            ))}
          </nav>
        </Reveal>

        {/* المحتوى */}
        <div className="lg:col-span-3">
          {tab === "personal" && <PersonalTab />}
          {tab === "criteria" && <CriteriaTab />}
          {tab === "evidence" && <EvidenceTab />}
          {tab === "dev" && (
            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <p className="text-xs font-bold text-ink-soft">{state.development.length} عنصر</p>
                <button className="btn-primary" onClick={() => setAddDevM(true)}>
                  <Icon name="plus" size={15} /> إضافة
                </button>
              </div>
              <MiniList empty={state.development.length === 0}>
                {state.development.map((d) => (
                  <div key={d.id} className="flex flex-wrap items-center gap-3 rounded-xl border border-gold-200/80 bg-cream px-4 py-3 shadow-soft">
                    <span className="rounded-full border border-pine-600/20 bg-pine-50 px-2 py-0.5 text-[10px] font-extrabold text-pine-700">{d.kind}</span>
                    <span className="flex-1 truncate text-sm font-bold text-ink">{d.title}</span>
                    <span className="text-[11px] font-bold text-ink-faint">{toAr(d.hours)} ساعة · {fmtDate(d.date)}</span>
                    <ConfirmDelete onConfirm={() => removeDev(d.id)} />
                  </div>
                ))}
              </MiniList>
              <Modal open={addDevM} onClose={() => setAddDevM(false)} title="إضافة عنصر تطوير" wide>
                <DevForm onDone={() => setAddDevM(false)} />
              </Modal>
            </div>
          )}
          {tab === "practices" && (
            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <p className="text-xs font-bold text-ink-soft">{state.practices.length} ممارسة</p>
                <button className="btn-primary" onClick={() => setAddPrM(true)}>
                  <Icon name="plus" size={15} /> إضافة
                </button>
              </div>
              <MiniList empty={state.practices.length === 0}>
                {state.practices.map((p) => (
                  <div key={p.id} className="flex flex-wrap items-center gap-3 rounded-xl border border-gold-200/80 bg-cream px-4 py-3 shadow-soft">
                    <span className="rounded-full border border-gold-400/40 bg-gold-100/70 px-2 py-0.5 text-[10px] font-extrabold text-gold-700">{p.category}</span>
                    <span className="flex-1 truncate text-sm font-bold text-ink">{p.title}</span>
                    <span className="text-[11px] font-bold text-ink-faint">{fmtDate(p.date)}</span>
                    <ConfirmDelete onConfirm={() => removePractice(p.id)} />
                  </div>
                ))}
              </MiniList>
              <Modal open={addPrM} onClose={() => setAddPrM(false)} title="إضافة ممارسة" wide>
                <PracticeForm onDone={() => setAddPrM(false)} />
              </Modal>
            </div>
          )}
          {tab === "ach" && (
            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <p className="text-xs font-bold text-ink-soft">{state.achievements.length} إنجاز</p>
                <button className="btn-primary" onClick={() => setAddAchM(true)}>
                  <Icon name="plus" size={15} /> إضافة
                </button>
              </div>
              <MiniList empty={state.achievements.length === 0}>
                {state.achievements.map((a) => (
                  <div key={a.id} className="flex flex-wrap items-center gap-3 rounded-xl border border-gold-200/80 bg-cream px-4 py-3 shadow-soft">
                    <span className="rounded-full border border-gold-400/40 bg-gold-100/70 px-2 py-0.5 text-[10px] font-extrabold text-gold-700">{a.kind}</span>
                    <span className="flex-1 truncate text-sm font-bold text-ink">{a.title}</span>
                    <span className="text-[11px] font-bold text-ink-faint">{fmtDate(a.date)}</span>
                    <ConfirmDelete onConfirm={() => removeAch(a.id)} />
                  </div>
                ))}
              </MiniList>
              <Modal open={addAchM} onClose={() => setAddAchM(false)} title="إضافة إنجاز" wide>
                <AchievementForm onDone={() => setAddAchM(false)} />
              </Modal>
            </div>
          )}
          {tab === "files" && <FilesTab onEnableDrive={() => setTab("settings")} />}
          {tab === "gdrive" && <GDriveTab />}
          {tab === "settings" && <SettingsTab onOpenDrive={() => setTab("gdrive")} />}
        </div>
      </div>
    </div>
  );
}

/* ===================== تبويب Google Drive ===================== */
/* زر نسيان Client ID — بتأكيد مزدوج */
function ForgetDriveBtn() {
  const d = useDrive();
  const [arm, setArm] = useState(false);
  useEffect(() => {
    if (!arm) return;
    const t = setTimeout(() => setArm(false), 3500);
    return () => clearTimeout(t);
  }, [arm]);
  return (
    <button
      className={cn("btn-danger", arm && "border-clay bg-clay text-white hover:bg-clay")}
      onClick={() => (arm ? (setArm(false), d.forgetClientId()) : setArm(true))}
    >
      <Icon name="trash" size={13} />
      {arm ? "سيُمسح الربط نهائياً — تأكيد؟" : "نسيان الـ Client ID"}
    </button>
  );
}

/* بطاقة إحصاء صغيرة */
function MiniStat({ icon, value, label }: { icon: string; value: number | string; label: string }) {
  return (
    <div className="min-w-[92px] flex-1 rounded-lg border border-sand-deep/70 bg-cream-deep/50 px-3 py-2.5 text-center">
      <p className="font-display text-xl font-bold leading-none text-pine-900">{value}</p>
      <p className="mt-1.5 flex items-center justify-center gap-1 text-[10px] font-extrabold text-ink-faint">
        <Icon name={icon} size={11} className="text-gold-500" /> {label}
      </p>
    </div>
  );
}

/* ===================== لوحة تشخيص الربط ===================== */
function AuthDiagnostics() {
  const d = useDrive();
  const [copied, setCopied] = useState("");
  const isFile = location.protocol === "file:";
  const origin = isFile ? "" : location.origin;
  const secure = typeof window !== "undefined" && window.isSecureContext;

  const rows = [
    { ok: d.clientIdValid, label: "صيغة الـ Client ID", fix: "يجب أن ينتهي بـ .apps.googleusercontent.com وأن يكون نوعه Web application" },
    { ok: !isFile, label: "الموقع مفتوح عبر رابط لا ملف محلي", fix: "ملفات file:// لا تدعم مصادقة Google — افتح الموقع عبر https أو localhost" },
    { ok: secure, label: "سياق آمن (https أو localhost)", fix: `العنوان الحالي ${location.protocol}// لا يُعد آمناً لدى المتصفح فيحجب Google` },
    { ok: !!origin, label: "أصل الموقع قابل للإدراج", fix: "لا يمكن تحديد أصل الموقع وهو ملف محلي" },
  ];
  const failed = rows.filter((r) => !r.ok).length;

  const copy = async (label: string, text: string) => {
    if (!text) return;
    const ok = await copyText(text);
    setCopied(ok ? label : "");
    setTimeout(() => setCopied(""), 2000);
  };

  return (
    <div className="relative overflow-hidden rounded-xl border border-gold-500/30 bg-pine-950 p-5 text-cream shadow-soft md:p-6">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <h4 className="flex items-center gap-2 font-display text-xl font-bold text-gold-300">
          <Icon name="scan" size={19} /> تشخيص الربط
        </h4>
        <span
          className={cn(
            "rounded-full border px-2.5 py-0.5 text-[10px] font-extrabold",
            failed ? "border-clay/50 bg-clay/15 text-[#e8b3a2]" : "border-pine-500/40 bg-pine-800 text-pine-100"
          )}
        >
          {failed ? `${toAr(failed)} فحص يحتاج معالجة` : "كل الفحوص سليمة"}
        </span>
      </div>

      <ul className="mt-4 space-y-2">
        {rows.map((r) => (
          <li key={r.label} className="flex items-start gap-2.5 rounded-lg border border-cream/10 bg-pine-900/60 px-3 py-2">
            <span className={cn("mt-0.5 flex h-5 w-5 shrink-0 items-center justify-center rounded-full", r.ok ? "bg-pine-600 text-white" : "bg-clay/80 text-white")}>
              <Icon name={r.ok ? "check" : "x"} size={12} />
            </span>
            <span className="min-w-0">
              <span className="block text-xs font-extrabold">{r.label}</span>
              {!r.ok && <span className="mt-0.5 block text-[11px] font-bold leading-relaxed text-cream/60">{r.fix}</span>}
            </span>
          </li>
        ))}
      </ul>

      <div className="mt-4 grid grid-cols-1 gap-2 sm:grid-cols-2">
        <div className="rounded-lg border border-cream/10 bg-pine-900/60 p-3">
          <p className="text-[10px] font-extrabold text-gold-300">أصل الموقع — يُضاف حرفياً في Authorized JavaScript origins</p>
          <div className="mt-1.5 flex items-center gap-2">
            <code className="min-w-0 flex-1 truncate rounded bg-pine-950 px-2 py-1 text-[11px] font-bold text-cream/85" dir="ltr">
              {origin || "غير متاح (ملف محلي)"}
            </code>
            <button className="btn-ghost !border-gold-500/40 !px-2.5 !py-1 !text-[11px] !text-gold-200" onClick={() => copy("origin", origin)} disabled={!origin}>
              <Icon name={copied === "origin" ? "check" : "folder"} size={12} /> {copied === "origin" ? "نُسخ" : "نسخ"}
            </button>
          </div>
        </div>
        <div className="rounded-lg border border-cream/10 bg-pine-900/60 p-3">
          <p className="text-[10px] font-extrabold text-gold-300">الـ Client ID المحفوظ</p>
          <div className="mt-1.5 flex items-center gap-2">
            <code className="min-w-0 flex-1 truncate rounded bg-pine-950 px-2 py-1 text-[11px] font-bold text-cream/85" dir="ltr">
              {d.clientId || "لم يُحفظ بعد"}
            </code>
            <button className="btn-ghost !border-gold-500/40 !px-2.5 !py-1 !text-[11px] !text-gold-200" onClick={() => copy("cid", d.clientId)} disabled={!d.clientId}>
              <Icon name={copied === "cid" ? "check" : "folder"} size={12} /> {copied === "cid" ? "نُسخ" : "نسخ"}
            </button>
          </div>
        </div>
      </div>

      <div className="mt-4 rounded-lg border border-cream/10 bg-pine-900/40 p-3">
        <p className="text-[11px] font-extrabold text-gold-300">إن كانت الفحوص سليمة وما زال الربط يفشل، تحقق في Google Cloud من:</p>
        <ul className="mt-2 space-y-1.5 text-[11px] font-bold leading-relaxed text-cream/70">
          <li>• تفعيل <b className="text-cream">Google Drive API</b> في نفس مشروع الـ Client ID (وليس مشروعاً آخر).</li>
          <li>• أن حالة النشر <b className="text-cream">Testing</b> مع إضافة بريدك في Test users، أو <b className="text-cream">In production</b>.</li>
          <li>• السماح بالنوافذ المنبثقة لهذا الموقع من أيقونة القفل في شريط العنوان.</li>
          <li>• عدم حجب المتصفح لملفات تعريف الارتباط لجهات خارجية (تظهر كرمز <span dir="ltr">idpiframe_initialization_failed</span>).</li>
        </ul>
      </div>

      {d.ready && !d.account && (
        <button className="btn-gold mt-4" onClick={() => d.signIn({ selectAccount: true })} disabled={d.busy || failed > 1}>
          <Icon name="refresh" size={15} className={d.busy ? "animate-spin" : ""} /> إعادة محاولة الربط
        </button>
      )}
    </div>
  );
}

function GDriveTab() {
  const { state, removeEvidence, removeFile } = useStore();
  const d = useDrive();
  const [id, setId] = useState(d.clientId);
  const [delOpen, setDelOpen] = useState(false);
  const [alsoRemove, setAlsoRemove] = useState(false);
  const [armDel, setArmDel] = useState(false);

  const driveEvidence = state.evidence.filter((e) => isDriveUrl(e.image) || isDriveUrl(e.link) || isDriveUrl(e.file?.url));
  const driveFiles = state.files.filter((f) => isDriveUrl(f.url));

  useEffect(() => {
    setId(d.clientId);
  }, [d.clientId]);

  const doDelete = () => {
    if (alsoRemove) {
      driveEvidence.forEach((e) => removeEvidence(e.id));
      driveFiles.forEach((f) => removeFile(f.id));
    }
    d.deleteAccount();
    setDelOpen(false);
    setAlsoRemove(false);
    setArmDel(false);
  };

  const quotaPct = d.account?.quota ? Math.min(100, Math.round((d.account.quota.usage / (d.account.quota.limit || 1)) * 100)) : null;
  const gb = (n: number) => (n / 1073741824).toFixed(n / 1073741824 >= 10 ? 0 : 1);

  return (
    <div className="space-y-5">
      <div className="rounded-xl border border-gold-200/80 bg-cream p-5 shadow-soft md:p-6">
        <div className="flex flex-wrap items-center justify-between gap-3">
          <h4 className="flex items-center gap-2 font-display text-xl font-bold text-pine-900">
            <Icon name="link" size={19} className="text-gold-600" /> حساب Google Drive
          </h4>
          <div className="flex items-center gap-3">
            <span className="text-[11px] font-extrabold text-ink-soft">{d.enabled ? "الربط مُفعّل" : "الربط مُعطّل"}</span>
            <Switch checked={d.enabled} onChange={d.setEnabled} label="تفعيل ربط Google Drive" />
          </div>
        </div>
        <p className="mt-2 text-[11px] font-bold leading-relaxed text-ink-faint">
          من هنا تربط حسابك، أو تبدّله بحساب آخر، أو تحذفه من الملف نهائياً. إيقاف المفتاح يُخفي كل عناصر Drive من الموقع بضغطة واحدة وبدون أي كود.
        </p>
        {d.clientId && (
          <div className="mt-3 flex flex-wrap items-center justify-between gap-2 rounded-lg border border-sand-deep bg-cream-deep/50 px-3 py-2">
            <p className="min-w-0 flex-1 truncate text-[11px] font-bold text-ink-faint" dir="ltr">
              {d.clientId}
            </p>
            <ForgetDriveBtn />
          </div>
        )}
        {d.error && (
          <div className="mt-3 rounded-lg border border-clay/30 bg-clay/10 px-3 py-2">
            <div className="flex items-start justify-between gap-2">
              <p className="text-xs font-extrabold leading-relaxed text-clay">{d.error}</p>
              <button className="shrink-0 text-clay hover:opacity-70" onClick={d.clearError} aria-label="إغلاق">
                <Icon name="x" size={13} />
              </button>
            </div>
            <p className="mt-1 text-[11px] font-bold leading-relaxed text-ink-soft">
              راجع «تشخيص الربط» أدناه — يعرض لك العنوان المطلوب إضافته في Google Cloud وأسباب الفشل الشائعة.
            </p>
          </div>
        )}

        {!d.clientId ? (
          <div className="mt-4">
            <p className="text-xs font-bold leading-relaxed text-ink-soft">
              الربط يتم عبر حسابك الشخصي في Google بمصادقة آمنة — الموقع لا يرى كلمة مرورك أبداً. لتفعيله مرة واحدة فقط:
            </p>
            <ol className="mt-3 space-y-2.5">
              {[
                "افتح console.cloud.google.com وأنشئ مشروعاً جديداً",
                "فعّل «Google Drive API» من قسم APIs & Services",
                "من Credentials أنشئ «OAuth client ID» بنوع Web application",
                "أضف عنوان هذا الموقع إلى «Authorized JavaScript origins» ثم انسخ الـ Client ID والصقه هنا",
              ].map((s, i) => (
                <li key={i} className="flex items-start gap-2.5 text-xs font-bold text-ink">
                  <span className="mt-0.5 flex h-5 w-5 shrink-0 items-center justify-center rounded-full border border-gold-400/60 bg-gold-100/60 font-display text-[11px] font-bold text-gold-700">
                    {["1", "2", "3", "4"][i]}
                  </span>
                  {s}
                </li>
              ))}
            </ol>
            <div className="mt-4 flex flex-col gap-2 sm:flex-row">
              <input
                className={cn("inp flex-1", id.trim() && !d.clientIdValid && !/^[0-9]+-[a-z0-9]+\.apps\.googleusercontent\.com$/i.test(id.trim()) && "!border-clay/60")}
                dir="ltr"
                placeholder="123456789-abc123def.apps.googleusercontent.com"
                value={id}
                onChange={(e) => setId(e.target.value)}
              />
              <button
                className="btn-primary"
                disabled={!/^[0-9]+-[a-z0-9]+\.apps\.googleusercontent\.com$/i.test(id.trim())}
                onClick={() => {
                  if (!id.trim()) return;
                  d.saveClientId(id);
                }}
              >
                <Icon name="check" size={15} /> حفظ وتفعيل
              </button>
            </div>
            {id.trim() && !/^[0-9]+-[a-z0-9]+\.apps\.googleusercontent\.com$/i.test(id.trim()) && (
              <p className="mt-2 flex items-center gap-1.5 text-[11px] font-bold text-clay">
                <Icon name="x" size={12} /> الصيغة غير صحيحة — يجب أن ينتهي بـ .apps.googleusercontent.com
              </p>
            )}
          </div>
        ) : !d.ready ? (
          <p className="mt-4 flex items-center gap-2 text-xs font-bold text-ink-soft">
            <Icon name="refresh" size={14} className="animate-spin text-gold-500" /> جارٍ تحميل خدمة Google Identity Services…
          </p>
        ) : !d.account ? (
          <div className="mt-5 rounded-lg border border-pine-600/20 bg-pine-50 p-5">
            <p className="text-sm font-extrabold text-pine-900">لا يوجد حساب مرتبط بعد</p>
            <p className="mt-1.5 text-[11px] font-bold leading-relaxed text-ink-soft">
              اربط حسابك في Google لرفع الشواهد والملفات مباشرة إلى Drive، أو لاختيار ملفات موجودة فيه كشواهد.
            </p>
            <button className="btn-primary mt-3" onClick={() => d.signIn({ selectAccount: true })} disabled={d.busy}>
              <Icon name="external" size={15} /> {d.busy ? "جارٍ فتح نافذة Google…" : "ربط حساب Google"}
            </button>
            <p className="mt-3 text-[11px] font-bold leading-relaxed text-ink-faint">
              ستنفتح نافذة Google الرسمية لاختيار حسابك ومنح الإذن — الموقع لا يطّلع على كلمة مرورك. إن لم تنفتح، اسمح بالنوافذ المنبثقة.
            </p>
          </div>
        ) : (
          <div className="mt-5 overflow-hidden rounded-xl border border-pine-600/25 bg-pine-50">
            <div className="flex flex-wrap items-center gap-4 p-4">
              <div className="relative shrink-0">
                {d.account.picture ? (
                  <img src={d.account.picture} alt="" className="rounded-full border-2 border-gold-400/70 object-cover" style={{ width: 54, height: 54 }} />
                ) : (
                  <span className="flex items-center justify-center rounded-full border-2 border-gold-400/70 bg-gold-100 font-display text-xl font-bold text-pine-800" style={{ width: 54, height: 54 }}>
                    {d.account.name.trim().charAt(0) || "G"}
                  </span>
                )}
                <span
                  className={cn(
                    "absolute -bottom-0.5 -left-0.5 h-4 w-4 rounded-full border-2 border-pine-50",
                    d.signedIn ? "bg-pine-500" : "bg-sand-dark"
                  )}
                  title={d.signedIn ? "جلسة نشطة" : "الجلسة منتهية"}
                />
              </div>
              <div className="min-w-0 flex-1">
                <p className="truncate font-display text-lg font-bold leading-tight text-pine-900">{d.account.name}</p>
                {d.account.email && (
                  <p className="truncate text-[11px] font-bold text-ink-soft" dir="ltr">
                    {d.account.email}
                  </p>
                )}
                <p className="mt-1.5 flex flex-wrap items-center gap-2 text-[11px] font-extrabold">
                  {d.signedIn ? (
                    <span className="flex items-center gap-1.5 rounded-full border border-pine-600/25 bg-pine-100 px-2 py-0.5 text-pine-700">
                      <span className="anim-pulse-gold h-1.5 w-1.5 rounded-full bg-pine-600" /> جلسة نشطة — الرفع والبحث متاحان
                    </span>
                  ) : (
                    <span className="flex items-center gap-1.5 rounded-full border border-gold-500/35 bg-gold-100 px-2 py-0.5 text-gold-700">
                      <Icon name="clock" size={11} /> الجلسة منتهية — ستُطلب موافقة Google عند أول عملية
                    </span>
                  )}
                </p>
              </div>
            </div>

            {/* المساحة المستخدمة */}
            {quotaPct !== null && d.account.quota && (
              <div className="border-t border-pine-600/15 px-4 py-3">
                <div className="flex items-center justify-between text-[10px] font-extrabold text-ink-soft">
                  <span>مساحة Drive</span>
                  <span dir="ltr">
                    {gb(d.account.quota.usage)} / {gb(d.account.quota.limit)} GB
                  </span>
                </div>
                <div className="mt-1.5 h-1.5 overflow-hidden rounded-full bg-sand-deep">
                  <div className="h-full rounded-full bg-gradient-to-l from-gold-400 to-pine-600 transition-all duration-1000" style={{ width: `${Math.max(quotaPct, 2)}%` }} />
                </div>
              </div>
            )}

            {/* ما ارتبط بالملف */}
            <div className="flex flex-wrap gap-2 border-t border-pine-600/15 px-4 py-3">
              <MiniStat icon="folder" value={toAr(driveEvidence.length)} label="شاهد من Drive" />
              <MiniStat icon="image" value={toAr(driveFiles.length)} label="ملف في المكتبة" />
              <MiniStat icon="check" value={d.signedIn ? "نشط" : "خامل"} label="حالة الاتصال" />
            </div>

            {/* الإجراءات */}
            <div className="flex flex-wrap gap-2 border-t border-pine-600/15 bg-cream/60 px-4 py-3">
              <button className="btn-soft" onClick={() => d.signIn({ selectAccount: true })} disabled={d.busy}>
                <Icon name="refresh" size={14} /> {d.busy ? "جارٍ…" : "تغيير الحساب"}
              </button>
              {d.signedIn ? (
                <button className="btn-ghost" onClick={d.signOut}>
                  <Icon name="x" size={14} /> إنهاء الجلسة
                </button>
              ) : (
                <button className="btn-ghost" onClick={() => d.signIn()} disabled={d.busy}>
                  <Icon name="external" size={14} /> استئناف الجلسة
                </button>
              )}
              <button className="btn-danger !px-4 !py-2 !text-sm" onClick={() => { setArmDel(false); setAlsoRemove(false); setDelOpen(true); }}>
                <Icon name="trash" size={14} /> حذف الحساب من الملف
              </button>
            </div>
          </div>
        )}
      </div>

      {/* تشخيص الربط */}
      {d.clientId && <AuthDiagnostics />}

      {/* نافذة حذف الحساب */}
      <Modal open={delOpen} onClose={() => setDelOpen(false)} title="حذف حساب Google من الملف">
        <div className="space-y-4">
          <div className="flex items-center gap-3 rounded-lg border border-gold-300/60 bg-gold-100/50 p-3">
            {d.account?.picture ? (
              <img src={d.account.picture} alt="" className="h-11 w-11 rounded-full border border-gold-400/60 object-cover" />
            ) : (
              <span className="flex h-11 w-11 items-center justify-center rounded-full border border-gold-400/60 bg-cream font-display text-lg font-bold text-pine-800">
                {d.account?.name?.charAt(0) || "G"}
              </span>
            )}
            <div className="min-w-0">
              <p className="truncate text-sm font-extrabold text-pine-900">{d.account?.name}</p>
              {d.account?.email && (
                <p className="truncate text-[11px] font-bold text-ink-soft" dir="ltr">
                  {d.account.email}
                </p>
              )}
            </div>
          </div>
          <p className="text-xs font-bold leading-relaxed text-ink">
            سيُقطع الاتصال بالحساب وتُمسح بياناته المحفوظة في هذا المتصفح. يبقى الـ Client ID والتفعيل كما هما، فيمكنك ربط حساب آخر في أي وقت.
          </p>
          {driveEvidence.length + driveFiles.length > 0 && (
            <label className="flex cursor-pointer items-start gap-2.5 rounded-lg border border-clay/25 bg-clay/[.06] p-3">
              <input type="checkbox" className="mt-0.5 h-4 w-4 accent-[#9c4a33]" checked={alsoRemove} onChange={(e) => setAlsoRemove(e.target.checked)} />
              <span className="text-xs font-bold leading-relaxed text-ink">
                إزالة المحتوى المرتبط بهذا الحساب من الملف أيضاً
                <span className="mt-0.5 block text-[11px] font-bold text-clay">
                  {toAr(driveEvidence.length)} شاهد + {toAr(driveFiles.length)} ملف في المكتبة — لا يمكن التراجع عن هذا الجزء
                </span>
              </span>
            </label>
          )}
          <div className="flex items-center justify-end gap-2 border-t border-gold-200/60 pt-4">
            <button className="btn-ghost" onClick={() => setDelOpen(false)}>
              إلغاء
            </button>
            <button
              className={cn("btn-danger !px-4 !py-2 !text-sm", armDel && "border-clay bg-clay text-white hover:bg-clay")}
              onClick={() => (armDel ? doDelete() : setArmDel(true))}
            >
              <Icon name="trash" size={14} />
              {armDel ? "تأكيد الحذف النهائي" : "حذف الحساب"}
            </button>
          </div>
        </div>
      </Modal>

      {/* منظّم المجلدات */}
      <OrganizePanel />

      {/* المزامنة */}
      <SyncPanel />

      <div className="rounded-xl border border-gold-200/80 bg-cream p-5 shadow-soft">
        <h5 className="flex items-center gap-2 text-sm font-extrabold text-pine-900">
          <Icon name="sparkles" size={15} className="text-gold-600" /> ما الذي يفتحه الربط؟
        </h5>
        <ul className="mt-3 space-y-2 text-xs font-bold leading-relaxed text-ink">
          <li className="flex items-start gap-2">
            <Icon name="upload" size={14} className="mt-0.5 shrink-0 text-gold-500" /> رفع أي ملف أو صورة مباشرة إلى حسابك في Drive من تبويب «الملفات والصور»
          </li>
          <li className="flex items-start gap-2">
            <Icon name="search" size={14} className="mt-0.5 shrink-0 text-gold-500" /> البحث في ملفات Drive واختيار صورة أو مستند وتحويله إلى شاهد داخل نموذج «إضافة شاهد»
          </li>
          <li className="flex items-start gap-2">
            <Icon name="folder" size={14} className="mt-0.5 shrink-0 text-gold-500" /> الملفات القادمة من Drive تُعلَّم بشارة مميزة في بطاقات الشواهد
          </li>
          <li className="flex items-start gap-2">
            <Icon name="refresh" size={14} className="mt-0.5 shrink-0 text-gold-500" /> «تغيير الحساب» يفتح قائمة حسابات Google لتبدّل المرتبط بالملف، و«حذف الحساب» يقطعه مع إمكانية إزالة ما ارتبط به
          </li>
          <li className="flex items-start gap-2">
            <Icon name="shield" size={14} className="mt-0.5 shrink-0 text-gold-500" /> المزامنة تحفظ ملفك كاملاً في مجلد «ملف إنجاز المعلم» على Drive، وتسترجعه من أي جهاز — تلقائياً بعد كل تعديل
          </li>
          <li className="flex items-start gap-2">
            <Icon name="folder" size={14} className="mt-0.5 shrink-0 text-gold-500" /> «منظّم مجلد Drive» يبني الهيكل الكامل داخل مجلد تختاره أنت: 9 مجلدات رئيسية ومجلد لكل معيار، مع الفهارس وتوزيع الملفات
          </li>
        </ul>
      </div>
    </div>
  );
}
