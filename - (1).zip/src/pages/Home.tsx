import { useState } from "react";
import { computeCompletion, computeStats, toAr } from "../data";
import { useStore } from "../store";
import { useNav, type PageId } from "../nav";
import { useViewer } from "../share";
import { EightStar, Field, Gauge, GoldDivider, Icon, Kicker, Modal, OrnateCard, Reveal, SectionHead, StatCard } from "../components/ui";

/* ===================== بطاقة التعريف القابلة للتعديل ===================== */
function IdentityCard() {
  const { state, updateTeacher } = useStore();
  const [open, setOpen] = useState(false);
  const t = state.teacher;
  const [f, setF] = useState({ name: t.name, specialty: t.specialty, school: t.school, year: t.year, photo: t.photo });
  return (
    <>
      <OrnateCard className="p-5 md:p-6">
        <div className="flex items-center gap-4">
          <div className="relative shrink-0">
            <img src={t.photo} alt={t.name} className="h-20 w-20 rounded-full border-2 border-gold-400/60 object-cover md:h-24 md:w-24" />
            <span className="absolute -bottom-1 -left-1 flex h-7 w-7 items-center justify-center rounded-full border border-gold-300 bg-pine-900 text-gold-300">
              <Icon name="cap" size={14} />
            </span>
          </div>
          <div className="min-w-0 flex-1">
            <p className="text-[10px] font-extrabold tracking-wide text-gold-600">ملف إنجاز المعلم</p>
            <h3 className="mt-0.5 truncate font-display text-2xl font-bold leading-tight text-pine-900 md:text-[26px]">{t.name}</h3>
            <div className="mt-1.5 space-y-0.5 text-xs font-bold text-ink-soft">
              <p className="flex items-center gap-1.5">
                <Icon name="book" size={13} className="text-gold-500" /> {t.specialty}
              </p>
              <p className="flex items-center gap-1.5">
                <Icon name="building" size={13} className="text-gold-500" /> {t.school}
              </p>
            </div>
            <p className="mt-1.5 inline-block rounded-full border border-gold-300/70 bg-gold-100/60 px-2.5 py-0.5 text-[10px] font-extrabold text-gold-700">
              العام الدراسي: {t.year}
            </p>
          </div>
        </div>
        <button className="btn-ghost no-viewer mt-4 w-full" onClick={() => { setF({ name: t.name, specialty: t.specialty, school: t.school, year: t.year, photo: t.photo }); setOpen(true); }}>
          <Icon name="pencil" size={14} /> تعديل بيانات المعلم
        </button>
      </OrnateCard>

      <Modal open={open} onClose={() => setOpen(false)} title="تعديل بيانات التعريف">
        <div className="space-y-4">
          <Field label="اسم المعلم">
            <input className="inp" value={f.name} onChange={(e) => setF({ ...f, name: e.target.value })} />
          </Field>
          <div className="grid grid-cols-2 gap-3">
            <Field label="التخصص">
              <input className="inp" value={f.specialty} onChange={(e) => setF({ ...f, specialty: e.target.value })} />
            </Field>
            <Field label="العام الدراسي">
              <input className="inp" value={f.year} onChange={(e) => setF({ ...f, year: e.target.value })} />
            </Field>
          </div>
          <Field label="المدرسة">
            <input className="inp" value={f.school} onChange={(e) => setF({ ...f, school: e.target.value })} />
          </Field>
          <Field label="رابط الصورة الشخصية">
            <input className="inp" dir="ltr" value={f.photo} onChange={(e) => setF({ ...f, photo: e.target.value })} />
          </Field>
          <div className="flex justify-end gap-2 border-t border-gold-200/60 pt-4">
            <button className="btn-ghost" onClick={() => setOpen(false)}>إلغاء</button>
            <button
              className="btn-primary"
              onClick={() => {
                updateTeacher(f);
                setOpen(false);
              }}
            >
              <Icon name="check" size={15} /> حفظ
            </button>
          </div>
        </div>
      </Modal>
    </>
  );
}

/* ===================== الصفحة الرئيسية ===================== */
const DOORS: { page: PageId; icon: string; label: string; desc: string }[] = [
  { page: "profile", icon: "user", label: "الملف الشخصي", desc: "البيانات والمؤهلات والمهارات" },
  { page: "criteria", icon: "grid", label: "معايير الأداء", desc: "أحد عشر معياراً وتوثيقها" },
  { page: "plan", icon: "layout", label: "الخطة التعليمية", desc: "الخطة الفصلية والتوزيع" },
  { page: "practices", icon: "bookOpen", label: "الممارسات المهنية", desc: "معرض الحصص والمبادرات" },
  { page: "results", icon: "chartUp", label: "نتائج الطلاب", desc: "تحليل قبل وبعد التدخل" },
  { page: "evidence", icon: "folder", label: "الشواهد", desc: "السجل الموحد والبحث" },
  { page: "achievements", icon: "trophy", label: "الإنجازات", desc: "شهادات وتكريمات ومشاريع" },
  { page: "development", icon: "rocket", label: "التطوير المهني", desc: "دورات وورش ومجتمعات" },
  { page: "reports", icon: "printer", label: "التقارير", desc: "قابلة للطباعة والتصدير" },
  { page: "share", icon: "shield", label: "المشاركة والحماية", desc: "رابط باسمك وقفل الملف" },
  { page: "dashboard", icon: "settings", label: "لوحة التحكم", desc: "تحرير كامل للمحتوى" },
  { page: "closing", icon: "star8", label: "الخاتمة", desc: "إعلان الإثبات" },
];

export function HomePage() {
  const { state } = useStore();
  const nav = useNav();
  const viewer = useViewer();
  const stats = computeStats(state);
  const comp = computeCompletion(state);
  const doors = DOORS.filter((d) => !(viewer && (d.page === "dashboard" || d.page === "share")));

  return (
    <div className="mx-auto max-w-6xl px-4 py-10 md:px-6 md:py-14">
      {/* الافتتاح */}
      <div className="grid grid-cols-1 items-start gap-8 lg:grid-cols-5">
        <div className="lg:col-span-3">
          <Reveal>
            <Kicker icon="star8">منصة توثيق الأداء المهني · {state.teacher.year}</Kicker>
            <h1 className="font-display text-5xl font-bold leading-[1.15] text-pine-900 md:text-6xl">
              ملف إنجاز <span className="relative text-gold-600">المعلم
                <span className="absolute -bottom-1 right-0 h-1 w-full rounded bg-gold-300/60" />
              </span>
            </h1>
          </Reveal>
          <Reveal delay={140}>
            <div className="relative mt-6 max-w-xl">
              <Icon name="quote" size={34} className="absolute -top-2 right-0 text-gold-400/60" />
              <EightStar className="anim-drift absolute -left-8 -top-6 h-10 w-10 text-gold-400/40" />
              <p className="font-display text-2xl leading-relaxed text-pine-800 md:text-[27px]">
                رحلة مِهنية توثّق الممارسة، وتُظهر الأثر، وتُصنّع التطوّر.
              </p>
            </div>
          </Reveal>
          <Reveal delay={240} className="mt-7">
            <IdentityCard />
          </Reveal>
        </div>

        <div className="lg:col-span-2">
          <Reveal delay={200}>
            <div className="relative overflow-hidden rounded-xl border border-gold-300/60 bg-cream p-6 shadow-soft">
              <GoldDivider className="mb-5" />
              <h3 className="text-center font-display text-xl font-bold text-pine-900">متابعة اكتمال الملف</h3>
              <div className="mt-4">
                <Gauge value={comp.total} size={210} />
              </div>
              <ul className="mt-5 space-y-2.5">
                {comp.parts.map((p) => (
                  <li key={p.key} className="flex items-center gap-3 text-[11px] font-bold">
                    <span className="w-28 shrink-0 text-ink-soft">{p.label}</span>
                    <span className="h-1.5 flex-1 overflow-hidden rounded-full bg-sand-deep">
                      <span
                        className="block h-full rounded-full bg-gradient-to-l from-gold-400 to-pine-600 transition-all duration-1000"
                        style={{ width: `${(p.value / p.target) * 100}%` }}
                      />
                    </span>
                    <span className="w-10 text-left tabular-nums text-ink-faint" dir="ltr">
                      {p.value}/{p.target}
                    </span>
                  </li>
                ))}
              </ul>
            </div>
          </Reveal>
        </div>
      </div>

      {/* الإحصاءات التفاعلية */}
      <div className="mt-14">
        <Reveal className="mb-5 flex items-center gap-3">
          <span className="h-px flex-1 bg-gold-300/50" />
          <h2 className="font-display text-2xl font-bold text-pine-900">أرقام تتحدث عن مسار</h2>
          <span className="h-px flex-1 bg-gold-300/50" />
        </Reveal>
        <div className="grid grid-cols-2 gap-3 sm:grid-cols-3 md:gap-4 lg:grid-cols-7">
          <StatCard icon="clock" value={stats.experience} label="سنوات الخبرة" />
          <StatCard icon="cap" value={stats.courses} label="الدورات" delay={60} />
          <StatCard icon="flag" value={stats.initiatives} label="المبادرات" delay={120} />
          <StatCard icon="folder" value={stats.evidence} label="الشواهد" delay={180} />
          <StatCard icon="layers" value={stats.activities} label="الأنشطة" delay={240} />
          <StatCard icon="rocket" value={stats.projects} label="المشاريع" delay={300} />
          <StatCard icon="trophy" value={stats.achievements} label="الإنجازات" delay={360} />
        </div>
      </div>

      {/* أبواب الملف */}
      <div className="mt-14">
        <SectionHead no="القسم ٠١" title="أبواب الملف" desc="ملف رقمي منظّم — كل قسم باب مستقل يفتح على محتوى موثق وقابل للتحرير من لوحة التحكم." icon="home" />
        <div className="grid grid-cols-1 gap-3 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4">
          {doors.map((d, i) => (
            <Reveal key={d.page + d.label} delay={Math.min(i * 55, 380)}>
              <button
                onClick={() => nav(d.page)}
                className="card-lift group flex w-full items-center gap-3.5 rounded-xl border border-gold-200/80 bg-cream p-4 text-right shadow-soft hover:border-gold-400"
              >
                <span className="flex h-11 w-11 shrink-0 items-center justify-center rounded-lg border border-gold-300/70 bg-gold-100/50 text-gold-600 transition-colors group-hover:bg-gold-100">
                  <Icon name={d.icon} size={20} />
                </span>
                <span className="min-w-0 flex-1">
                  <span className="block font-display text-lg font-bold leading-tight text-pine-900">{d.label}</span>
                  <span className="block truncate text-[11px] font-bold text-ink-faint">{d.desc}</span>
                </span>
                <Icon name="chevron" size={15} className="shrink-0 text-gold-400 transition-transform group-hover:-translate-x-1" />
              </button>
            </Reveal>
          ))}
        </div>
      </div>

      {/* معاينة المعايير */}
      <div className="mt-14">
        <SectionHead no="نظرة عامة" title="خريطة معايير الأداء" desc="نقطة التوثيق توضح حالة كل معيار: أخضر = موثق، ذهبي = قيد التوثيق، رمادي = غير موثق." icon="grid" />
        <Reveal>
          <div className="flex gap-2.5 overflow-x-auto pb-3">
            {state.criteria.map((c, i) => {
              const n = state.evidence.filter((e) => e.criterionId === c.id).length;
              const st = n >= 3 ? "موثق" : n >= 1 ? "قيد التوثيق" : "غير موثق";
              return (
                <button
                  key={c.id}
                  onClick={() => nav("criterion", c.id)}
                  className="card-lift shrink-0 rounded-xl border border-gold-200/80 bg-cream px-4 py-3 text-right shadow-soft hover:border-gold-400"
                  style={{ transitionDelay: `${i * 20}ms` }}
                >
                  <span className="flex items-center gap-2">
                    <span className={`h-2 w-2 rounded-full ${st === "موثق" ? "bg-pine-500" : st === "قيد التوثيق" ? "bg-gold-500" : "bg-sand-dark"}`} />
                    <span className="font-display text-lg font-bold text-pine-900">{toAr(c.id)}</span>
                  </span>
                  <span className="mt-1 block max-w-[130px] truncate text-[11px] font-bold text-ink-soft">{c.title}</span>
                  <span className="mt-0.5 block text-[10px] font-bold text-ink-faint">{n} شواهد</span>
                </button>
              );
            })}
          </div>
        </Reveal>
      </div>
    </div>
  );
}

/* ===================== الصفحة الختامية ===================== */
export function ClosingPage() {
  const { state } = useStore();
  const nav = useNav();
  const t = state.teacher;
  return (
    <div className="relative overflow-hidden bg-pine-950 py-20 text-cream md:py-28">
      <EightStar className="anim-spin-slow absolute -left-24 -top-24 h-96 w-96 text-gold-500/10" />
      <EightStar className="anim-spin-slow absolute -bottom-32 -right-20 h-[26rem] w-[26rem] text-gold-500/[.07]" />
      <div className="relative mx-auto max-w-3xl px-4 text-center">
        <Reveal>
          <span className="text-[11px] font-extrabold tracking-widest text-gold-400">الصفحة الختامية</span>
          <div className="mx-auto mt-4 flex max-w-xs items-center gap-3">
            <span className="h-px flex-1 bg-gradient-to-l from-gold-400/70 to-transparent" />
            <EightStar className="h-5 w-5 text-gold-400" />
            <span className="h-px flex-1 bg-gradient-to-r from-gold-400/70 to-transparent" />
          </div>
          <p className="mt-8 font-display text-3xl font-bold leading-[1.7] text-cream md:text-[42px]">
            المعلم لا يوثّق ما أنجزه فقط،
            <br />
            بل يوثّق <span className="text-gold-300">أثراً تركه</span> في تعلم طلابه.
          </p>
        </Reveal>
        <Reveal delay={180}>
          <div className="mx-auto mt-12 max-w-md rounded-xl border border-gold-500/40 bg-pine-900/70 px-6 py-5">
            <p className="font-display text-2xl font-bold text-cream">{t.name}</p>
            <p className="mt-1.5 text-sm font-bold text-cream/70">
              {t.specialty} · {t.school}
            </p>
            <p className="mt-1 text-xs font-bold text-gold-300">{t.year}</p>
          </div>
        </Reveal>
        <Reveal delay={300}>
          <button
            className="btn-gold mt-10"
            onClick={() => {
              nav("home");
              window.scrollTo({ top: 0, behavior: "smooth" });
            }}
          >
            <Icon name="chevron" size={15} className="rotate-90" /> العودة إلى البداية
          </button>
        </Reveal>
      </div>
    </div>
  );
}
