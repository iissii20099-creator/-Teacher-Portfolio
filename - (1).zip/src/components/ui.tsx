import { useEffect, useId, useRef, useState, type CSSProperties, type ReactNode } from "react";
import { cn } from "../utils/cn";
import { useViewer } from "../share";

/* ===================== الحركة المفضلة ===================== */
export const prefersReducedMotion = () =>
  typeof window !== "undefined" && window.matchMedia("(prefers-reduced-motion: reduce)").matches;

export function useInView<T extends HTMLElement = HTMLDivElement>(threshold = 0.15) {
  const ref = useRef<T>(null);
  const [on, setOn] = useState(false);
  useEffect(() => {
    const el = ref.current;
    if (!el) return;
    if (prefersReducedMotion()) {
      setOn(true);
      return;
    }
    const io = new IntersectionObserver(
      (es) => {
        for (const e of es)
          if (e.isIntersecting) {
            setOn(true);
            io.disconnect();
          }
      },
      { threshold }
    );
    io.observe(el);
    return () => io.disconnect();
  }, [threshold]);
  return { ref, on };
}

export function useCountUp(end: number, run: boolean, dur = 1400) {
  const [v, setV] = useState(0);
  useEffect(() => {
    if (!run) return;
    if (prefersReducedMotion()) {
      setV(end);
      return;
    }
    let raf = 0;
    const t0 = performance.now();
    const tick = (t: number) => {
      const p = Math.min(1, (t - t0) / dur);
      setV(end * (1 - Math.pow(1 - p, 3)));
      if (p < 1) raf = requestAnimationFrame(tick);
    };
    raf = requestAnimationFrame(tick);
    return () => cancelAnimationFrame(raf);
  }, [end, run, dur]);
  return v;
}

/* ===================== الظهور التدريجي ===================== */
export function Reveal({
  children,
  className,
  delay = 0,
  as: Tag = "div",
}: {
  children: ReactNode;
  className?: string;
  delay?: number;
  as?: React.ElementType;
}) {
  const { ref, on } = useInView<HTMLElement>();
  return (
    <Tag ref={ref} className={cn("reveal", on && "on", className)} style={{ transitionDelay: `${delay}ms` }}>
      {children}
    </Tag>
  );
}

/* ===================== الأيقونات ===================== */
const I = {
  home: (
    <>
      <path d="M3 11l9-8 9 8" />
      <path d="M5 9.5V20h14V9.5" />
      <path d="M9.5 20v-6h5v6" />
    </>
  ),
  user: (
    <>
      <circle cx="12" cy="8" r="4" />
      <path d="M4 21c1.4-3.8 4.6-5.5 8-5.5s6.6 1.7 8 5.5" />
    </>
  ),
  users: (
    <>
      <circle cx="9" cy="8.5" r="3.5" />
      <path d="M2.5 20c1-3.4 3.4-5 6.5-5s5.5 1.6 6.5 5" />
      <path d="M15.5 5.6a3.5 3.5 0 010 5.8M17.8 15.3c2 .7 3.2 2.2 3.7 4.7" />
    </>
  ),
  heart: (
    <path d="M12 20.5C7.5 16.8 3.5 13.4 3.5 9.3 3.5 6.6 5.6 4.8 7.9 4.8c1.8 0 3.2.9 4.1 2.3.9-1.4 2.3-2.3 4.1-2.3 2.3 0 4.4 1.8 4.4 4.5 0 4.1-4 7.5-8.5 11.2z" />
  ),
  layers: (
    <>
      <path d="M12 3.5l9 4.8-9 4.8-9-4.8 9-4.8z" />
      <path d="M3.5 13l8.5 4.5 8.5-4.5" />
      <path d="M3.5 17l8.5 4.5L20.5 17" />
    </>
  ),
  chartUp: (
    <>
      <path d="M3.5 18.5L9.5 12l4 3.2 7.5-8.7" />
      <path d="M15.5 6.5H21V12" />
    </>
  ),
  book: (
    <>
      <path d="M6.5 2.5H19a.8.8 0 01.8.8v17.4a.8.8 0 01-.8.8H6.5A2.5 2.5 0 014 19V5a2.5 2.5 0 012.5-2.5z" />
      <path d="M4 17.5A2.5 2.5 0 016.5 15H19" />
      <path d="M8.5 7.5h7" />
    </>
  ),
  bookOpen: (
    <>
      <path d="M12 6.5A3.2 3.2 0 008.8 4H3v15h6.2c1.6 0 2.8 1.2 2.8 2.8V6.5z" />
      <path d="M12 6.5A3.2 3.2 0 0115.2 4H21v15h-6.2c-1.6 0-2.8 1.2-2.8 2.8V6.5z" />
    </>
  ),
  monitor: (
    <>
      <rect x="3" y="4" width="18" height="12.5" rx="1.5" />
      <path d="M12 16.5V21M8 21h8M9.5 10.5l4-2.5-4-2.5v5z" />
    </>
  ),
  sprout: (
    <>
      <path d="M12 21v-8.5" />
      <path d="M12 12.5C12 8.5 15 6.5 19.5 6.5c0 4-2.8 6-7.5 6z" />
      <path d="M12 12.5c0-3.5-2.6-5.2-6.5-5.2 0 3.5 2.5 5.2 6.5 5.2z" />
    </>
  ),
  clock: (
    <>
      <circle cx="12" cy="12" r="8.5" />
      <path d="M12 7.5V12l3.2 2" />
    </>
  ),
  scan: (
    <>
      <circle cx="11" cy="11" r="6.5" />
      <path d="M15.8 15.8L21 21" />
      <path d="M8.5 13v-1.8M11 13V8.8M13.5 13V10.5" />
    </>
  ),
  scale: (
    <>
      <path d="M12 4v16M8 20h8M4.5 7.5h15" />
      <path d="M6.5 7.5L4 13h5l-2.5-5.5zM17.5 7.5L15 13h5l-2.5-5.5z" />
    </>
  ),
  clipboard: (
    <>
      <rect x="5" y="4.5" width="14" height="17" rx="2" />
      <path d="M9 4.5a3 3 0 016 0" />
      <path d="M8.5 12l2.2 2.2 4.6-4.7M8.5 17h5" />
    </>
  ),
  pencil: (
    <>
      <path d="M4 20l1.2-4.2L16 5l3 3L8.2 18.8 4 20z" />
      <path d="M13.5 7.5l3 3" />
    </>
  ),
  trash: (
    <>
      <path d="M4 7h16M9.5 7V4.5h5V7" />
      <path d="M6.5 7l1 13.5h9l1-13.5" />
      <path d="M10 11v6M14 11v6" />
    </>
  ),
  download: (
    <>
      <path d="M12 3.5v11M7.5 10l4.5 4.5L16.5 10" />
      <path d="M4 20.5h16" />
    </>
  ),
  upload: (
    <>
      <path d="M12 14.5v-11M7.5 8L12 3.5 16.5 8" />
      <path d="M4 20.5h16" />
    </>
  ),
  eye: (
    <>
      <path d="M2.5 12S6 5.5 12 5.5 21.5 12 21.5 12 18 18.5 12 18.5 2.5 12 2.5 12z" />
      <circle cx="12" cy="12" r="3" />
    </>
  ),
  plus: <path d="M12 5v14M5 12h14" />,
  x: <path d="M6 6l12 12M18 6L6 18" />,
  search: (
    <>
      <circle cx="11" cy="11" r="7" />
      <path d="M16.2 16.2L21 21" />
    </>
  ),
  check: <path d="M4.5 12.5l5 5L19.5 7" />,
  calendar: (
    <>
      <rect x="3.5" y="5" width="17" height="16" rx="1.8" />
      <path d="M3.5 10h17M8 3v4M16 3v4" />
    </>
  ),
  link: (
    <>
      <path d="M10.5 13.5a4.5 4.5 0 006.4 0l2.4-2.4a4.5 4.5 0 00-6.4-6.4L11.6 6" />
      <path d="M13.5 10.5a4.5 4.5 0 00-6.4 0l-2.4 2.4a4.5 4.5 0 006.4 6.4l1.3-1.3" />
    </>
  ),
  image: (
    <>
      <rect x="3" y="5" width="18" height="14" rx="1.8" />
      <circle cx="8.5" cy="10" r="1.5" />
      <path d="M21 15.5l-4.5-4.5L8 19.5" />
    </>
  ),
  video: (
    <>
      <rect x="3" y="6.5" width="13" height="11" rx="1.8" />
      <path d="M16 10.5l5-3v9l-5-3" />
    </>
  ),
  external: (
    <>
      <path d="M14 4h6v6M20 4l-9 9" />
      <path d="M9 14H4.5V19a1 1 0 001 1H19a1 1 0 001-1V9.5h-5" />
    </>
  ),
  printer: (
    <>
      <path d="M7 8V3.5h10V8" />
      <path d="M7 16H4a1 1 0 01-1-1V9a1 1 0 011-1h16a1 1 0 011 1v6a1 1 0 01-1 1h-3" />
      <path d="M7 13h10v7.5H7z" />
    </>
  ),
  settings: (
    <>
      <circle cx="12" cy="12" r="3.2" />
      <path d="M12 2.5v3M12 18.5v3M2.5 12h3M18.5 12h3M5 5l2.1 2.1M16.9 16.9L19 19M19 5l-2.1 2.1M7.1 16.9L5 19" />
    </>
  ),
  award: (
    <>
      <circle cx="12" cy="9" r="5.2" />
      <path d="M9 13.5L7.2 21l4.8-2.8L16.8 21 15 13.5" />
    </>
  ),
  trophy: (
    <>
      <path d="M8 3.5h8v5.3a4 4 0 01-8 0V3.5z" />
      <path d="M8 5H4c0 3 1.8 4.8 4 4.8M16 5h4c0 3-1.8 4.8-4 4.8" />
      <path d="M12 12.8v3.2M9 20.5h6M10 16h4l.6 4.5h-5.2L10 16z" />
    </>
  ),
  flag: (
    <>
      <path d="M5.5 21V4" />
      <path d="M5.5 5c2-1.5 4-1.5 6 0s4 1.5 6.5 0v8.5c-2.5 1.5-4.5 1.5-6.5 0s-4-1.5-6 0" />
    </>
  ),
  folder: <path d="M3 6.5a1 1 0 011-1h5.5l2 2.2H20a1 1 0 011 1V18a1 1 0 01-1 1H4a1 1 0 01-1-1V6.5z" />,
  filter: <path d="M4 5h16l-6.2 7.2V18l-3.6 2v-7.8L4 5z" />,
  refresh: (
    <>
      <path d="M20 5.5v5h-5M4 18.5v-5h5" />
      <path d="M19.5 10.5a8 8 0 00-13.6-3.4L4 9.5M4.5 13.5a8 8 0 0013.6 3.4L20 14.5" />
    </>
  ),
  quote: (
    <path
      fill="currentColor"
      stroke="none"
      d="M9.8 6.5H6.3A3.3 3.3 0 003 9.8v3.4c0 .8.6 1.4 1.4 1.4H6.9c.8 0 1.4-.6 1.4-1.4v-2.1H5.9c0-1.2 1-2.2 2.2-2.2V6.5zm9.5 0h-3.5a3.3 3.3 0 00-3.3 3.3v3.4c0 .8.6 1.4 1.4 1.4h2.3c.8 0 1.4-.6 1.4-1.4v-2.1h-2.4c0-1.2 1-2.2 2.2-2.2V6.5z"
    />
  ),
  star8: (
    <>
      <rect x="6.8" y="6.8" width="10.4" height="10.4" />
      <rect x="6.8" y="6.8" width="10.4" height="10.4" transform="rotate(45 12 12)" />
    </>
  ),
  chevron: <path d="M14.5 6l-6 6 6 6" />,
  target: (
    <>
      <circle cx="12" cy="12" r="8.5" />
      <circle cx="12" cy="12" r="4.8" />
      <circle cx="12" cy="12" r="1.4" fill="currentColor" stroke="none" />
    </>
  ),
  shield: (
    <>
      <path d="M12 3l8 3v6.2c0 4.8-3.4 7.8-8 8.8-4.6-1-8-4-8-8.8V6l8-3z" />
      <path d="M8.8 12l2.2 2.2 4.2-4.4" />
    </>
  ),
  building: (
    <>
      <path d="M4.5 21V3.5h15V21" />
      <path d="M2.5 21h19M9 7.5h1.8M13.2 7.5H15M9 11.5h1.8M13.2 11.5H15M10.5 21v-4h3v4" />
    </>
  ),
  layout: (
    <>
      <rect x="3" y="4" width="18" height="16" rx="1.8" />
      <path d="M3 9.5h18M9.5 9.5V20" />
    </>
  ),
  fileText: (
    <>
      <path d="M13.5 3H6a1 1 0 00-1 1v16a1 1 0 001 1h12a1 1 0 001-1V8l-5.5-5z" />
      <path d="M13.5 3v5H19M8.5 13h7M8.5 17h4.5" />
    </>
  ),
  table: (
    <>
      <rect x="3" y="5" width="18" height="14" rx="1.5" />
      <path d="M3 10h18M9.5 5v14M15 5v14" />
    </>
  ),
  sparkles: (
    <>
      <path d="M12 4l1.6 4.4L18 10l-4.4 1.6L12 16l-1.6-4.4L6 10l4.4-1.6L12 4z" />
      <path d="M18.5 15.5l.9 2.1 2.1.9-2.1.9-.9 2.1-.9-2.1-2.1-.9 2.1-.9.9-2.1z" />
    </>
  ),
  rocket: (
    <>
      <path d="M12 3.2c2.8 1.8 4.7 5.3 4.7 8.6l-2.2 3.2H9.5L7.3 11.8c0-3.3 1.9-6.8 4.7-8.6z" />
      <circle cx="12" cy="9.6" r="1.6" />
      <path d="M9.2 15.5L7.8 20l4.2-2 4.2 2-1.4-4.5M12 17.5v3" />
    </>
  ),
  cap: (
    <>
      <path d="M12 4L2 9l10 5 10-5-10-5z" />
      <path d="M6.5 11.5V16c0 1.6 2.5 3 5.5 3s5.5-1.4 5.5-3v-4.5M22 9.5v4.5" />
    </>
  ),
  grid: (
    <>
      <rect x="3.5" y="3.5" width="7" height="7" rx="1" />
      <rect x="13.5" y="3.5" width="7" height="7" rx="1" />
      <rect x="3.5" y="13.5" width="7" height="7" rx="1" />
      <rect x="13.5" y="13.5" width="7" height="7" rx="1" />
    </>
  ),
  star: <path d="M12 3.5l2.6 5.4 5.9.8-4.3 4.1 1 5.8-5.2-2.8-5.2 2.8 1-5.8-4.3-4.1 5.9-.8L12 3.5z" />,
  penLine: (
    <>
      <path d="M4 20l1-3.5L16.5 5a1.8 1.8 0 012.5 2.5L7.5 19 4 20z" />
      <path d="M14.5 7l2.5 2.5" />
    </>
  ),
};

export type IconName = keyof typeof I;

export function Icon({ name, className, size = 20 }: { name: IconName | string; className?: string; size?: number }) {
  const node = (I as Record<string, ReactNode>)[name] ?? I.star8;
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="1.6"
      strokeLinecap="round"
      strokeLinejoin="round"
      className={cn("shrink-0", className)}
      aria-hidden="true"
    >
      {node}
    </svg>
  );
}

/* ===================== الزخارف ===================== */
export function EightStar({ className, style }: { className?: string; style?: CSSProperties }) {
  return (
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1" className={className} style={style} aria-hidden="true">
      <rect x="7" y="7" width="10" height="10" />
      <rect x="7" y="7" width="10" height="10" transform="rotate(45 12 12)" />
      <circle cx="12" cy="12" r="2" />
    </svg>
  );
}

export function Flourish({ className }: { className?: string }) {
  return (
    <svg viewBox="0 0 64 64" fill="none" stroke="currentColor" className={cn("pointer-events-none absolute", className)} aria-hidden="true">
      <path d="M62 2C30 2 2 30 2 62" strokeWidth="1.1" />
      <path d="M47 5.5C26.5 10 8.5 27.5 5.5 47" strokeWidth="0.7" opacity="0.65" />
      <path d="M31 11.5l1.8 3.9 3.9 1.8-3.9 1.8-1.8 3.9-1.8-3.9-3.9-1.8 3.9-1.8 1.8-3.9z" fill="currentColor" stroke="none" opacity="0.75" />
      <circle cx="20" cy="20" r="1.4" fill="currentColor" stroke="none" opacity="0.6" />
    </svg>
  );
}

export function OrnateCard({ children, className, flourish = true }: { children: ReactNode; className?: string; flourish?: boolean }) {
  return (
    <div className={cn("relative rounded-xl border border-gold-300/60 bg-cream shadow-soft", className)}>
      {flourish && (
        <>
          <Flourish className="right-1.5 top-1.5 h-10 w-10 text-gold-500/50" />
          <Flourish className="bottom-1.5 left-1.5 h-10 w-10 rotate-180 text-gold-500/50" />
        </>
      )}
      {children}
    </div>
  );
}

export function GoldDivider({ className }: { className?: string }) {
  return (
    <div className={cn("flex items-center gap-3", className)} aria-hidden="true">
      <span className="h-px flex-1 bg-gradient-to-l from-gold-400/70 to-transparent" />
      <EightStar className="h-4 w-4 text-gold-500" />
      <span className="h-px flex-1 bg-gradient-to-r from-gold-400/70 to-transparent" />
    </div>
  );
}

export function Kicker({ children, icon }: { children: ReactNode; icon?: string }) {
  return (
    <div className="mb-3 flex items-center gap-2.5 text-gold-600">
      <span className="h-px w-9 bg-gold-400/70" />
      {icon && <Icon name={icon} size={15} />}
      <span className="text-[11px] font-extrabold tracking-wide">{children}</span>
    </div>
  );
}

export function SectionHead({ no, title, desc, icon }: { no: string; title: string; desc?: string; icon?: string }) {
  return (
    <Reveal className="mb-9">
      <Kicker icon={icon}>
        {no} · قسم من ملف الإنجاز
      </Kicker>
      <h2 className="mask-line font-display text-3xl font-bold leading-snug text-pine-900 md:text-4xl">
        <span>{title}</span>
      </h2>
      {desc && <p className="mt-3 max-w-2xl text-sm leading-relaxed text-ink-soft md:text-[15px]">{desc}</p>}
    </Reveal>
  );
}

/* ===================== الشارات ===================== */
const STATUS_STYLES: Record<string, { chip: string; dot: string }> = {
  موثق: { chip: "border-pine-600/25 bg-pine-50 text-pine-700", dot: "bg-pine-600" },
  "قيد التوثيق": { chip: "border-gold-500/35 bg-gold-100 text-gold-700", dot: "bg-gold-500" },
  "غير موثق": { chip: "border-sand-dark/60 bg-sand-deep/50 text-ink-faint", dot: "bg-ink-faint" },
};

export function StatusBadge({ status, className }: { status: string; className?: string }) {
  const s = STATUS_STYLES[status] ?? STATUS_STYLES["غير موثق"];
  return (
    <span className={cn("inline-flex items-center gap-1.5 rounded-full border px-2.5 py-0.5 text-[11px] font-bold", s.chip, className)}>
      <span className={cn("h-1.5 w-1.5 rounded-full", s.dot)} />
      {status}
    </span>
  );
}

const FILE_STYLE: Record<string, { icon: string; cls: string }> = {
  PDF: { icon: "fileText", cls: "border-clay/25 bg-clay/10 text-clay" },
  Word: { icon: "fileText", cls: "border-pine-600/25 bg-pine-50 text-pine-700" },
  PowerPoint: { icon: "monitor", cls: "border-gold-500/30 bg-gold-100 text-gold-700" },
  Excel: { icon: "table", cls: "border-olive-500/30 bg-olive-100 text-olive-600" },
  صورة: { icon: "image", cls: "border-olive-500/30 bg-olive-100 text-olive-600" },
  فيديو: { icon: "video", cls: "border-pine-600/25 bg-pine-50 text-pine-700" },
  رابط: { icon: "link", cls: "border-gold-500/30 bg-gold-100 text-gold-700" },
};

export function FileChip({ type, className }: { type: string; className?: string }) {
  const s = FILE_STYLE[type] ?? FILE_STYLE.PDF;
  return (
    <span className={cn("inline-flex items-center gap-1 rounded-md border px-2 py-0.5 text-[11px] font-bold", s.cls, className)}>
      <Icon name={s.icon} size={12} />
      {type}
    </span>
  );
}

/* ===================== المؤشرات الدائرية ===================== */
export function Gauge({ value, size = 216, stroke = 13, sub }: { value: number; size?: number; stroke?: number; sub?: string }) {
  const { ref, on } = useInView<HTMLDivElement>();
  const v = useCountUp(value, on, 1600);
  const id = useId().replace(/[:]/g, "");
  const r = (size - stroke) / 2;
  const C = 2 * Math.PI * r;
  return (
    <div ref={ref} className="relative mx-auto" style={{ width: size, height: size }}>
      <svg width={size} height={size} className="-rotate-90">
        <defs>
          <linearGradient id={`g-${id}`} x1="0" y1="0" x2="1" y2="1">
            <stop offset="0%" stopColor="#c5a663" />
            <stop offset="100%" stopColor="#8f6e33" />
          </linearGradient>
        </defs>
        <circle cx={size / 2} cy={size / 2} r={r} stroke="var(--color-gold-100)" strokeWidth={stroke} fill="none" />
        <circle
          cx={size / 2}
          cy={size / 2}
          r={r}
          stroke={`url(#g-${id})`}
          strokeWidth={stroke}
          fill="none"
          strokeLinecap="round"
          strokeDasharray={C}
          strokeDashoffset={on ? C * (1 - value / 100) : C}
          style={{ transition: "stroke-dashoffset 1.5s cubic-bezier(.22,.61,.36,1) .15s" }}
        />
      </svg>
      <div className="absolute inset-0 flex flex-col items-center justify-center">
        <span className="font-display text-5xl font-bold text-pine-900">
          {Math.round(v)}
          <span className="text-2xl text-gold-600">٪</span>
        </span>
        <span className="mt-1 text-xs font-bold text-ink-soft">{sub ?? "اكتمال ملف الإنجاز"}</span>
      </div>
    </div>
  );
}

export function MiniRing({ value, size = 44, stroke = 4 }: { value: number; size?: number; stroke?: number }) {
  const r = (size - stroke) / 2;
  const C = 2 * Math.PI * r;
  const id = useId().replace(/[:]/g, "");
  return (
    <div className="relative" style={{ width: size, height: size }} title={`اكتمال الملف: ${value}%`}>
      <svg width={size} height={size} className="-rotate-90">
        <circle cx={size / 2} cy={size / 2} r={r} stroke="var(--color-gold-200)" strokeWidth={stroke} fill="none" />
        <circle cx={size / 2} cy={size / 2} r={r} stroke="var(--color-gold-500)" strokeWidth={stroke} fill="none" strokeLinecap="round" strokeDasharray={C} strokeDashoffset={C * (1 - value / 100)} style={{ transition: "stroke-dashoffset 1s ease" }} />
        <defs>
          <linearGradient id={id} />
        </defs>
      </svg>
      <span className="absolute inset-0 flex items-center justify-center text-[10px] font-extrabold text-pine-800">{value}</span>
    </div>
  );
}

/* ===================== الإحصاءات ===================== */
export function StatCard({ icon, value, label, delay = 0 }: { icon: string; value: number; label: string; delay?: number }) {
  const { ref, on } = useInView<HTMLDivElement>();
  const v = useCountUp(value, on, 1200);
  return (
    <Reveal delay={delay}>
      <div
        ref={ref}
        className="card-lift group relative h-full overflow-hidden rounded-xl border border-gold-200 bg-cream p-4 text-center shadow-soft"
      >
        <EightStar className="absolute -left-4 -top-4 h-14 w-14 text-gold-200/60 transition-transform duration-700 group-hover:rotate-45" />
        <div className="relative">
          <span className="mx-auto flex h-10 w-10 items-center justify-center rounded-full border border-gold-300/70 bg-gold-100/60 text-gold-600">
            <Icon name={icon} size={19} />
          </span>
          <div className="mt-2.5 font-display text-4xl font-bold leading-none text-pine-900">{Math.round(v)}</div>
          <div className="mt-1.5 text-xs font-bold text-ink-soft">{label}</div>
        </div>
      </div>
    </Reveal>
  );
}

/* ===================== الرسوم البيانية ===================== */
export function BarCompare({ data, max = 100 }: { data: { label: string; before: number; after: number }[]; max?: number }) {
  const { ref, on } = useInView<HTMLDivElement>();
  return (
    <div ref={ref}>
      <div className="mb-4 flex items-center justify-center gap-5 text-[11px] font-bold text-ink-soft">
        <span className="flex items-center gap-1.5">
          <span className="h-2.5 w-2.5 rounded-sm bg-olive-300" /> قبل التدخل
        </span>
        <span className="flex items-center gap-1.5">
          <span className="h-2.5 w-2.5 rounded-sm bg-pine-700" /> بعد التدخل
        </span>
      </div>
      <div className="grid gap-4 md:gap-6" style={{ gridTemplateColumns: `repeat(${Math.min(data.length, 6)}, minmax(0,1fr))` }}>
        {data.map((d, i) => (
          <div key={d.label} className="flex flex-col items-center gap-2">
            <div className="flex h-44 w-full items-end justify-center gap-1.5 rounded-lg border border-sand-deep/70 bg-white/40 p-2">
              <div
                className="bar-anim w-5 rounded-t-[4px] bg-olive-300 md:w-7"
                style={{ height: on ? `${(d.before / max) * 100}%` : "0%", transitionDelay: `${i * 100}ms` }}
              />
              <div
                className="bar-anim w-5 rounded-t-[4px] bg-pine-700 md:w-7"
                style={{ height: on ? `${(d.after / max) * 100}%` : "0%", transitionDelay: `${i * 100 + 140}ms` }}
              />
            </div>
            <div className="text-center">
              <div className="text-[11px] font-extrabold text-pine-800">
                <span className="text-ink-faint">{d.before}</span>
                <span className="mx-1 text-gold-500">←</span>
                {d.after}
              </div>
              <div className="text-xs font-bold text-ink-soft">{d.label}</div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

export function TrendLine({ points }: { points: { label: string; value: number }[] }) {
  const { ref, on } = useInView<HTMLDivElement>();
  const id = useId().replace(/[:]/g, "");
  const W = 560;
  const H = 210;
  const P = 34;
  const xs = points.map((_, i) => P + (i * (W - 2 * P)) / (points.length - 1));
  const ys = points.map((p) => H - P - (p.value / 100) * (H - 2 * P));
  const dLine = xs.map((x, i) => `${i ? "L" : "M"}${x} ${ys[i]}`).join(" ");
  const dArea = `${dLine} L${xs[xs.length - 1]} ${H - P} L${xs[0]} ${H - P} Z`;
  return (
    <div ref={ref}>
      <svg viewBox={`0 0 ${W} ${H}`} className="w-full">
        <defs>
          <linearGradient id={`t-${id}`} x1="0" y1="0" x2="0" y2="1">
            <stop offset="0%" stopColor="#2c6a51" stopOpacity="0.28" />
            <stop offset="100%" stopColor="#2c6a51" stopOpacity="0.02" />
          </linearGradient>
        </defs>
        {[25, 50, 75, 100].map((g) => {
          const y = H - P - (g / 100) * (H - 2 * P);
          return (
            <g key={g}>
              <line x1={P - 8} x2={W - P + 8} y1={y} y2={y} stroke="var(--color-sand-deep)" strokeDasharray="3 4" />
              <text x={P - 12} y={y + 3} textAnchor="end" fontSize="9" fill="var(--color-ink-faint)">
                {g}
              </text>
            </g>
          );
        })}
        <path d={dArea} fill={`url(#t-${id})`} opacity={on ? 1 : 0} style={{ transition: "opacity 1s ease .8s" }} />
        <path
          d={dLine}
          className={cn("line-draw", on && "on")}
          stroke="var(--color-pine-700)"
          strokeWidth="2.5"
          fill="none"
          strokeLinecap="round"
          strokeLinejoin="round"
        />
        {points.map((p, i) => (
          <g key={p.label}>
            <circle cx={xs[i]} cy={ys[i]} r="4" fill="var(--color-cream)" stroke="var(--color-gold-500)" strokeWidth="2" opacity={on ? 1 : 0} style={{ transition: `opacity .5s ease ${0.4 + i * 0.18}s` }} />
            <text x={xs[i]} y={ys[i] - 10} textAnchor="middle" fontSize="11" fontWeight="800" fill="var(--color-pine-800)" opacity={on ? 1 : 0} style={{ transition: `opacity .5s ease ${0.5 + i * 0.18}s` }}>
              {p.value}
            </text>
            <text x={xs[i]} y={H - P + 16} textAnchor="middle" fontSize="10" fill="var(--color-ink-soft)">
              {p.label}
            </text>
          </g>
        ))}
      </svg>
    </div>
  );
}

const DONUT_COLORS = ["#215340", "#b4914e", "#97a472", "#8f6e33", "#9c4a33"];

export function Donut({ slices, centerLabel, centerValue }: { slices: { label: string; value: number }[]; centerLabel?: string; centerValue?: string }) {
  const { ref, on } = useInView<HTMLDivElement>();
  const size = 190;
  const stroke = 26;
  const r = (size - stroke) / 2;
  const C = 2 * Math.PI * r;
  const total = slices.reduce((a, b) => a + b.value, 0) || 1;
  let acc = 0;
  return (
    <div className="flex flex-wrap items-center justify-center gap-7">
      <div ref={ref} className="relative" style={{ width: size, height: size }}>
        <svg width={size} height={size} className="-rotate-90">
          <circle cx={size / 2} cy={size / 2} r={r} stroke="var(--color-gold-100)" strokeWidth={stroke} fill="none" />
          {slices.map((s, i) => {
            const len = (s.value / total) * C;
            const off = acc;
            acc += len;
            return (
              <circle
                key={s.label}
                className="donut-seg"
                cx={size / 2}
                cy={size / 2}
                r={r}
                stroke={DONUT_COLORS[i % DONUT_COLORS.length]}
                strokeWidth={stroke}
                fill="none"
                strokeDasharray={on ? `${Math.max(len - 2, 0)} ${C - len + 2}` : `0 ${C}`}
                strokeDashoffset={-off}
                style={{ transitionDelay: `${i * 160}ms` }}
              />
            );
          })}
        </svg>
        <div className="absolute inset-0 flex flex-col items-center justify-center text-center">
          <span className="font-display text-3xl font-bold text-pine-900">{centerValue}</span>
          {centerLabel && <span className="mt-0.5 max-w-[90px] text-[10px] font-bold leading-tight text-ink-soft">{centerLabel}</span>}
        </div>
      </div>
      <ul className="space-y-2.5">
        {slices.map((s, i) => (
          <li key={s.label} className="flex items-center gap-2.5 text-sm">
            <span className="h-3 w-3 rounded-sm" style={{ background: DONUT_COLORS[i % DONUT_COLORS.length] }} />
            <span className="font-bold text-ink">{s.label}</span>
            <span className="font-display text-lg font-bold text-pine-800">{s.value}%</span>
          </li>
        ))}
      </ul>
    </div>
  );
}

/* ===================== النوافذ ===================== */
export function Modal({
  open,
  onClose,
  title,
  children,
  wide,
}: {
  open: boolean;
  onClose: () => void;
  title: string;
  children: ReactNode;
  wide?: boolean;
}) {
  useEffect(() => {
    if (!open) return;
    const h = (e: KeyboardEvent) => e.key === "Escape" && onClose();
    window.addEventListener("keydown", h);
    document.body.style.overflow = "hidden";
    return () => {
      window.removeEventListener("keydown", h);
      document.body.style.overflow = "";
    };
  }, [open, onClose]);
  if (!open) return null;
  return (
    <div className="no-print fixed inset-0 z-50 flex items-center justify-center p-3 md:p-6" role="dialog" aria-modal="true">
      <div className="modal-fade absolute inset-0 bg-pine-950/55 backdrop-blur-[3px]" onClick={onClose} />
      <div className={cn("modal-panel relative max-h-[90vh] w-full overflow-y-auto rounded-xl border border-gold-300/70 bg-cream shadow-2xl", wide ? "max-w-3xl" : "max-w-xl")}>
        <div className="sticky top-0 z-10 flex items-center justify-between border-b border-gold-200/70 bg-cream/95 px-5 py-3.5 backdrop-blur">
          <h3 className="font-display text-xl font-bold text-pine-900">{title}</h3>
          <button onClick={onClose} className="icon-btn" aria-label="إغلاق">
            <Icon name="x" size={16} />
          </button>
        </div>
        <div className="p-5">{children}</div>
      </div>
    </div>
  );
}

export function Field({ label, children, className }: { label: string; children: ReactNode; className?: string }) {
  return (
    <label className={cn("block", className)}>
      <span className="lbl">{label}</span>
      {children}
    </label>
  );
}

/* مفتاح تشغيل/إيقاف — يعتمد الاتجاه المنطقي فيعمل صح في RTL */
export function Switch({
  checked,
  onChange,
  label,
}: {
  checked: boolean;
  onChange: (v: boolean) => void;
  label: string;
}) {
  return (
    <button
      type="button"
      role="switch"
      aria-checked={checked}
      aria-label={label}
      onClick={() => onChange(!checked)}
      className={cn(
        "relative inline-flex h-7 w-[54px] shrink-0 cursor-pointer items-center rounded-full border transition-colors duration-300 focus:outline-none focus-visible:ring-2 focus-visible:ring-gold-400/70",
        checked ? "border-pine-700 bg-pine-700" : "border-sand-dark bg-sand-deep"
      )}
    >
      <span
        className={cn(
          "absolute flex h-5 w-5 items-center justify-center rounded-full bg-cream shadow-soft transition-all duration-300",
          checked ? "end-[3px] text-pine-700" : "start-[3px] text-ink-faint"
        )}
      >
        <Icon name={checked ? "check" : "x"} size={12} className="transition-opacity duration-200" />
      </span>
    </button>
  );
}

export function ConfirmDelete({ onConfirm, label = "حذف" }: { onConfirm: () => void; label?: string }) {
  const viewer = useViewer();
  const [arm, setArm] = useState(false);
  useEffect(() => {
    if (!arm) return;
    const t = setTimeout(() => setArm(false), 3200);
    return () => clearTimeout(t);
  }, [arm]);
  if (viewer) return null;
  return (
    <button
      className={cn("btn-danger", arm && "border-clay bg-clay text-white hover:bg-clay")}
      onClick={() => (arm ? (setArm(false), onConfirm()) : setArm(true))}
    >
      <Icon name="trash" size={13} />
      {arm ? "تأكيد الحذف؟" : label}
    </button>
  );
}
