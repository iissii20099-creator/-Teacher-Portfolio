/**
 * منظّم Google Drive — يبني هيكل المجلدات داخل مجلد تختاره أنت،
 * ويرفع/ينقل الشواهد والملفات إلى أماكنها الصحيحة مع سجل تنفيذ حيّ.
 */
import { useEffect, useRef, useState } from "react";
import { fmtDate, toAr } from "./data";
import { useStore } from "./store";
import { isDriveUrl, parseDriveId, useDrive, type DriveFile } from "./googleDrive";
import { Icon } from "./components/ui";
import { cn } from "./utils/cn";

export const ROOT_KEY = "tp-drive-root";
export const getRoot = () => localStorage.getItem(ROOT_KEY) ?? "";
export const saveRoot = (id: string) => (id ? localStorage.setItem(ROOT_KEY, id) : localStorage.removeItem(ROOT_KEY));

export const PORTFOLIO_DOC = "portfolio.json";

const TREE: { key: string; name: string; note: string }[] = [
  { key: "doc", name: "00 · ملف الإنجاز", note: "نسخة الملف الكاملة والفهارس" },
  { key: "evidence", name: "01 · الشواهد", note: "مجلد فرعي لكل معيار من المعايير" },
  { key: "practices", name: "02 · الممارسات المهنية", note: "الدروس والاستراتيجيات والمشاريع" },
  { key: "plan", name: "03 · الخطة التعليمية", note: "الخطة الفصلية والتوزيع وأوراق العمل" },
  { key: "results", name: "04 · نتائج الطلاب", note: "التحليلات والمقارنات والخطط العلاجية" },
  { key: "dev", name: "05 · التطوير المهني", note: "الدورات والورش وشهاداتها" },
  { key: "ach", name: "06 · الإنجازات والتكريمات", note: "الشهادات والمسابقات والمبادرات" },
  { key: "media", name: "07 · الصور والوسائط", note: "مكتبة الصور المرفوعة" },
  { key: "reports", name: "08 · التقارير", note: "التقارير المصدّرة للجهة" },
];

const sleep = (ms: number) => new Promise((r) => setTimeout(r, ms));
const pad = (n: number) => String(n).padStart(2, "0");
const safe = (s: string) => s.replace(/[\\/:*?"<>|#]/g, "-").replace(/\s+/g, " ").trim().slice(0, 70) || "بلا-عنوان";
const mimeOf = (dataUrl: string) => (dataUrl.startsWith("data:") ? dataUrl.slice(5, dataUrl.indexOf(";")) || "application/octet-stream" : "text/plain");
const EXT: Record<string, string> = {
  "application/pdf": "pdf",
  "image/jpeg": "jpg",
  "image/png": "png",
  "image/webp": "webp",
  "image/gif": "gif",
  "video/mp4": "mp4",
  "application/json": "json",
  "text/plain": "txt",
  "application/msword": "doc",
};
const extOf = (mime: string, fallback = "bin") => EXT[mime] ?? fallback;

type StepState = "working" | "done" | "failed" | "skipped";
interface Step {
  id: number;
  label: string;
  state: StepState;
  note?: string;
}

/* ===================== معاينة الهيكل ===================== */
function TreePreview({ criteria }: { criteria: { id: number; title: string }[] }) {
  const rows: { p: string; t: string; sub: boolean }[] = [];
  TREE.forEach((node) => {
    rows.push({ p: "├─", t: node.name, sub: false });
    if (node.key === "evidence") {
      criteria.forEach((c, i) => {
        rows.push({
          p: i === criteria.length - 1 ? "│  └─" : "│  ├─",
          t: `معيار ${pad(c.id)} · ${c.title}`,
          sub: true,
        });
      });
    }
  });
  return (
    <div className="mt-3 max-h-64 overflow-y-auto rounded-lg border border-cream/10 bg-pine-950/70 p-3">
      <p className="font-mono text-[11px] font-bold text-gold-300" dir="rtl">
        📁 مجلدك على Drive
      </p>
      {rows.map((r, i) => (
        <p
          key={i}
          className={cn("font-mono text-[11px] leading-6", r.sub ? "text-cream/55" : "text-cream/85")}
          style={{ paddingInlineStart: r.sub ? 14 : 6 }}
          dir="rtl"
        >
          <span className="text-gold-500/70">{r.p}</span> {r.t}
        </p>
      ))}
    </div>
  );
}

/* ===================== اللوحة ===================== */
export function OrganizePanel() {
  const { state } = useStore();
  const d = useDrive();
  const [input, setInput] = useState(getRoot());
  const [root, setRoot] = useState<{ id: string; name: string; link: string } | null>(null);
  const [verifying, setVerifying] = useState(false);
  const [vErr, setVErr] = useState("");
  const [showTree, setShowTree] = useState(false);

  const [opts, setOpts] = useState({ structure: true, docs: true, uploads: true, moves: true });
  const [log, setLog] = useState<Step[]>([]);
  const [total, setTotal] = useState(0);
  const [running, setRunning] = useState(false);
  const stop = useRef(false);
  const seq = useRef(0);
  const endRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    endRef.current?.scrollIntoView({ block: "nearest" });
  }, [log.length]);

  const addStep = (label: string) => {
    const id = ++seq.current;
    setLog((l) => [...l, { id, label, state: "working" }]);
    return {
      done: (note?: string) => setLog((l) => l.map((x) => (x.id === id ? { ...x, state: "done" as StepState, note } : x))),
      fail: (note?: string) => setLog((l) => l.map((x) => (x.id === id ? { ...x, state: "failed" as StepState, note } : x))),
      skip: (note?: string) => setLog((l) => l.map((x) => (x.id === id ? { ...x, state: "skipped" as StepState, note } : x))),
    };
  };

  const msg = (e: unknown) => (e instanceof Error ? e.message : "خطأ غير معروف");

  /* ---------- التحقق من رابط المجلد ---------- */
  const verify = async () => {
    setVErr("");
    const id = parseDriveId(input);
    if (!id) {
      setVErr("لم أتعرف على معرّف المجلد — الصق رابط المجلد من شريط العنوان في Drive (يحتوي /folders/…).");
      return;
    }
    setVerifying(true);
    try {
      const f = (await d.api(
        `https://www.googleapis.com/drive/v3/files/${id}?fields=id,name,mimeType,webViewLink,capabilities(canAddChildren,canEdit)`
      )) as DriveFile & { capabilities?: { canAddChildren?: boolean } };
      if (f.mimeType !== "application/vnd.google-apps.folder") throw new Error("الرابط يشير إلى ملف لا إلى مجلد.");
      if (f.capabilities?.canAddChildren === false) throw new Error("لا تملك صلاحية الإضافة داخل هذا المجلد — شاركه مع حسابك كمحرر.");
      setRoot({ id: f.id, name: f.name, link: f.webViewLink });
      saveRoot(f.id);
    } catch (e) {
      setRoot(null);
      setVErr(msg(e));
    } finally {
      setVerifying(false);
    }
  };

  /* ---------- تنفيذ التنظيم ---------- */
  const run = async () => {
    if (!root) return;
    stop.current = false;
    setRunning(true);
    setLog([]);
    const ids: Record<string, string> = {};
    const structTotal = opts.structure ? TREE.length + (opts.structure ? state.criteria.length : 0) : 0;
    setTotal(structTotal || 1);

    try {
      /* 1) الهيكل */
      if (opts.structure) {
        for (const node of TREE) {
          if (stop.current) break;
          const s = addStep(`مجلد «${node.name}»`);
          try {
            const f = await d.ensureChild(root.id, node.name);
            ids[node.key] = f.id;
            s.done("جاهز");
          } catch (e) {
            s.fail(msg(e));
          }
          await sleep(110);
        }
        if (ids.evidence) {
          for (const c of state.criteria) {
            if (stop.current) break;
            const s = addStep(`مجلد المعيار ${toAr(c.id)} · ${c.title}`);
            try {
              ids[`c${c.id}`] = (await d.ensureChild(ids.evidence, `معيار ${pad(c.id)} · ${safe(c.title)}`)).id;
              s.done("جاهز");
            } catch (e) {
              s.fail(msg(e));
            }
            await sleep(110);
          }
        }
      }

      /* 2) وثائق الملف والفهارس */
      if (opts.docs && ids.doc) {
        const s1 = addStep(`رفع ${PORTFOLIO_DOC} (نسخة الملف الكاملة)`);
        try {
          await d.uploadBytes(PORTFOLIO_DOC, "application/json", JSON.stringify({ v: 1, savedAt: new Date().toISOString(), state }), ids.doc);
          s1.done("يمكن استرجاع الملف منها");
        } catch (e) {
          s1.fail(msg(e));
        }
        await sleep(110);

        const s2 = addStep("رفع «ملخص-الملف.txt»");
        try {
          const t = state.teacher;
          const body = [
            `ملف إنجاز المعلم — ${t.name}`,
            `التخصص: ${t.specialty} | المدرسة: ${t.school} | العام: ${t.year}`,
            `المؤهل: ${t.degree}`,
            `الرخصة: ${t.license} | سنوات الخبرة: ${t.experience}`,
            "",
            `عدد المعايير: ${state.criteria.length}`,
            `عدد الشواهد: ${state.evidence.length}`,
            `عدد الممارسات: ${state.practices.length}`,
            `عناصر التطوير المهني: ${state.development.length}`,
            `الإنجازات: ${state.achievements.length}`,
            "",
            ...state.criteria.map((c) => {
              const mine = state.evidence.filter((e) => e.criterionId === c.id);
              return `معيار ${pad(c.id)} · ${c.title} — ${mine.length} شاهداً`;
            }),
          ].join("\n");
          await d.uploadBytes("ملخص-الملف.txt", "text/plain", body, ids.doc);
          s2.done();
        } catch (e) {
          s2.fail(msg(e));
        }
        await sleep(110);

        for (const c of state.criteria) {
          const mine = state.evidence.filter((e) => e.criterionId === c.id);
          if (!mine.length) continue;
          if (stop.current) break;
          const s = addStep(`فهرس المعيار ${toAr(c.id)}`);
          try {
            const body = [
              `معيار ${pad(c.id)} · ${c.title}`,
              c.short,
              "",
              "المؤشرات:",
              ...c.indicators.map((x, i) => `${i + 1}. ${x}`),
              "",
              `الشواهد (${mine.length}):`,
              ...mine.map((e) => `- ${e.title} | ${e.type} | ${fmtDate(e.date)} | ${e.semester}`),
              "",
              "الأثر:",
              c.impact,
              "",
              "التأمل المهني:",
              c.reflection,
            ].join("\n");
            await d.uploadBytes(`فهرس-المعيار-${pad(c.id)}.txt`, "text/plain", body, ids[`c${c.id}`] ?? ids.doc);
            s.done();
          } catch (e) {
            s.fail(msg(e));
          }
          await sleep(110);
        }
      }

      /* 3) رفع الشواهد المحلية إلى مجلد معيارها */
      if (opts.uploads) {
        for (const e of state.evidence) {
          if (stop.current) break;
          const parent = ids[`c${e.criterionId}`] ?? ids.evidence ?? ids.doc;
          if (!parent) continue;
          const targets = [e.file?.url, e.image].filter((u): u is string => !!u && u.startsWith("data:"));
          if (!targets.length) continue;
          for (const url of targets) {
            const s = addStep(`رفع «${safe(e.title)}»`);
            try {
              const mime = mimeOf(url);
              const isImg = url === e.image;
              await d.uploadBytes(`${safe(e.title)}${isImg ? "-صورة" : ""}.${extOf(mime)}`, mime, url, parent);
              s.done(`معيار ${toAr(e.criterionId)}`);
            } catch (err) {
              s.fail(msg(err));
            }
            await sleep(140);
          }
        }

        /* مكتبة الملفات المحلية */
        for (const f of state.files) {
          if (stop.current) break;
          if (!f.url?.startsWith("data:")) continue;
          const s = addStep(`رفع ملف المكتبة «${f.name}»`);
          try {
            const mime = mimeOf(f.url);
            await d.uploadBytes(f.name.includes(".") ? f.name : `${safe(f.name)}.${extOf(mime)}`, mime, f.url, mime.startsWith("image/") ? (ids.media ?? ids.doc) : (ids.doc ?? root.id));
            s.done();
          } catch (err) {
            s.fail(msg(err));
          }
          await sleep(140);
        }
      }

      /* 4) نقل ملفات Drive المرتبطة إلى مجلداتها */
      if (opts.moves) {
        for (const e of state.evidence) {
          if (stop.current) break;
          const links = [e.file?.url, e.image, e.link].filter((u): u is string => !!u && isDriveUrl(u) && !u.startsWith("data:"));
          if (!links.length) continue;
          const parent = ids[`c${e.criterionId}`] ?? ids.evidence;
          if (!parent) continue;
          for (const url of links) {
            const fid = parseDriveId(url);
            if (!fid) continue;
            const s = addStep(`نقل «${safe(e.title)}» إلى مجلد المعيار ${toAr(e.criterionId)}`);
            try {
              await d.moveTo(fid, parent);
              s.done();
            } catch (err) {
              s.skip(`${msg(err)} — قد يكون الملف خارج صلاحياتك`);
            }
            await sleep(140);
          }
        }
      }
    } finally {
      setRunning(false);
    }
  };

  /* ---------- الحالة ---------- */
  const done = log.filter((x) => x.state === "done").length;
  const failed = log.filter((x) => x.state === "failed").length;
  const skipped = log.filter((x) => x.state === "skipped").length;
  const pct = log.length ? Math.round((log.filter((x) => x.state !== "working").length / Math.max(log.length, total)) * 100) : 0;
  const available = d.enabled && d.ready && !!d.account;

  if (!available) {
    return (
      <div className="rounded-xl border border-gold-200/80 bg-cream p-5 shadow-soft">
        <h4 className="flex items-center gap-2 font-display text-lg font-bold text-pine-900">
          <Icon name="folder" size={17} className="text-gold-600" /> منظّم مجلد Drive
        </h4>
        <p className="mt-2 text-xs font-bold leading-relaxed text-ink-soft">
          {d.enabled ? "اربط حساب Google أولاً ليصبح بإمكانك بناء هيكل المجلدات داخل مجلدك الخاص." : "فعّل ربط Google Drive من المفتاح أعلاه."}
        </p>
      </div>
    );
  }

  return (
    <div className="relative overflow-hidden rounded-xl border border-gold-200/80 bg-cream p-5 shadow-soft md:p-6">
      <div className="flex flex-wrap items-start justify-between gap-3">
        <div>
          <h4 className="flex items-center gap-2 font-display text-xl font-bold text-pine-900">
            <Icon name="folder" size={19} className="text-gold-600" /> منظّم مجلد Drive
          </h4>
          <p className="mt-1.5 max-w-2xl text-[11px] font-bold leading-relaxed text-ink-soft">
            الصق رابط أي مجلد في حسابك، فيتحقق الموقع من صلاحيتك عليه ثم يبني داخله هيكل ملف الإنجاز كاملاً: مجلد لكل قسم، ومجلد لكل معيار داخل «الشواهد»، مع رفع الفهارس والملفات وتوزيعها في أماكنها.
          </p>
        </div>
        <button className="btn-ghost shrink-0 !px-3 !py-1 !text-[11px]" onClick={() => setShowTree((v) => !v)}>
          <Icon name={showTree ? "x" : "folder"} size={12} /> {showTree ? "إخفاء الهيكل" : "معاينة الهيكل"}
        </button>
      </div>

      {showTree && <TreePreview criteria={state.criteria} />}

      {/* رابط المجلد */}
      <div className="mt-4 rounded-lg border border-sand-deep/70 bg-cream-deep/50 p-3.5">
        <label className="lbl" htmlFor="drive-root">
          رابط مجلد Google Drive (أو معرّف المجلد)
        </label>
        <div className="flex flex-col gap-2 sm:flex-row">
          <input
            id="drive-root"
            className="inp flex-1 font-mono !text-[11px]"
            dir="ltr"
            placeholder="https://drive.google.com/drive/folders/1AbC…"
            value={input}
            onChange={(e) => {
              setInput(e.target.value);
              setVErr("");
            }}
          />
          <button className="btn-soft shrink-0" onClick={verify} disabled={verifying || !input.trim()}>
            <Icon name={verifying ? "refresh" : "check"} size={14} className={verifying ? "animate-spin" : ""} />
            {verifying ? "جارٍ التحقق…" : "تحقق من المجلد"}
          </button>
        </div>
        {vErr && <p className="mt-2 text-[11px] font-bold leading-relaxed text-clay">{vErr}</p>}
        {root && (
          <div className="mt-2.5 flex flex-wrap items-center gap-2 rounded-lg border border-pine-600/25 bg-pine-50 px-3 py-2">
            <Icon name="check" size={14} className="text-pine-700" />
            <span className="text-xs font-extrabold text-pine-900">{root.name}</span>
            <span className="text-[10px] font-bold text-ink-faint" dir="ltr">
              {root.id}
            </span>
            <a className="btn-ghost ms-auto !px-2.5 !py-0.5 !text-[10px]" href={root.link} target="_blank" rel="noreferrer">
              <Icon name="external" size={11} /> فتح
            </a>
          </div>
        )}
      </div>

      {/* الخيارات */}
      <div className="mt-4 grid grid-cols-1 gap-2 sm:grid-cols-2">
        {[
          ["structure", "بناء هيكل المجلدات", `${toAr(TREE.length)} مجلدات رئيسية + ${toAr(state.criteria.length)} مجلد معيار`],
          ["docs", "الفهارس ونسخة الملف", "portfolio.json + ملخص وفهرس لكل معيار"],
          ["uploads", "رفع الملفات المحلية", "الشواهد والصور المحفوظة في المتصفح"],
          ["moves", "نقل ملفات Drive المرتبطة", "إعادة ترتيب الشواهد المرتبطة إلى مجلداتها"],
        ].map(([k, label, hint]) => (
          <label key={k} className="flex cursor-pointer items-start gap-2.5 rounded-lg border border-sand-deep/70 bg-white/50 px-3 py-2.5 transition hover:border-gold-400">
            <input
              type="checkbox"
              className="mt-0.5 h-4 w-4 shrink-0 accent-[#215340]"
              checked={opts[k as keyof typeof opts]}
              onChange={(e) => setOpts({ ...opts, [k]: e.target.checked })}
            />
            <span>
              <span className="block text-xs font-extrabold text-pine-900">{label}</span>
              <span className="mt-0.5 block text-[10px] font-bold leading-relaxed text-ink-faint">{hint}</span>
            </span>
          </label>
        ))}
      </div>

      {/* التشغيل */}
      <div className="mt-4 flex flex-wrap items-center gap-2 border-t border-gold-200/60 pt-4">
        <button className="btn-primary" onClick={run} disabled={!root || running || !Object.values(opts).some(Boolean)}>
          <Icon name={running ? "refresh" : "sparkles"} size={15} className={running ? "animate-spin" : ""} />
          {running ? "جارٍ التنظيم…" : "ابدأ التنظيم"}
        </button>
        {running && (
          <button className="btn-danger !px-4 !py-2 !text-sm" onClick={() => (stop.current = true)}>
            <Icon name="x" size={14} /> إيقاف بعد الخطوة الحالية
          </button>
        )}
        {log.length > 0 && !running && (
          <button className="btn-ghost" onClick={() => setLog([])}>
            <Icon name="refresh" size={14} /> مسح السجل
          </button>
        )}
        {log.length > 0 && (
          <span className="ms-auto flex flex-wrap items-center gap-2 text-[10px] font-extrabold">
            <span className="text-pine-700">{toAr(done)} تم</span>
            {failed > 0 && <span className="text-clay">{toAr(failed)} فشل</span>}
            {skipped > 0 && <span className="text-ink-faint">{toAr(skipped)} تخطّي</span>}
          </span>
        )}
      </div>

      {/* شريط التقدم والسجل */}
      {log.length > 0 && (
        <div className="mt-3 overflow-hidden rounded-lg border border-pine-800 bg-pine-950">
          <div className="h-1 bg-pine-900">
            <div className="h-full bg-gradient-to-l from-gold-400 to-pine-500 transition-all duration-500" style={{ width: `${Math.min(100, pct)}%` }} />
          </div>
          <div className="max-h-72 overflow-y-auto p-3">
            {log.map((s) => (
              <div key={s.id} className="flex items-start gap-2 border-b border-cream/5 py-1.5 last:border-0">
                <span
                  className={cn(
                    "mt-0.5 flex h-4 w-4 shrink-0 items-center justify-center rounded-full",
                    s.state === "done" && "bg-pine-600 text-white",
                    s.state === "failed" && "bg-clay text-white",
                    s.state === "skipped" && "bg-cream/15 text-cream/60",
                    s.state === "working" && "bg-gold-500/20 text-gold-300"
                  )}
                >
                  {s.state === "working" ? (
                    <Icon name="refresh" size={10} className="animate-spin" />
                  ) : s.state === "done" ? (
                    <Icon name="check" size={10} />
                  ) : (
                    <Icon name="x" size={10} />
                  )}
                </span>
                <span className="min-w-0 flex-1">
                  <span
                    className={cn(
                      "block truncate text-[11px] font-bold",
                      s.state === "done" ? "text-cream/85" : s.state === "failed" ? "text-[#e8b3a2]" : s.state === "skipped" ? "text-cream/45" : "text-gold-200"
                    )}
                  >
                    {s.label}
                  </span>
                  {s.note && <span className="block truncate text-[10px] font-bold text-cream/40">{s.note}</span>}
                </span>
              </div>
            ))}
            <div ref={endRef} />
          </div>
        </div>
      )}
    </div>
  );
}
