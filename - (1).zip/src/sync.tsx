/**
 * مزامنة ملف الإنجاز مع Google Drive
 * — مجلد خاص، حفظ/استرجاع، مزامنة تلقائية، وكشف تعارض النسخ.
 */
import { createContext, useCallback, useContext, useEffect, useMemo, useState, type ReactNode } from "react";
import { useStore } from "./store";
import { useDrive } from "./googleDrive";
import { getRoot } from "./organize";
import type { State } from "./data";
import { Icon, Switch } from "./components/ui";
import { cn } from "./utils/cn";

const META_KEY = "tp-sync-meta";
const FOLDER_NAME = "ملف إنجاز المعلم";
const DOC_NAME = "portfolio.json";
const DRIVE = "https://www.googleapis.com/drive/v3";
const UPLOAD = "https://www.googleapis.com/upload/drive/v3";

export interface SyncMeta {
  folderId: string | null;
  fileId: string | null;
  folderLink: string | null;
  at: string | null;
  remoteTime: string | null;
  fp: string | null;
  auto: boolean;
}

const EMPTY: SyncMeta = { folderId: null, fileId: null, folderLink: null, at: null, remoteTime: null, fp: null, auto: true };

function readMeta(): SyncMeta {
  try {
    const raw = localStorage.getItem(META_KEY);
    return raw ? { ...EMPTY, ...(JSON.parse(raw) as SyncMeta) } : EMPTY;
  } catch {
    return EMPTY;
  }
}

function fingerprint(s: unknown): string {
  const str = JSON.stringify(s);
  let h1 = 0x811c9dc5;
  let h2 = 0x9e3779b1;
  for (let i = 0; i < str.length; i++) {
    h1 = ((h1 ^ str.charCodeAt(i)) * 16777619) >>> 0;
    h2 = ((h2 ^ (str.charCodeAt(i) + i)) * 2246822519) >>> 0;
  }
  return `${h1.toString(36)}${h2.toString(36)}${str.length.toString(36)}`;
}

export function relTime(iso: string | null): string {
  if (!iso) return "لم تتم مزامنة بعد";
  const diff = Date.now() - new Date(iso).getTime();
  if (diff < 45_000) return "الآن";
  const m = Math.floor(diff / 60_000);
  if (m < 60) return `قبل ${m} دقيقة`;
  const h = Math.floor(m / 60);
  if (h < 24) return `قبل ${h} ساعة`;
  return new Date(iso).toLocaleDateString("ar-EG-u-nu-latn", { day: "numeric", month: "long" });
}

export type SyncStatus = "off" | "idle" | "dirty" | "saving" | "pulling" | "conflict" | "error";

interface SyncCtl {
  available: boolean;
  status: SyncStatus;
  meta: SyncMeta;
  error: string;
  dirty: boolean;
  push: (force?: boolean) => Promise<void>;
  pull: () => Promise<void>;
  setAuto: (v: boolean) => void;
  unlink: () => void;
  clearError: () => void;
}

const Ctx = createContext<SyncCtl | null>(null);

export function useSync(): SyncCtl {
  const c = useContext(Ctx);
  if (!c) throw new Error("useSync must be used inside SyncProvider");
  return c;
}

export function SyncProvider({ disabled, children }: { disabled?: boolean; children: ReactNode }) {
  const { state, importState } = useStore();
  const d = useDrive();
  const [meta, setMeta] = useState<SyncMeta>(readMeta);
  const [working, setWorking] = useState<"saving" | "pulling" | null>(null);
  const [conflict, setConflict] = useState(false);
  const [error, setError] = useState("");

  const fp = useMemo(() => fingerprint(state), [state]);
  const available = !disabled && d.enabled && d.ready && !!d.account;

  const persist = useCallback((m: SyncMeta) => {
    setMeta(m);
    try {
      localStorage.setItem(META_KEY, JSON.stringify(m));
    } catch {
      /* تجاهل */
    }
  }, []);

  const dirty = available && !!meta.fileId && meta.fp !== fp;

  /* ---------- أدوات Drive ---------- */
  const findFolder = useCallback(async () => {
    const q = encodeURIComponent(`name = '${FOLDER_NAME}' and mimeType = 'application/vnd.google-apps.folder' and trashed = false`);
    const r = await d.api<{ files: { id: string; webViewLink: string }[] }>(`${DRIVE}/files?fields=files(id,webViewLink)&pageSize=1&q=${q}`);
    return r.files?.[0] ?? null;
  }, [d]);

  const ensureFolder = useCallback(async () => {
    const found = await findFolder();
    if (found) return found;
    const root = getRoot();
    const created = await d.api<{ id: string; webViewLink: string }>(`${DRIVE}/files`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        name: FOLDER_NAME,
        mimeType: "application/vnd.google-apps.folder",
        ...(root ? { parents: [root] } : {}),
      }),
    });
    return created;
  }, [d, findFolder]);

  const findDoc = useCallback(
    async (folderId: string) => {
      const q = encodeURIComponent(`name = '${DOC_NAME}' and '${folderId}' in parents and trashed = false`);
      const r = await d.api<{ files: { id: string }[] }>(`${DRIVE}/files?fields=files(id)&pageSize=1&q=${q}`);
      return r.files?.[0]?.id ?? null;
    },
    [d]
  );

  const putDoc = useCallback(
    async (fileId: string | null, folderId: string, body: string) => {
      if (fileId) {
        await d.api(`${UPLOAD}/files/${fileId}?uploadType=media`, {
          method: "PATCH",
          headers: { "Content-Type": "application/json" },
          body,
        });
        return fileId;
      }
      const boundary = `----tpsync${Date.now().toString(36)}`;
      const metaPart = `--${boundary}\r\nContent-Type: application/json; charset=UTF-8\r\n\r\n${JSON.stringify({
        name: DOC_NAME,
        parents: [folderId],
        mimeType: "application/json",
      })}\r\n--${boundary}\r\nContent-Type: application/json\r\n\r\n${body}\r\n--${boundary}--`;
      const r = await d.api<{ id: string }>(`${UPLOAD}/files?uploadType=multipart`, {
        method: "POST",
        headers: { "Content-Type": `multipart/related; boundary=${boundary}` },
        body: metaPart,
      });
      return r.id;
    },
    [d]
  );

  /* ---------- الحفظ على Drive ---------- */
  const push = useCallback(
    async (force = false) => {
      if (!available) return;
      setWorking("saving");
      setError("");
      try {
        const folder = meta.folderId ? { id: meta.folderId, webViewLink: meta.folderLink ?? "" } : await ensureFolder();
        let fileId = meta.fileId ?? (await findDoc(folder.id));

        if (fileId && !force) {
          const md = await d.api<{ modifiedTime: string }>(`${DRIVE}/files/${fileId}?fields=modifiedTime`);
          if (meta.remoteTime && md.modifiedTime > meta.remoteTime) {
            setConflict(true);
            setWorking(null);
            return;
          }
        }

        const body = JSON.stringify({ v: 1, savedAt: new Date().toISOString(), teacher: state.teacher.name, state });
        fileId = await putDoc(fileId, folder.id, body);
        const md2 = await d.api<{ modifiedTime: string }>(`${DRIVE}/files/${fileId}?fields=modifiedTime`);

        persist({
          folderId: folder.id,
          fileId,
          folderLink: folder.webViewLink || meta.folderLink,
          at: new Date().toISOString(),
          remoteTime: md2.modifiedTime,
          fp,
          auto: meta.auto,
        });
        setConflict(false);
      } catch (e) {
        setError(e instanceof Error ? e.message : "تعذّر الحفظ على Google Drive.");
      } finally {
        setWorking(null);
      }
    },
    [available, meta, d, state, fp, persist, ensureFolder, findDoc, putDoc]
  );

  /* ---------- الاسترجاع من Drive ---------- */
  const pull = useCallback(async () => {
    if (!available) return;
    setWorking("pulling");
    setError("");
    try {
      const folder = meta.folderId ? { id: meta.folderId, webViewLink: meta.folderLink ?? "" } : await ensureFolder();
      const fileId = meta.fileId ?? (await findDoc(folder.id));
      if (!fileId) throw new Error("لا توجد نسخة محفوظة على Drive بعد — احفظ ملفك أولاً.");
      const text = await d.apiText(`${DRIVE}/files/${fileId}?alt=media`);
      const parsed = JSON.parse(text);
      const incoming = (parsed?.state ?? parsed) as State;
      if (!incoming?.teacher || !Array.isArray(incoming.criteria) || !Array.isArray(incoming.evidence)) {
        throw new Error("بنية الملف المحفوظ على Drive غير صالحة.");
      }
      importState(incoming);
      const md = await d.api<{ modifiedTime: string }>(`${DRIVE}/files/${fileId}?fields=modifiedTime`);
      persist({
        folderId: folder.id,
        fileId,
        folderLink: folder.webViewLink || meta.folderLink,
        at: new Date().toISOString(),
        remoteTime: md.modifiedTime,
        fp: fingerprint(incoming),
        auto: meta.auto,
      });
      setConflict(false);
    } catch (e) {
      setError(e instanceof Error ? e.message : "تعذّر الاسترجاع من Google Drive.");
    } finally {
      setWorking(null);
    }
  }, [available, meta, d, importState, persist, ensureFolder, findDoc]);

  /* ---------- مزامنة تلقائية بعد التوقف عن التحرير ---------- */
  useEffect(() => {
    if (!available || !meta.auto || !dirty || working || conflict) return;
    const t = setTimeout(() => void push(), 6000);
    return () => clearTimeout(t);
  }, [available, meta.auto, dirty, working, conflict, fp, push]);

  /* ---------- قطع ربط المزامنة (يبقي الملفات على Drive) ---------- */
  const unlink = useCallback(() => {
    persist({ ...EMPTY, auto: meta.auto });
    setConflict(false);
    setError("");
  }, [persist, meta.auto]);

  const status: SyncStatus = !available
    ? "off"
    : working
      ? working
      : conflict
        ? "conflict"
        : error
          ? "error"
          : dirty || !meta.fileId
            ? "dirty"
            : "idle";

  const value: SyncCtl = {
    available,
    status,
    meta,
    error,
    dirty,
    push,
    pull,
    setAuto: (v) => persist({ ...meta, auto: v }),
    unlink,
    clearError: () => setError(""),
  };

  return <Ctx.Provider value={value}>{children}</Ctx.Provider>;
}

/* ===================== مؤشر المزامنة الحيّ (الترويسة) ===================== */
const TONE: Record<SyncStatus, { dot: string; txt: string; label: string }> = {
  off: { dot: "bg-sand-dark", txt: "text-ink-faint", label: "المزامنة غير مفعّلة" },
  idle: { dot: "bg-pine-500", txt: "text-pine-700", label: "متزامن" },
  dirty: { dot: "bg-gold-500", txt: "text-gold-700", label: "تغييرات غير محفوظة" },
  saving: { dot: "bg-gold-500", txt: "text-gold-700", label: "جارٍ الحفظ على Drive…" },
  pulling: { dot: "bg-gold-500", txt: "text-gold-700", label: "جارٍ الاسترجاع من Drive…" },
  conflict: { dot: "bg-clay", txt: "text-clay", label: "تعارض نسخ — يلزم قرار" },
  error: { dot: "bg-clay", txt: "text-clay", label: "تعذّرت المزامنة" },
};

export function SyncChip({ onOpenPanel }: { onOpenPanel?: () => void }) {
  const s = useSync();
  const [, tick] = useState(0);
  useEffect(() => {
    const t = setInterval(() => tick((x) => x + 1), 30_000);
    return () => clearInterval(t);
  }, []);
  if (s.status === "off") return null;

  const tone = TONE[s.status];
  const busy = s.status === "saving" || s.status === "pulling";
  const label =
    s.status === "idle"
      ? `متزامن ${relTime(s.meta.at)}`
      : s.status === "dirty"
        ? s.meta.fileId
          ? "تغييرات غير محفوظة"
          : "لم يُحفظ على Drive بعد"
        : tone.label;

  return (
    <button
      onClick={() => (busy ? undefined : s.status === "dirty" ? void s.push() : onOpenPanel?.())}
      title={`${label}${s.status === "dirty" && !busy ? " — اضغط للحفظ الآن" : ""}`}
      className={cn(
        "flex items-center gap-1.5 rounded-full border bg-cream-deep/60 px-2.5 py-1 text-[10px] font-extrabold transition hover:border-gold-400",
        s.status === "conflict" || s.status === "error" ? "border-clay/40" : "border-sand-deep",
        busy ? "cursor-wait" : "cursor-pointer"
      )}
    >
      <span className={cn("h-2 w-2 rounded-full", tone.dot, busy && "anim-pulse-gold")} />
      {busy && <Icon name="refresh" size={11} className={cn("animate-spin", tone.txt)} />}
      <span className={tone.txt}>{label}</span>
    </button>
  );
}

/* ===================== لوحة المزامنة (لوحة التحكم) ===================== */
export function SyncPanel() {
  const s = useSync();
  const d = useDrive();
  const [armUnlink, setArmUnlink] = useState(false);
  const tone = TONE[s.status];

  if (!s.available) {
    return (
      <div className="rounded-xl border border-gold-200/80 bg-cream p-5 shadow-soft">
        <h4 className="flex items-center gap-2 font-display text-lg font-bold text-pine-900">
          <Icon name="refresh" size={17} className="text-gold-600" /> مزامنة الملف مع Drive
        </h4>
        <p className="mt-2 text-xs font-bold leading-relaxed text-ink-soft">
          {d.enabled
            ? "اربط حساب Google أولاً ثم فعّل المزامنة — ستحفظ نسخة من ملفك داخل مجلد خاص على Drive وتسترجعها من أي جهاز."
            : "فعّل ربط Google Drive من مفتاح التفعيل أعلاه لتصبح المزامنة متاحة."}
        </p>
      </div>
    );
  }

  return (
    <div className="relative overflow-hidden rounded-xl border border-gold-200/80 bg-cream p-5 shadow-soft md:p-6">
      <div className="flex flex-wrap items-start justify-between gap-3">
        <div>
          <h4 className="flex items-center gap-2 font-display text-xl font-bold text-pine-900">
            <Icon name="refresh" size={19} className="text-gold-600" /> مزامنة الملف مع Drive
          </h4>
          <p className="mt-1.5 max-w-xl text-[11px] font-bold leading-relaxed text-ink-soft">
            يُحفظ ملف إنجازك كاملاً (البيانات، المعايير، الشواهد، الممارسات، الإنجازات) في ملف <span dir="ltr">{DOC_NAME}</span> داخل مجلد «{FOLDER_NAME}» على حسابك — فترجع إليه من أي جهاز أو بعد مسح بيانات المتصفح.
          </p>
        </div>
        <span className={cn("flex items-center gap-1.5 rounded-full border px-2.5 py-1 text-[10px] font-extrabold", s.status === "idle" ? "border-pine-600/25 bg-pine-50" : "border-gold-500/35 bg-gold-100/70")}>
          <span className={cn("h-2 w-2 rounded-full", tone.dot, (s.status === "saving" || s.status === "pulling") && "anim-pulse-gold")} />
          <span className={tone.txt}>{tone.label}</span>
        </span>
      </div>

      {/* آخر مزامنة */}
      <div className="mt-4 flex flex-wrap gap-2">
        {[
          ["آخر حفظ", s.meta.at ? relTime(s.meta.at) : "—"],
          ["نسخة Drive", s.meta.remoteTime ? relTime(s.meta.remoteTime) : "—"],
          ["المجلد", s.meta.folderId ? "مرتبط" : "غير منشأ"],
        ].map(([k, v]) => (
          <div key={k} className="min-w-[110px] flex-1 rounded-lg border border-sand-deep/70 bg-cream-deep/50 px-3 py-2">
            <p className="text-[10px] font-extrabold text-ink-faint">{k}</p>
            <p className="mt-0.5 text-xs font-bold text-pine-900">{v}</p>
          </div>
        ))}
      </div>

      {/* تعارض النسخ */}
      {s.status === "conflict" && (
        <div className="mt-4 rounded-lg border border-clay/30 bg-clay/[.07] p-4">
          <p className="flex items-center gap-2 text-xs font-extrabold text-clay">
            <Icon name="shield" size={15} /> توجد نسخة أحدث على Drive من نسختك المحلية
          </p>
          <p className="mt-1.5 text-[11px] font-bold leading-relaxed text-ink">
            غالباً لأنك عدّلت الملف من جهاز آخر. اختر أي النسختين تُعتمد — لا يُدمج شيء تلقائياً حتى لا تفقد بيانات.
          </p>
          <div className="mt-3 flex flex-wrap gap-2">
            <button className="btn-primary" onClick={() => void s.pull()}>
              <Icon name="download" size={14} /> استرجاع نسخة Drive
            </button>
            <button className="btn-gold" onClick={() => void s.push(true)}>
              <Icon name="upload" size={14} /> اعتماد نسختي المحلية
            </button>
          </div>
        </div>
      )}

      {s.error && (
        <div className="mt-4 flex items-start justify-between gap-2 rounded-lg border border-clay/30 bg-clay/10 px-3 py-2">
          <p className="text-[11px] font-bold leading-relaxed text-clay">{s.error}</p>
          <button className="shrink-0 text-clay hover:opacity-70" onClick={s.clearError} aria-label="إغلاق">
            <Icon name="x" size={13} />
          </button>
        </div>
      )}

      {/* الإجراءات */}
      <div className="mt-4 flex flex-wrap items-center gap-2 border-t border-gold-200/60 pt-4">
        <button className="btn-primary" onClick={() => void s.push()} disabled={s.status === "saving" || s.status === "pulling"}>
          <Icon name="upload" size={15} /> احفظ على Drive
        </button>
        <button className="btn-soft" onClick={() => void s.pull()} disabled={s.status === "saving" || s.status === "pulling"}>
          <Icon name="download" size={15} /> استرجع من Drive
        </button>
        {s.meta.folderLink && (
          <a className="btn-ghost" href={s.meta.folderLink} target="_blank" rel="noreferrer">
            <Icon name="external" size={14} /> فتح المجلد
          </a>
        )}
        <button
          className={cn("btn-danger ms-auto", armUnlink && "border-clay bg-clay text-white hover:bg-clay")}
          onClick={() => (armUnlink ? (setArmUnlink(false), s.unlink()) : setArmUnlink(true))}
        >
          <Icon name="x" size={13} /> {armUnlink ? "تأكيد قطع المزامنة؟" : "قطع ربط المزامنة"}
        </button>
      </div>

      {/* المزامنة التلقائية */}
      <div className="mt-4 flex flex-wrap items-center justify-between gap-3 rounded-lg border border-pine-600/20 bg-pine-50/70 p-4">
        <div className="min-w-0">
          <p className="text-sm font-extrabold text-pine-900">المزامنة التلقائية</p>
          <p className="mt-1 text-[11px] font-bold leading-relaxed text-ink-soft">
            تحفظ تلقائياً بعد 6 ثوانٍ من توقّفك عن التعديل — دون أي جهد منك. تتوقف تلقائياً عند وجود تعارض نسخ.
          </p>
        </div>
        <Switch checked={s.meta.auto} onChange={s.setAuto} label="المزامنة التلقائية" />
      </div>
    </div>
  );
}
